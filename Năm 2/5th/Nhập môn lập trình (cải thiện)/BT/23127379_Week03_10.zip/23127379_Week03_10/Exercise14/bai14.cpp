#include "bai14.h"

void inputNumber(int &n)
{
    cout << "Nhap n: ";
    cin >> n;
}
bool isAllOddDigit(int n)
{
    bool AllOddDigit = true;
    while (n > 0)
    {
        int remainder = n % 10;
        if (remainder % 2 == 0)
        {
            AllOddDigit = false;
            break;
        }
        n /= 10;
    }
    return AllOddDigit;
}