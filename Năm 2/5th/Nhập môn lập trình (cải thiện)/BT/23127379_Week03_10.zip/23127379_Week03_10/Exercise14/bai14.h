#pragma once

#include <iostream>
using namespace std;

void inputNumber(int &n);
bool isAllOddDigit(int n);