#include "bai14.h"

int main()
{
    int n = 0;
    inputNumber(n);
    bool checkOddDigit = isAllOddDigit(n);
    if (checkOddDigit)
    {
        cout << "Gia tri " << n << " deu mang gia tri le.\n";
    }
    else
    {
        cout << "Gia tri " << n << " co it nhat 1 chu so mang gia tri chan.\n";
    }
    return 0;
}