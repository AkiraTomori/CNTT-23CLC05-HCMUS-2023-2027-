#include "bai6.h"

void inputDate(int &day, int &month, int &year)
{
    cout << "Ngay: ";
    cin >> day;
    cout << "Thang: ";
    cin >> month;
    cout << "Nam: ";
    cin >> year;
}
bool checkLeapYear(int year)
{
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}
int GetDaysInMonth(int month, int year)
{
    switch(month)
    {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
        {
            return 31;
        }
        case 4: case 6: case 9: case 11:
        {
            return 30;
        }
        case 2:
        {
            return (checkLeapYear(year) ? 29 : 28);
        }
        default:
        {
            return 0;
        }
    }
}
void getPreviousDay(int day, int month, int year)
{
    int maxDaysInMonth = GetDaysInMonth(month, year);
    if (day < 1 || day > maxDaysInMonth || month < 1 || month > 12)
    {
        cout << "Ngay nhap vao khong hop le.\n";
    }
    else
    {
        day--;
        if (day < 1)
        {
            day = maxDaysInMonth;
            month--;
            if (month < 1)
            {
                month = 12;
                year--;
            }
        }
    }
    cout << "Ngay truoc: " << day << "/" << month << "/" << year << "\n";
}