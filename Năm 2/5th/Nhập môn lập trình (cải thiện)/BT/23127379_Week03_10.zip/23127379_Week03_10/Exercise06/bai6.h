#pragma once

#include <iostream>
using namespace std;

void inputDate(int &day, int &month, int &year);
bool checkLeapYear(int year);
int GetDaysInMonth(int month, int year);
void getPreviousDay(int day, int month, int year);