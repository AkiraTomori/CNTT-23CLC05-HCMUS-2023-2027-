#include "bai6.h"

int main()
{
    int day, month, year;
    inputDate(day, month, year);
    getPreviousDay(day, month, year);
    return 0;
}