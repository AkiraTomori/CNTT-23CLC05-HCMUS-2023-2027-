#pragma once

#include <iostream>
using namespace std;

void inputNumber(int &a, int &b);
int FindGCD(int a, int b);