#include "bai16.h"

int main()
{
    int a, b;
    inputNumber(a, b);
    int GCD = FindGCD(a, b);
    cout << "Uoc chung nho nhat: " << GCD << "\n";
    return 0;
}