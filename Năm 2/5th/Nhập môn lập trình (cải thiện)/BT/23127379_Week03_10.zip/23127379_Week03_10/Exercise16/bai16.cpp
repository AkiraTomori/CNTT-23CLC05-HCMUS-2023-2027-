#include "bai16.h"

void inputNumber(int &a, int &b)
{
    cout << "Nhap vao gia tri thu nhat: ";
    cin >> a;
    cout << "Nhap vao gia tri thu hai: ";
    cin >> b;
}
int FindGCD(int a, int b)
{
    int r = 0;
    while (b != 0)
    {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}