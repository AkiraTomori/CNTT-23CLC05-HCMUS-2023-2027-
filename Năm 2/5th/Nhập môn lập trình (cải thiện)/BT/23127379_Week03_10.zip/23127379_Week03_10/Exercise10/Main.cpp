#include "bai10.h"

int main()
{
    int n = 0;
    inputNumber(n);
    bool checkPrime = isPrime(n);
    if (checkPrime)
    {
        cout << n << " la so nguyen to.\n";
    }
    else
    {
        cout << n << " khong la so nguyen to.\n";
    }
    return 0;
}