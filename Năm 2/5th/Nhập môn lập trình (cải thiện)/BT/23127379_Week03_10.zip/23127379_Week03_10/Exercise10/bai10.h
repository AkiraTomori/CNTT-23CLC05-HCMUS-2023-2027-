#pragma once

#include <iostream>
#include <math.h>
using namespace std;

void inputNumber(int &n);
bool isPrime(int n);