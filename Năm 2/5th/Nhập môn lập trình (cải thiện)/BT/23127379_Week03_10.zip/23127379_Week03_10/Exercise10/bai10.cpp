#include "bai10.h"

void inputNumber(int &n)
{
    cout << "Nhap n: ";
    cin >> n;
}
bool isPrime(int n)
{
    if (n < 2)
        return false;
    int sqrt2 = sqrt(n);
    for (int i = 2; i <= sqrt2; i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}