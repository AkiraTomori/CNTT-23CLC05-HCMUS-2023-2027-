#include "bai20.h"

void inputNumber(int &a, int &b, int &c)
{
    cout << "Nhap a: ";
    cin >> a;
    cout << "Nhap b: ";
    cin >> b;
    cout << "Nhap c: ";
    cin >> c;
}
int FindMax(int a, int b, int c)
{
    int max = 0;
    if (a > b && a > c)
    {
        max = a;
    }
    else if (b > a && b > c)
    {
        max = b;
    }
    else if (c > a && c > b)
    {
        max = c;
    }
    return max;
}
int FindMaxBetweenTwoNumber(int a, int b)
{
    return (a > b ? a : b);
}
void printSecondLargest(int a, int b, int c) {
    if (a == b && b == c) {
        cout << "Khong co gia tri lon thu hai.\n" << endl;
        return;
    }

    int maxNum, secondLargest = INT_MIN;

    if (a >= b && a >= c) {
        maxNum = a;
    } 
    else if (b >= a && b >= c) {
        maxNum = b;
    } 
    else {
        maxNum = c;
    }

    if (a < maxNum)
        secondLargest = a;
    if (b < maxNum && b > secondLargest) secondLargest = b;
    if (c < maxNum && c > secondLargest) secondLargest = c;
    cout << "Gia tri lon thu hai: " << secondLargest << "\n";
}