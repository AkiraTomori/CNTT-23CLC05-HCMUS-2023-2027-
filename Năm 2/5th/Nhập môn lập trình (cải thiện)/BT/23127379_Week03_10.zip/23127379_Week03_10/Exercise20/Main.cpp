#include "bai20.h"

int main()
{
    int a, b, c;
    inputNumber(a, b, c);
    printSecondLargest(a, b, c);
    return 0;
}