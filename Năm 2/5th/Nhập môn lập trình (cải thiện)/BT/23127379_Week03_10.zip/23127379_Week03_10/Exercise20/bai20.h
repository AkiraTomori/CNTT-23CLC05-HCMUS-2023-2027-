#pragma once

#include <iostream>
#include <climits>
using namespace std;

void inputNumber(int &a, int &b, int &c);
void printSecondLargest(int a, int b, int c);