#include "bai2.h"

int main()
{
    double grade = 0.0;
    inputNumber(grade);
    checkGrade(grade);
    return 0;
}