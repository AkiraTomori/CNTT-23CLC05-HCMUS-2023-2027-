#include "bai2.h"

void inputNumber(double &grade)
{
    cout << "GPA: ";
    cin >> grade;
}
void checkGrade(double grade)
{
    if (grade > 9 && grade <= 10)
    {
        cout << "Outstanding\n";
    }
    else if (grade > 8 && grade <= 9)
    {
        cout << "Excellent\n";
    }
    else if (grade > 7 && grade <= 8)
    {
        cout << "Good\n";
    }
    else if (grade > 6 && grade <= 7)
    {
        cout << "Above Average\n";
    }
    else if (grade > 5 && grade <= 6)
    {
        cout << "Average\n";
    }
    else
    {
        cout << "Below Average\n";
    }
}