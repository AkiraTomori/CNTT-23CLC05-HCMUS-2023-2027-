#pragma once

#include <iostream>
using namespace std;

void inputNumber(int &n);
int FindLargestDigit(int n);