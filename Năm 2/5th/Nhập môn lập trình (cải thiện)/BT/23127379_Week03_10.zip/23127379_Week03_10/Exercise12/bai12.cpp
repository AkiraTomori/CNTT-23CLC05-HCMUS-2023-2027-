#include "bai12.h"

void inputNumber(int &n)
{
    cout << "Nhap n: ";
    cin >> n;
}
int FindLargestDigit(int n)
{
    int maxDigit = n % 10;
    n /= 10;
    while (n > 0)
    {
        int remainder = n % 10;
        if (maxDigit < remainder)
        {
            maxDigit = remainder;
        }
        n /= 10;
    }
    return maxDigit;
}