#include "bai12.h"

int main()
{
    int n = 0;
    inputNumber(n);
    int maxDigit = FindLargestDigit(n);
    cout << "Chu so lon nhat: " << maxDigit << "\n";
    return 0;
}