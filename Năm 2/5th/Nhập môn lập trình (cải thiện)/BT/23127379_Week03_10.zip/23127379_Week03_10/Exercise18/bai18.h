#pragma once

#include <iostream>

using namespace std;

void inputNumber(double &x, int &n);
double CalculateSn(double x, int n);