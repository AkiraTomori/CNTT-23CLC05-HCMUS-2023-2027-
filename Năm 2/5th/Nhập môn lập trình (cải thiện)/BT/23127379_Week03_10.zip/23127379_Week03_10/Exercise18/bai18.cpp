#include "bai18.h"

void inputNumber(double &x, int &n)
{
    cout << "Nhap x: ";
    cin >> x;
    cout << "Nhap n: ";
    cin >> n;
}
double CalculateSn(double x, int n)
{
    double SumN = 0.0;
    double term = 1.0;
    int sign = -1;
    int SumCSC = 0;
    for (int i = 1; i <= n; i++)
    {
        term = term * x;
        SumCSC = SumCSC + i;
        SumN = SumN + sign * (term) / (SumCSC);
        sign = -sign;
    }
    return SumN;
}