#include "bai18.h"

int main()
{
    double x = 0.0;
    int n = 0;
    inputNumber(x, n);
    double Sum = CalculateSn(x, n);
    cout << "Gia tri cua S(x) = " << Sum << "\n";
    return 0;
}