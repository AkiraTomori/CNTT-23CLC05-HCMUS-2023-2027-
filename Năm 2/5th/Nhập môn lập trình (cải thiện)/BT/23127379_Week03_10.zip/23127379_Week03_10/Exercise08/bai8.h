#pragma once

#include <iostream>
using namespace std;

void inputPlayerChoice(char &c1, char &c2);
char toUpperCase(char c);
void determineWinner(char p1, char p2);