#include "bai8.h"


void inputPlayerChoice(char &c1, char &c2)
{
    cout << "Lua chon nguoi choi dau: (R, r, P, p, S, s) ";
    cin >> c1;
    cout << "Lua chon nguoi choi nhi: (R, r, P, p, S, s) ";
    cin >> c2;
}
char toUpperCase(char c)
{
    if (c >= 'a' && c <= 'z')
    {
        c = c - 32;
    }
    return c;
}
void determineWinner(char p1, char p2)
{
    p1 = toUpperCase(p1);
    p2 = toUpperCase(p2);
    if (p1 == p2)
    {
        cout << "Hoa.\n";
    }
    else if ((p1 == 'R' && p2 == 'S') || (p1 == 'S' && p1 == 'P') || (p1 == 'P' && p2 == 'R'))
    {
        cout << "Nguoi choi 1 thang.\n";
    }
    else
    {
        cout << "Nguoi choi 2 thang.\n";
    }
}