#include "bai8.h"

int main()
{
    char player1, player2;
    inputPlayerChoice(player1, player2);
    determineWinner(player1, player2);
    return 0;
}