#include "bai4.h"

int main()
{
    int a, b, c;
    double x1, x2;
    inputCoefficent(a, b, c);
    solveQuadratic(a, b, c, x1, x2);
    return 0;
}