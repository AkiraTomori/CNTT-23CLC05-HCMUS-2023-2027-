#pragma once

#include <iostream>
#include <math.h>
using namespace std;

void inputCoefficent(int &a, int &b, int &c);
void solveLinear(int a, int b, double &x);
void solveQuadratic(int a, int b, int c, double &x1, double &x2);