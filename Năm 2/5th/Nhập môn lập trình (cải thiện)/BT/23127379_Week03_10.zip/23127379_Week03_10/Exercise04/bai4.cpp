#include "bai4.h"

void inputCoefficent(int &a, int &b, int &c)
{
    cout << "a = ";
    cin >> a;
    cout << "b = ";
    cin >> b;
    cout << "c = ";
    cin >> c;
}
void solveLinear(int a, int b, double &x)
{
    if (a == 0)
    {
        cout << (b == 0 ? "Phuong trinh vo nghiem" : "Phuong trinh co vo so nghiem") << "\n";
    }
    else
    {
        x = (double)(-b) / a;
        cout << "Phuong trinh co nghiem thuc mang gia tri: " << x << "\n";
    }
}
void solveQuadratic(int a, int b, int c, double &x1, double &x2)
{
    if (a == 0)
    {
        solveLinear(b, c, x1);
        x2 = 0;
    }
    else
    {
        double delta = b * b - 4 * a * c;
        double sqrtDelta = sqrt(delta);
        if (delta < 0)
        {
            cout << "Phuong trinh vo nghiem.\n";
        }
        else if (delta == 0)
        {
            x1 = (-b) / (2 * a);
            x2 = x1;
            cout << "Phuong trinh co nghiem kep: " << x1 << "\n";
        }
        else if (delta > 0)
        {
            x1 = (-b + sqrtDelta) / (2 * a);
            x2 = (-b - sqrtDelta) / (2 * a);
            cout << "Phuong trinh co 2 nghiem thuc phan biet: " << x1 << " , " << x2 << "\n"; 
        }
    }
}