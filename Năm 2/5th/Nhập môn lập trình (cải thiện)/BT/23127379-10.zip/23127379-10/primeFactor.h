#pragma once
#include <iostream>
#include <math.h>

using namespace std;
bool isPrime(int n);
void printPrimeFactor(int n);