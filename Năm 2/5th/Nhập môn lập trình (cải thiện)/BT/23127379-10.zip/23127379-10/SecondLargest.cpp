#include "SecondLargest.h"

void inputArray(int arr[], int n)
{
    cout << "Enter Numbers: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
}
void outputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
void findSecondLargest(int arr[], int n)
{
    if (n < 2)
    {
        return;
    }
    int Largest = -1;
    int SecondLargest = -1;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > Largest && arr[i] > SecondLargest)
        {
            SecondLargest = Largest;
            Largest = arr[i];
        }
        else if (arr[i] > SecondLargest && arr[i] < Largest)
        {
            SecondLargest = arr[i];
        }
    }
    cout << "Second largest Number: " << SecondLargest << "\n";
}
void findSecondLargestSort(int arr[], int n)
{
    sort(arr, arr + n);
    for (int i = n - 2; i >= 0; i--)
    {
        if (arr[i] != arr[i + 1])
        {
            cout << "Second largest Number: " << arr[i] << "\n";
            return;
        }
    }
}