#include "Employee.h"
// void inputArray(int arr[], int n)
// {
//     for (int i = 0; i < n; i++)
//     {
//         cin >> arr[i];
//     }
// }
// void outputArray(int arr[], int n)
// {
//     for (int i = 0; i < n; i++)
//     {
//         cout << arr[i] << " ";
//     }
//     cout << "\n";
// }
void categoryEmployee(int arr[], int n)
{
    cout << "Low Income Group (<5000)\n";
    for (int i = 0; i < n; i++)
    {
        if (arr[i] < 5000)
        {
            cout << "Employee " << i + 1 << ": " << "$" << arr[i] << "\n";
        }
    }
    cout << "High income Group (>= 5000)\n";
    for (int i = 0; i < n; i++)
    {
        if (arr[i] >= 5000)
        {
            cout << "Employee " << i + 1 << ": " << "$" << arr[i] << "\n";
        }
    }
}