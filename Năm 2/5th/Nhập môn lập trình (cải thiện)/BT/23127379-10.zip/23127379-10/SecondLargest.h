#pragma once
#include <iostream>
#include <algorithm>
#include <set>
using namespace std;

void inputArray(int arr[], int n);
void outputArray(int arr[], int n);
void findSecondLargest(int arr[], int n);
void findSecondLargestSort(int arr[], int n);
