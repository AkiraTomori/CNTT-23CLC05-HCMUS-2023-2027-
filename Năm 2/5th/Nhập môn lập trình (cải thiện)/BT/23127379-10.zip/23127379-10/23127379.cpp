#include "primeFactor.h"
#include "SecondLargest.h"
#include "Employee.h"
using namespace std;

int main()
{
    // Bai 1
    int m;
    cout << "Enter number: ";
    cin >> m;
    printPrimeFactor(m);
    cout << "\n";
    // Bai 2

    int n;
    cout << "Enter size of array: ";
    cin >> n;
    int arr[100];
    inputArray(arr, n);
    outputArray(arr, n);
    findSecondLargest(arr, n);
    findSecondLargestSort(arr, n);

    // Bai 3
    int p;
    cout << "Enter the number of Salary: ";
    cin >> p;
    int b[100];
    for (int i = 0; i < p; i++)
    {
        cout << "Enter Salary for employee " << i + 1 << ": ";
        cin >> b[i];
    }
    outputArray(b, p);
    categoryEmployee(b, p);
    return 0;
}