#pragma once
#include <iostream>
using namespace std;

// void inputArray(int arr[], int n);
// void outputArray(int arr[], int n);
void categoryEmployee(int arr[], int n);