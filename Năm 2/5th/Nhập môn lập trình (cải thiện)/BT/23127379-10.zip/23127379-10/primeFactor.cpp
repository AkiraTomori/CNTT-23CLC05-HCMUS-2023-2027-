#include "primeFactor.h"

bool isPrime(int n)
{
    if (n < 2)
        return false;
    int canBac2 = sqrt(n);
    for (int i = 2; i <= canBac2; i++)
    {
        if (n % i == 0)
            return false;
    }
    return true;
}
void printPrimeFactor(int n)
{
    int temp = n;
    for (int i = 2; i <= n; i++)
    {
        if (isPrime(i))
        {
            if (temp % i == 0)
            {
                cout << i << " ";
                temp /= i;
                i--;
            }
        }
    }
}