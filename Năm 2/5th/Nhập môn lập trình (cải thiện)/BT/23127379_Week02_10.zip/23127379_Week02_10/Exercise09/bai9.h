#pragma once

#include <iostream>
#include <math.h>
using namespace std;

double exp2HandMade(double x, int n);
void inputNumber(double &x, int &n);