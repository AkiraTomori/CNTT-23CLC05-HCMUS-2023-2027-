#include "bai9.h"

double exp2HandMade(double x, int n){
    double term = 1.0;
    double sum = 1.0;
    int fact = 1;
    for (int i = 1; i <= n; i++){
        term = term * (x * x);
        fact = fact * (2 * i - 1) * (2 * i);
        sum += (double)(term) / fact;
    }
    return sum;
}

void inputNumber(double &x, int &n){
    cout << "Nhap vao he so x: ";
    cin >> x;
    cout << "Nhap vao bac n: ";
    cin >> n;
}