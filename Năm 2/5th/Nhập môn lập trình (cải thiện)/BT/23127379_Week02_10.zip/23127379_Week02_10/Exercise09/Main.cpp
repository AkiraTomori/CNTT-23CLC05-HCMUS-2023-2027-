#include "bai9.h"

int main()
{
    double x = 0.0; int n = 0.0;
    inputNumber(x, n);
    double giatri = exp2HandMade(x, n);
    cout << "Gia tri cua S: " << giatri << "\n";
    return 0;
}