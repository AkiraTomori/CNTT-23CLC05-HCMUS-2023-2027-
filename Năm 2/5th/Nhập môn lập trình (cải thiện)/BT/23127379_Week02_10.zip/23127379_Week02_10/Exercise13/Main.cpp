#include "bai13.h"

int main()
{
    int n = 0;
    inputNumber(n);
    int MaxDigitOfN = FindMaxDigit(n);
    cout << "Chu so co gia tri lon nhat trong " << n << " la: " << MaxDigitOfN << "\n";
    int CountMaxDigitAppearInN = CountMaxDigitAppear(n);
    cout << "So lan xuat hien cua " << MaxDigitOfN << " trong " << n << " la: " << CountMaxDigitAppearInN << "\n";
    return 0;
}