#include "bai13.h"

void inputNumber(int &n)
{
    cout << "Nhap vao gia tri n: ";
    cin >> n;
}
int FindMaxDigit(int n){
    int maxDigit = n % 10;
    n /= 10;
    while (n > 0){
        int remainder = n % 10;
        if (maxDigit < remainder)
        {
            maxDigit = remainder;
        }
        n /= 10;
    }
    return maxDigit;
}
int CountMaxDigitAppear(int n)
{
    int maxDigit = 0;
    int count = 0;
    while (n > 0)
    {
        int Remainder = n % 10;
        if (maxDigit < Remainder){
            maxDigit = Remainder;
            count = 1;
        }
        else if (maxDigit == Remainder){
            count++;
        }
        n /= 10;
    }
    return count;
}