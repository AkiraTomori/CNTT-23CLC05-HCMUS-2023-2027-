#pragma once
#include <iostream>
using namespace std;

void inputNumber(int &n);
int CountMaxDigitAppear(int n);
int FindMaxDigit(int n);