#include "bai1.h"

int main()
{
    int a, b, c;
    inputTriangle(a, b, c);
    if (checkValidTriangle(a, b, c)){
        cout << "Tam giac hop le.\n";
    }
    else{
        cout << "Tam giac khong hop le.\n";
        return 1;
    }
    int Perimeter = PerimeterOfTriangle(a, b, c);
    double Area = AreaOfTriangle(a, b, c);
    cout << "Chu vi cua tam giac la: " << Perimeter << " cm.\n";
    cout << "Dien tich cua tam giac la: " << setprecision(3) << fixed << Area << " cm^2." << "\n";  
    return 0;
}