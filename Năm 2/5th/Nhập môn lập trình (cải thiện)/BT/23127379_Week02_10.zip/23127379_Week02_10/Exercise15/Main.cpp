#include "bai15.h"

int main()
{
    int n = 0;
    inputNumber(n);
    bool checkIncreasing = checkIfIncreasing(n);
    if (checkIncreasing){
        cout << "Cac chu so dang tang dan.\n";
    }
    else{
        cout << "Khong tang dan.\n";
    }
    return 0;
}