#include "bai15.h"

void inputNumber(int &n)
{
    cout << "Nhap vao gia tri cua n: ";
    cin >> n;
}
bool checkIfIncreasing(int n)
{
    bool isIncreasing = true;
    int FirstDigit = n % 10; 
    n /= 10;
    while (n > 0)
    {
        int SecondDigit = n % 10;
        if (SecondDigit > FirstDigit){
            isIncreasing = false;
            break;
        }
        FirstDigit = SecondDigit;
        n /= 10;
    }
    return isIncreasing;
}