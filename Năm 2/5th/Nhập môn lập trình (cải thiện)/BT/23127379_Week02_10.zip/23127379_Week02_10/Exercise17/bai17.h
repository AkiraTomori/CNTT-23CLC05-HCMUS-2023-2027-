#pragma once
#include <iostream>
using namespace std;

void inputNumber(double &x, int &n);
double calculateS(double x, int n);