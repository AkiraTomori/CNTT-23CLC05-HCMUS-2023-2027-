#include "bai17.h"

void inputNumber(double &x, int &n)
{
    cout << "Nhap vao gia tri x: ";
    cin >> x;
    cout << "Nhap vao gia tri n: ";
    cin >> n;
}
double calculateS(double x, int n)
{
    double sum = 0.0;
    double term = 1.0;
    int sign = 1;
    for (int i = 1; i <= n; i++){
        term = term * x;
        sum = sum + term * sign;
        sign = -sign;
    }
    return sum;
}