#include "bai17.h"

int main()
{
    int n = 0;
    double x = 0.0;
    inputNumber(x, n);
    double sum = calculateS(x, n);
    cout << "Gia tri cua S: " << sum << "\n";
    return 0;
}