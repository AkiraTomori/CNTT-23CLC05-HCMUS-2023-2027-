#include "bai11.h"

void inputNumber(int &n)
{
    cout << "Nhap vao gia tri n: ";
    cin >> n;
}
int FindReversedNumber(int n)
{
    int ReversedNumber = 0;
    while (n > 0)
    {
        int Remainder = n % 10;
        ReversedNumber = ReversedNumber * 10 + Remainder;
        n /= 10;
    }
    return ReversedNumber;
}