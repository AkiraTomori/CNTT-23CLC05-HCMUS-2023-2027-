#include "bai11.h"

int main(){
    int n = 0;
    inputNumber(n);
    int ReversedValue = FindReversedNumber(n);
    cout << "Gia tri nguoc cua n: " << ReversedValue << "\n";
    return 0;
}