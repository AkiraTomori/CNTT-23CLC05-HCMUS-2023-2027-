#include "bai7.h"

void roundNumber(double &x, int n){
    double scale = pow(10, n);
    x = x * scale;
    if (x >= 0)
    {
        x = floor(x + 0.5) / scale;
    }
    else
    {
        x = -float(-x + 0.5) / scale;
    }
}

void inputNumber(double &x, int &n){
    cout << "Nhap vao gia tri thuc: ";
    cin >> x;
    cout << "Nhap vao gia tri can de lam tron den: ";
    cin >> n;
}