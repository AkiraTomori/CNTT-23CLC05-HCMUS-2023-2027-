#pragma once
#include <iostream>
#include <math.h>
using namespace std;

void roundNumber(double &x, int n);
void inputNumber(double &x, int &n);
