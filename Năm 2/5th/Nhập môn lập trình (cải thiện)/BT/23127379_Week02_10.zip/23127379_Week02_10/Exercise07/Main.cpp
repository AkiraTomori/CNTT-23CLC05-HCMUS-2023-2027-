#include "bai7.h"

int main()
{
    double x = 0; int n = 0;
    inputNumber(x, n);
    cout << "Gia tri cua x truoc khi duoc lam tron: " << x << "\n";
    roundNumber(x, n);
    cout << "Gia tri cua x sau khi duoc lam tron theo " << n << " chu so: " << x << "\n"; 
    return 0;
}