#pragma once

#include <iostream>
using namespace std;

int Func1(int i, int j, int k);
int Func2(int i, int j, int k);
void printPossibleValue(int StandBuffalo, int LyingBuffalo, int OldBuffalo);