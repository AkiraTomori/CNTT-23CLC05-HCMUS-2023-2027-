#include "bai19.h"

int Func1(int i, int j, int k)
{
    return i + j + k;
}
int Func2(int i, int j, int k)
{
    return 5 * i + 3 * j + k / 3;
}
void printPossibleValue(int StandBuffalo, int LyingBuffalo, int OldBuffalo)
{
    int Nghiem = 1;
    for (StandBuffalo = 0; StandBuffalo < 20; StandBuffalo++)
    {
        for (LyingBuffalo = 0; LyingBuffalo < 33; LyingBuffalo++)
        {
            OldBuffalo = 100 - StandBuffalo - LyingBuffalo;
            if (OldBuffalo % 3 == 0 && Func1(StandBuffalo, LyingBuffalo, OldBuffalo) == 100 && Func2(StandBuffalo, LyingBuffalo, OldBuffalo) == 100)
            {
                cout << "Nghiem " << Nghiem << "\n";
                cout << "So trau dung: " << StandBuffalo << "\n";
                cout << "So trau nam: " << LyingBuffalo << "\n";
                cout << "So trau gia: " << OldBuffalo << "\n";
                cout << "\n";
                Nghiem++;
            }
        }
    }
}