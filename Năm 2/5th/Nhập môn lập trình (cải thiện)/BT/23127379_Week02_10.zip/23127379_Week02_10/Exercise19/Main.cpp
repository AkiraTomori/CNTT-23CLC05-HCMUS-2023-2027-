#include "bai19.h"

int main()
{
    int StandBuffalo = 0, LyingBuffalo = 0, OldBuffalo = 0;
    printPossibleValue(StandBuffalo, LyingBuffalo, OldBuffalo);
    return 0;
}