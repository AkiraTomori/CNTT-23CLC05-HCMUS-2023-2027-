#include "bai3.h"

int main()
{
    int a, b;
    double x;
    inputCoefficent(a, b);
    solveLinearEquation(a, b, x);
    return 0;
}