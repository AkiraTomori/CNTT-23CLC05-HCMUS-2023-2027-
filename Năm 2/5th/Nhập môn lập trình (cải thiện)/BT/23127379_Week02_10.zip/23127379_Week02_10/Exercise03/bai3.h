#pragma once
#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

void solveLinearEquation(int a, int b, double &x);
void inputCoefficent(int &a, int &b);