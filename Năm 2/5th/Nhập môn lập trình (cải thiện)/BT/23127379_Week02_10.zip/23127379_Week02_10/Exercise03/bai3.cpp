#include "bai3.h"

void solveLinearEquation(int a, int b, double &x){
    if (a == 0){
        cout << (b == 0 ? "Phuong trinh co vo so nghiem.\n" : "Phuong trinh vo nghiem.\n");
    }
    else{
        x = (1.0) * (-b) / (a);
        cout << "Phuong trinh co 1 nghiem thuc mang gia tri la: " << setprecision(3) << fixed << x << "\n";
    }
}
void inputCoefficent(int &a, int &b){
    cout << "Nhap vao he so a: ";
    cin >> a;
    cout << "Nhap vao he so b: ";
    cin >> b;
}