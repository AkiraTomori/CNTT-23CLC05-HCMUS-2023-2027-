#pragma once
#include <iostream>
#include <math.h>
using namespace std;

bool isLeapYear(int year);
int getDaysInMonth(int month, int year);
void getNextDay(int day, int month, int year);
void inputDate(int &day, int &month, int &year);