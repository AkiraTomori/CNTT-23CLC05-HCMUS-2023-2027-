#include "bai5.h"

int main(){
    int day, month, year;
    inputDate(day, month, year);
    getNextDay(day, month, year);
    return 0;
}