#pragma once
#include <iostream>
#include <string.h>
#include <string>
#include <climits>
#include <conio.h>
using namespace std;

#define MAX_LENGTH 7
bool isOnBorder(int x, int y, int m, int n);
void inputMatrix(char matrix[][MAX_LENGTH], int m, int n);
void outputMatrix(char matrix[][MAX_LENGTH], int m, int n);
void findBoundaryPosition(char matrix[][MAX_LENGTH], int m, int n, int &x1, int &y1, int &x2, int &y2);
int findMinStarPath(char matrix[][MAX_LENGTH], int m, int n, int x1, int y1, int x2, int y2);
