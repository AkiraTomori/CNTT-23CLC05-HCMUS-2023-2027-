#include "Matrix.h"

void inputMatrix(char matrix[][MAX_LENGTH], int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << "Nhap phan tu matrix[" << i + 1 << "][" << j + 1 << "]: ";
            cin >> matrix[i][j];
        }
    }
}
void outputMatrix(char matrix[][MAX_LENGTH], int m, int n)
{
    cout << "Danh sach cac phan tu: \n";
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << matrix[i][j] << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}
bool isOnBorder(int x, int y, int m, int n)
{
    return (x == 0 || x == m - 1 || y == 0 || y == n - 1);
}
void findBoundaryPosition(char matrix[][MAX_LENGTH], int m, int n, int &x1, int &y1, int &x2, int &y2)
{
    x1 = y1 = x2 = y2 = -1;
    int count = 0;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (isOnBorder(i, j, m , n) && matrix[i][j] == '.')
            {
                if (count == 0)
                {
                    x1 = i;
                    y1 = j;
                }
                else
                {
                    x2 = i;
                    y2 = j;
                    return;
                }
                count++;
            }
        }
    }
}

int findMinStarPath(char matrix[][MAX_LENGTH], int m, int n, int x1, int y1, int x2, int y2)
{
    int starCount = 0;
    int x = x1, y = y1;
    while (x != x2 || y != y2)
    {
        if (x < x2 && matrix[x + 1][y] == '*')
        {
            x++;
        }
        else if (x > x2 && matrix[x - 1][y] == '*')
        {
            x--;
        }
        else if (y < y2 && matrix[x][y + 1] == '*')
        {
            y++;
        }
        else if (y > y2 && matrix[x][y - 1] == '*')
        {
            y--;
        }
        else
            break;
        if (matrix[x][y] == '*') starCount++;
    }
    return starCount;
}