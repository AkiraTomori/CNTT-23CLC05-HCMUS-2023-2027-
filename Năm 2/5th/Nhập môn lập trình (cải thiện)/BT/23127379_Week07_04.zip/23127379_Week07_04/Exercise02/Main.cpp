#include "Matrix.h"

int main()
{
    int x1, y1, x2, y2;
    char matrix[6][7] = {
        {'#', '#', '#', '#', '#', '#', '#'},
        {'#', '*', ' ', ' ', '*', '*', '.'},
        {'#', ' ', ' ', ' ', '*', ' ', '#'},
        {'#', '*', ' ', '*', '*', ' ', '#'},
        {'#', ' ', '*', '*', ' ', '*', '#'},
        {'#', '#', '.', '#', '#', '#', '#'}
    };
    outputMatrix(matrix, 6, 7);
    findBoundaryPosition(matrix, 6, 7, x1, y1, x2, y2);
    cout << "Toa do dau tien: " << x1 << ", " << y1 << "\n";
    cout << "Toa do thu hai: " << x2 << ", " << y2 << "\n";

    int countPaths = findMinStarPath(matrix, 6, 7, x1, y1, x2, y2);
    cout << countPaths << "\n";
    return 0;
}