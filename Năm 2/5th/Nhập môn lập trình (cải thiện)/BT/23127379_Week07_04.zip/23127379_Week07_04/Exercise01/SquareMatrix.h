#pragma once
#include <iostream>
#include <string>
#include <string.h>
using namespace std;

#define MAX_LENGTH 100
void inputSquareMatrix(int matrix[][MAX_LENGTH], int n);
void outputSquareMatrix(int matrix[][MAX_LENGTH], int n);
void counterClockWise(int matrix[][MAX_LENGTH], int n);
bool isMagicSquare(int matrix[][MAX_LENGTH], int n);
