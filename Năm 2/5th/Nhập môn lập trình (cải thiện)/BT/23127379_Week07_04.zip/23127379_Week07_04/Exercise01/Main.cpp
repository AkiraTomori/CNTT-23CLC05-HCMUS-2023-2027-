#include "SquareMatrix.h"

int main()
{
    int n;
    cout << "Nhap vao kich thuoc cua ma tran vuong: ";
    cin >> n;
    int matrix[MAX_LENGTH][MAX_LENGTH];
    inputSquareMatrix(matrix, n);
    outputSquareMatrix(matrix, n);
    counterClockWise(matrix, n);
    cout << "Sau khi thuc hien phep xoay 90 do.\n";
    outputSquareMatrix(matrix, n);
    int m;
    cout << "Nhap vao kich thuoc m cua ma tran vuong thu hai: ";
    cin >> m;
    int matrix2[MAX_LENGTH][MAX_LENGTH];
    inputSquareMatrix(matrix2, m);
    outputSquareMatrix(matrix2, m);
    bool MagicSquare = isMagicSquare(matrix2, m);
    if (MagicSquare)
        cout << "Ma tran tren la ma phuong.\n";
    else
        cout << "Khong phai ma phuong.\n";
    return 0;
}