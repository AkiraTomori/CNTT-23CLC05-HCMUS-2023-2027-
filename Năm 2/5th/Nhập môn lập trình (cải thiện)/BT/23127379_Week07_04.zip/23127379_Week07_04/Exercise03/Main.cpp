#include "Secret.h"

int main()
{
    int arr[MAX_LENGTH];
    int matrix[MAX_LENGTH][MAX_LENGTH];
    cout << "Nhap so dong cua ma tran: ";
    int m; cin >> m;
    cout << "Nhap so cot cua ma tran: ";
    int n; cin >> n;
    inputMatrix(matrix, m, n);
    outputMatrix(matrix, m ,n);
    cout << "Nhap kich thuoc cua mang (kich thuoc nho hon cot cua ma tran): ";
    int p; cin >> p;
    inputArr(arr, p);
    outputArr(arr, p);
    cout << "Mat ma la: " << Decipher(matrix, m, n, arr, p);

    int B[][MAX_LENGTH] = {
        {3, 2, 1, 2, 3, 1},
        {3, 2, 1, 3, 2, 1},
        {2, 0, 2, 1, 7, 9},
        {1, 2, 3, 2, 1, 6}
    };
    int A[] = {3, 2, 1};
    int count = countAppearance(B, 4, 6, A, 3);
    cout << "So lan xuat hien cua mang A trong B: " << count << "\n";
    return 0;
}