#include "Secret.h"

void inputMatrix(int matrix[][MAX_LENGTH], int m, int n)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << "Nhap phan tu matrix[" << i + 1 << "][" << j + 1 << "]: ";
            cin >> matrix[i][j];
        }
    }
}
void outputMatrix(int matrix[][MAX_LENGTH], int m, int n)
{
    cout << "Danh sach cac phan tu trong ma tran: \n";
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << matrix[i][j] << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}
void inputArr(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap phan tu arr[" << i + 1 << "]: ";
        cin >> arr[i];
    }
}
void outputArr(int arr[], int n)
{
    cout << "Danh sach cac phan tu trong mang: \n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
int Decipher(int matrix[][MAX_LENGTH], int m, int n, int A[], int k)
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j + k - 1 < n; j++)
        {
            bool found = true;
            for (int idx = 0; idx < k; idx++)
            {
                if (A[idx] != matrix[i][j + idx])
                {
                    found = false;
                    break;
                }
            }
            if (found)
            {
                int sum = 0;
                for (int idx = j - 1; idx >= 0; idx--)
                {
                    sum += matrix[i][idx];
                }
                for (int idx = j + k; idx < n; idx++)
                {
                    sum += matrix[i][idx];
                }

                return sum;
            }
        }
    }
    return 0;
}
int countAtPos(int matrix[][MAX_LENGTH], int m, int n, int A[], int k, int i, int j)
{
    int count = 0;
    for (int idx = 0; idx < k; idx++)
    {
        if (matrix[i][j + idx] != A[idx])
        {
            break;
        }
        if (idx == k - 1)
        {
            count++;
        }
    }
    for (int idx = 0; idx < k; idx++)
    {
        if (matrix[i][j - idx] != A[idx])
            break;
        if (idx == k - 1)
            count++;
    }
    for (int idx = 0; idx < k; idx++)
    {
        if (matrix[i + idx][j] != A[idx])
            break;
        if (idx == k - 1)
            count++;
    }
    for (int idx = 0; idx < k; idx++)
    {
        if (matrix[i - idx][j] != A[idx])
            break;
        if (idx == k - 1)
            count++;
    }
    return count;
}  
int countAppearance(int matrix[][MAX_LENGTH], int m, int n, int A[], int k)
{
    int count = 0;
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            count += countAtPos(matrix, m, n, A, k, i, j);
        }
    }
    return count;
}