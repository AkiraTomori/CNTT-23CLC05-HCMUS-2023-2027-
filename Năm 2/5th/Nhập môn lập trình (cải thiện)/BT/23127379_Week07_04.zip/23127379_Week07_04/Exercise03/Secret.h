#pragma once

#include <iostream>
#include <string.h>
#include <string>
using namespace std;

#define MAX_LENGTH 100
void inputMatrix(int matrix[][MAX_LENGTH], int m, int n);
void outputMatrix(int matrix[][MAX_LENGTH], int m, int n);
void inputArr(int arr[], int n);
void outputArr(int arr[], int n);
int Decipher(int matrix[][MAX_LENGTH], int m, int n, int A[], int k);
int countAtPos(int matrix[][MAX_LENGTH], int m, int n, int A[], int k, int i, int j);
int countAppearance(int matrix[][MAX_LENGTH], int m, int n, int A[], int k);
