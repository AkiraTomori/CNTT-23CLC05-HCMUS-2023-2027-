#include "readFile.h"

int main()
{
    int n;
    int arr[MAX_LENGTH];
    readNumberFromFile("Files/input.txt", arr, n);
    double average = CalculateAverage(arr, n);
    writetoFiles("Files/output.json", arr, n, average);
    return 0;
}