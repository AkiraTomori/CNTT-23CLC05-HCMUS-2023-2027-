#pragma once
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <string.h>
using namespace std;

#define MAX_LENGTH 100
void readNumberFromFile(const string& filename, int arr[], int &n);
double CalculateAverage(int arr[], int n);
void writetoFiles(const string& filename, int arr[], int n, double average);