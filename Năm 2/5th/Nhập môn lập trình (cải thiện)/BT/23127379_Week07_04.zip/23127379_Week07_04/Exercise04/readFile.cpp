#include "readFile.h"

void readNumberFromFile(const string& filename, int arr[], int &n)
{
    ifstream fin(filename);
    if (fin.is_open())
    {
        fin >> n;
        for (int i = 0; i < n; i++)
        {
            fin >> arr[i];
        }
        fin.close();
    }
}
double CalculateAverage(int arr[], int n)
{
    double average = 0.0;
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > 0)
        {
            average += arr[i];
            count++;
        }
    }
    return (count == 0 ? 0 : static_cast<double>(average / count));
}
void writetoFiles(const string& filename, int arr[], int n, double average)
{
    ofstream fout(filename);
    if (fout.is_open())
    {
        fout << "{\n";
        fout << "\"DanhSach\": [";
        for (int i = 0; i < n; i++)
        {
            fout << arr[i];
            if (i < n - 1) fout << ", ";
        }
        fout << "],\n";
        fout << "\"TrungBinhCong\": " << fixed << setprecision(2) << average << "\n";
        fout << "}";
        fout.close();
    }
}