#include "Operation.h"

// Bài 1
void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap vao gia tri thu " << i + 1 << ": ";
        cin >> arr[i];
    }
}
// Bài 2
void outputArray(int arr[], int n)
{
    cout << "Gia tri cua tung phan tu trong mang.\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
// Bài 3
int FindMaximumValue(int arr[], int n)
{
    if (n == 0) return arr[0];
    int maxValue = arr[0];
    for (int i = 1; i < n; i++)
    {
        if (maxValue < arr[i])
        {
            maxValue = arr[i];
        }
    }
    return maxValue;
}
// Bài 4
int FindFirstEvenNumber(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        if (arr[i] % 2 == 0)
            return arr[i];
    }
    return -1;
}
// Bài 5
int FindSmallestEven(int arr[], int n)
{
    int minEven = -1;
    for (int i = 0; i < n; i++)
    {
        if (minEven == -1 || (minEven > arr[i] && arr[i] % 2 == 0))
        {
            minEven = arr[i];
        }
    }
    return minEven;
}