#include "Operation.h"

int main()
{
    int n;
    do
    {
        cout << "So luong phan tu cua mang can nhap: ";
        cin >> n;
        if (n <= 0)
        {
            cout << "So luong phan tu khong hop le.\n";
        }
    } while (n <= 0);
    int arr[MAX_LENGTH];
    int choice;
    bool isArrayInput = false;
    cout << "\nMenu:\n";
    cout << "1. Nhap phan tu cua mang.\n";
    cout << "2. In ra cac phan tu cua mang.\n";
    cout << "3. Tim gia tri lon nhat co trong mang.\n";
    cout << "4. Tim so chan dau tien xuat hien trong mang.\n";
    cout << "5. Tim so chan nho nhat xuat hien trong mang.\n";
    cout << "0. Thoat chuong trinh.\n";
    
    while (1)
    {
        cout << "Nhap vao lua chon cong viec can thuc hien: ";
        cin >> choice;
        switch(choice)
        {
            case 1:
                inputArray(arr, n);
                isArrayInput = true;
                break;
            case 2:
                if (isArrayInput)
                    outputArray(arr, n);
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 3:
                if (isArrayInput)
                    cout << "Gia tri lon nhat cua mang: " << FindMaximumValue(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 4:
                if (isArrayInput)
                    cout << "Gia tri chan dau tien xuat hien trong mang: " << FindFirstEvenNumber(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 5:
                if (isArrayInput)
                    cout << "Gia tri chan nho nhat xuat hien trong mang: " << FindSmallestEven(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 0:
                cout << "Chuong trinh thoat.\n";
                return 0;
        }
    }
    return 0;
}