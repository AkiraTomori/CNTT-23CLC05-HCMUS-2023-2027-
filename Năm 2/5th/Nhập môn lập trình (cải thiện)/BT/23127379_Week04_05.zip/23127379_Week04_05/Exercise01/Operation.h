#pragma once
#include <iostream>
#include <math.h>
#include <stdio.h>

using namespace std;
#define MAX_LENGTH 100
// Bài 1
void inputArray(int arr[], int n);
// Bài 2
void outputArray(int arr[], int n);
// Bài 3
int FindMaximumValue(int arr[], int n);
// Bài 4
int FindFirstEvenNumber(int arr[], int n);
// Bài 5
int FindSmallestEven(int arr[], int n);

