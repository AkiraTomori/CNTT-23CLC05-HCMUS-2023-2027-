#include "DirDistance.h"

void getFolders(const char path[], char folders[][MAX_LENGTH], int &count)
{
    const char separators[] = "/";
    strcpy(folders[0], separators);
    count++;

    int length = strlen(path);
    int start = 1;
    while (start < length)
    {
        const char *pos = strchr(path + start, '/');
        if (pos == nullptr)
            break;
        int nameLength = pos - (path + start);
        strncpy(folders[count], path + start, nameLength);
        folders[count][nameLength] = '\0';

        start = start + nameLength + 1;
        count++;
    }
}
int calcDirDistance(const char f1[], const char f2[])
{
    char folders[MAX_LENGTH][MAX_LENGTH];
    int count1 = 0;
    getFolders(f1, folders, count1);

    char folders2[MAX_LENGTH][MAX_LENGTH];
    int count2 = 0;
    getFolders(f2, folders, count2);

    for (int i = count1 - 1; i >= 0; i--)
    {
        if (i >= count2)
            continue;
        if (strcmp(folders[i], folders2[i]) == 0)
        {
            bool hasValidPath = true;
            for (int j = i - 1; j >= 0; j--)
            {
                if (strcmp(folders[j], folders2[j]) != 0)
                {
                    hasValidPath = false;
                    break;
                }
            }
            if (!hasValidPath)
                continue;
            int dist1 = count1 - i - 1;
            int dist2 = count2 - i - 1;
            return dist1 + dist2;
        }
    }
    return (count1 - 1) + (count2 - 1);
}