#include "Shapes.h"

int main()
{
    Triangle tri[MAX_LENGTH];
    int n1;

    Circle cir[MAX_LENGTH];
    int n2;

    read(tri, n1, cir, n2);
    for (int i = 0; i < n1; i++)
    {
        cout << tri[i] << "\n";
    }
    for (int i = 0; i < n2; i++)
    {
        cout << cir[i] << "\n";
    }
    return 0;
}