#pragma once
#include <iostream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <fstream>
using namespace std;

#define MAX_LENGTH 100
struct Point{
    double x;
    double y;

    friend ostream& operator << (ostream& out, const Point& p){
        out << "(" << p.x << ", " << p.y << ")";
        return out;
    }
};

struct Triangle{
    Point a;
    Point b;
    Point c;

    friend ostream& operator << (ostream& out, const Triangle& tri)
    {
        out << "Triangle: " << tri.a << ", " << tri.b << ", " << tri.c;
        return out;
    }
};

struct Circle{
    Point Center;
    double radius;

    friend ostream& operator << (ostream& out, const Circle& cir)
    {
        out << "Circle: " << cir.Center << ", " << cir.radius;
        return out;
    }
};

double readNumber(const char str[]);
Point readPoint(const char str[], int &next);
Triangle readTriangle(const char line[]);
Circle readCircle(const char line[]);
void read(Triangle tri[], int &n1, Circle cir[], int &n2);
