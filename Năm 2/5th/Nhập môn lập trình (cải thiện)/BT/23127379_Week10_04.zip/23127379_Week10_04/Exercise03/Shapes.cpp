#include "Shapes.h"

double readNumber(const char str[])
{
    double number;
    sscanf(str, "%lf", &number);
    return number;
}
Point readPoint(const char str[], int &next)
{
    Point p;

    const char* firstEnd = strchr(str, ',');
    p.x = readNumber(str + 1);
    p.y = readNumber(str + (firstEnd - str) + 2);

    const char* secondEnd = strchr(str + (firstEnd - str), ')');
    next += secondEnd - str;

    return p;
}
Triangle readTriangle(const char line[])
{
    Triangle t;

    int start = 4;
    t.a = readPoint(line + start, start);

    start += 3;
    t.b = readPoint(line + start, start);

    start += 3;
    t.c = readPoint(line + start, start);

    return t;
}
Circle readCircle(const char line[])
{
    Circle c;

    int start = 4;
    c.Center = readPoint(line + start, start);

    start += 3;
    c.radius = readNumber(line + start);

    return c;
}
void read(Triangle tri[], int &n1, Circle cir[], int &n2)
{
    FILE *files = fopen("Files/SHAPES.txt", "r");
    if (!files)
    {
        cerr << "Can't open file.\n";
        return;
    }
    char lines[MAX_LENGTH];
    n1 = n2 = 0;
    while (fgets(lines, sizeof(lines), files))
    {
        if (lines[1] == '0'){
            Triangle t = readTriangle(lines);
            tri[n1] = t;
            n1++;
        }
        else{
            Circle c = readCircle(lines);
            cir[n2] = c;
            n2++;
        }
    }
    fclose(files);
}