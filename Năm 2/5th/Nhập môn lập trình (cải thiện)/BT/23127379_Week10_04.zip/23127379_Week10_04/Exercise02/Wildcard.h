#pragma once
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
using namespace std;

#define MAX_LENGTH 100
void getTokens(const char s[], char tokens[][MAX_LENGTH], int &count);
int strmatch(const char s[], const char t[]);