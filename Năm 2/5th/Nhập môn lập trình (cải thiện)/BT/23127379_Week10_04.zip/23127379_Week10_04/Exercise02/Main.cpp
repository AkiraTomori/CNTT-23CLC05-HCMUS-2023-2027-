#include "Wildcard.h"

int main(){
    cout << "TRUE\n";

    string s = "app*";
    string t = "apple";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "*aaa*bbb*ccc*ddd*eee*";
    t = "aaaAAAbbbBBBcccCCCdddDDDeee";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "*ion";
    t = "lion";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "the*quick*fox";
    t = "the-quickfox";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "the*quick*fox";
    t = "the very quick brown fox";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "the*quick****fox";
    t = "the very quick brown fox";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    cout << "\nFALSE\n";

    s = "alp*";
    t = "apple";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "*ion";
    t = "lionee";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "the*quick*fox";
    t = " the-quickfox";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "*d*d";
    t = "d";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    s = "m*i*si*si*si*pi";
    t = "mississippi";
    cout << strmatch(s.c_str(), t.c_str()) << "\n";

    return 0;
}