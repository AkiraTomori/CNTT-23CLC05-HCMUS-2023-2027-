#include "Wildcard.h"

void getTokens(const char s[], char tokens[][MAX_LENGTH], int &count)
{
    int length = strlen(s);
    int start = 0;
    while (start < length)
    {
        const char *pos = strchr(s + start, '*');
        if (pos == nullptr)
            break;
        int tokenLength = pos - (s + start);
        if (tokenLength < 1)
        {
            start = start + tokenLength + 1;
            continue;
        }
        strncpy(tokens[count], s + start, tokenLength);
        tokens[count][tokenLength] = '\0';

        start = start + tokenLength + 1;
        count++;
    }
    int tokenLength = strlen(s + start);
    if (tokenLength > 0)
    {
        strcpy(tokens[count], s + start);
        count++;
    }
}
int strmatch(const char s[], const char t[])
{
    int sLength = strlen(s);
    int tlength = strlen(t);
    if (strchr(s, '*') == nullptr)
    {
        return strcmp(s, t) == 0;
    }
    for (int i = 0; i < sLength; i++)
    {
        if (s[i] == '*')
            break;
        if (i >= tlength || s[i] != t[i])
            return 0;
    }
    for (int i = sLength - 1, j = tlength - 1; i >= 0; i--, j--)
    {
        if (s[i] == '*')
            break;
        if (j < 0 || s[i] != t[j])
            return 0;
    }
    char tokens[MAX_LENGTH][MAX_LENGTH];
    int count = 0;
    getTokens(s, tokens, count);
    int start = 0;
    for (int i = 0; i < count; i++)
    {
        const char *current = strstr(t + start, tokens[i]);
        if (current == nullptr)
            return 0;
        start = (current - t) + strlen(tokens[i]);
    }
    return 1;
}