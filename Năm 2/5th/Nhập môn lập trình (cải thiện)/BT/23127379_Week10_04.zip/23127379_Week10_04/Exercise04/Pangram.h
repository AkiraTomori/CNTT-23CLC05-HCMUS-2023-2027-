#pragma once
#include <iostream>
#include <string.h>
#include <string>
using namespace std;

#define MAX_LENGTH 100
bool isPangram(const char str[]);
void printMissingCharacters(const char str[]);
