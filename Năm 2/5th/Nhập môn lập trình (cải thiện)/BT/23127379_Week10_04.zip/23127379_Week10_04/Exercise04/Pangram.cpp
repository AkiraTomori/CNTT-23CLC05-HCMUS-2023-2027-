#include "Pangram.h"

bool isPangram(const char str[])
{
    bool alphabet[26] = {false};
    int index = 0;
    for (int i = 0; str[i] != '\0'; i++)
    {
        if ('A' <= str[i] && str[i] <= 'Z')
        {
            index = str[i] - 'A';
        }
        else if ('a' <= str[i] && str[i] <= 'z')
        {
            index = str[i] - 'a';
        }
        else{
            continue;
        }
        alphabet[index] = true;
    }
    for (int i = 0; i < 26; i++)
    {
        if (!alphabet[i])
            return false;
    }
    return true;
}
void printMissingCharacters(const char str[])
{
    bool alphabet[26] = {false};
    int index = 0;
    for (int i = 0; str[i] != '\0'; i++)
    {
        if ('A' <= str[i] && str[i] <= 'Z')
        {
            index = str[i] - 'A';
        }
        else if ('a' <= str[i] && str[i] <= 'z')
        {
            index = str[i] - 'a';
        }
        else{
            continue;
        }
        alphabet[index] = true;
    }
    cout << "Nhung ki tu con thieu: ";
    for (int i = 0; i < 26; i++)
    {
        if (!alphabet[i])
        {
            cout << char(i + 'a') << " ";
        }
    }
    cout << "\n";
}