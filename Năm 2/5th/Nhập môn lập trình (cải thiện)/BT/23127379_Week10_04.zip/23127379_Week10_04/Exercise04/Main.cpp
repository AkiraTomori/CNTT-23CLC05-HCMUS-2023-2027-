#include "Pangram.h"

int main()
{
    char pangram[MAX_LENGTH];
    cout << "Nhap chuoi de kiem tra: ";
    cin.getline(pangram, MAX_LENGTH);
    if (isPangram(pangram))
    {
        cout << "Chuoi tren la pangram.\n";
    }
    else{
        cout << "Chuoi tren khong la pangram.\n";
        printMissingCharacters(pangram);
    }
    return 0;
}