#pragma once
#include <iostream>
#include <math.h>
#include <stdio.h>

using namespace std;
#define MAX_LENGTH 100
// Bài 1
void inputArray(int arr[], int n);
// Bài 2
void outputArray(int arr[], int n);
// Bài 3
int FindMaximumValue(int arr[], int n);
// Bài 4
int FindFirstEvenNumber(int arr[], int n);
// Bài 5
int FindSmallestEven(int arr[], int n);
// Bài 6
int FindPositionOfSmallestEven(int arr[], int n);
// Bai 7
int Max(int a, int b);
int FindXContainsAllValuesInTheArray(int arr[], int n);
// Bai 8
bool isPowerOfTwo(int n);
int FindTheFirstValueIsPowerOfTwo(int arr[], int n);
// Bai 9
void FindSpecialValues(int arr[], int n);
// Bai 10
void FindLargestEvenPositions(int arr[], int n);
// Bai 11
bool isFirstDigitOdd(int n);
int CalculateSumWithFirstOddDigit(int arr[], int n);
// Bai 12
double CalculateAveragePositiveNumber(int arr[], int n);
// Bai 13
bool isPrime(int n);
int CountPrimeNumber(int arr[], int n);
// Bai 14
int CountDistinctValues(int arr[], int n);
// Bai 15
void listFrequencies(int arr[], int n);
// Bai 16
void listUniqueValues(int arr1[], int n, int arr2[], int m);
// Bai 17
bool isSorted(int arr[], int n);
// Bai 18
bool isArithmeticSequence(int arr[], int n);
int getArithmeticNumber(int arr[], int n);
// Bai 19
void sortArray(int arr[], int n);
// Bai 20
void sortOddNumber(int arr[], int n);
// Bai 21
bool isPermutation(int a[], int b[], int n);
// Bai 22
void mergeArray(int a[], int m, int b[], int n, int result[]);
// Bai 23
void insertElement(int arr[], int &n, int x, int k);
// Bai 24
void insertAtSortedPosition(int arr[], int &n, int x);
// Bai 25
void deleteElement(int arr[], int &n, int x);