#include "Cinema.h"

int main()
{
    cout << "Nhap vao so luong ve: ";
    int n; cin >> n;
    Ticket tickets[MAX_LENGTH];
    cin.ignore();
    inputTicket(tickets, n);
    cout << "Nhap vao gio: ";
    int hh; cin >> hh;
    cout << "Nhap vao phut: ";
    int mm; cin >> mm;
    cout << "Tong doanh thu theo gio " << hh << "va phut " << mm << "la: " << calculateRevenue(tickets, n, hh, mm);
    return 0; 
}