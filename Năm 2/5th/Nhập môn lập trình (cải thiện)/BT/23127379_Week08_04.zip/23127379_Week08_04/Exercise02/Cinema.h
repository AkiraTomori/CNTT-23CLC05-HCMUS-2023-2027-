#pragma once
#include <iostream>
#include <string.h>
#include <string>
using namespace std;

#define MAX_LENGTH 100
struct Ticket
{
    char FilmName[101];
    int hour;
    int minutes;
    char CinemaName[101];
    int FoodPrice;
    double factor;
};

void inputTicket(Ticket tickets[], int n);
double calculateTicketPrice(const Ticket &ticket);
double calculateRevenue(Ticket tickets[], int n, int hh, int mm);