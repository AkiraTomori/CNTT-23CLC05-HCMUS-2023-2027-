#include "Cinema.h"

void inputTicket(Ticket tickets[], int n){
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap thong tin ve " << i + 1 << ": \n";
        cout << "Ten phim: ";
        cin.getline(tickets[i].FilmName, 100);
        cout << "Gio bat dau: ";
        cin >> tickets[i].hour;
        cout << "Phut bat dau: ";
        cin >> tickets[i].minutes;
        cin.ignore();
        cout << "Ten rap phim: ";
        cin.getline(tickets[i].CinemaName, 100);
        cout << "Gia thuc an kem: ";
        cin >> tickets[i].FoodPrice;
        cout << "He so ve (1.0 ve thuong, 1.5 cho ve combo): ";
        cin >> tickets[i].factor;
        cin.ignore();
    }
}
double calculateTicketPrice(const Ticket &ticket){
    if (ticket.factor == 1.5)
        return (ticket.factor * 80000 + ticket.FoodPrice) * 0.9;
    return (ticket.factor * 80000 + ticket.FoodPrice);
}
double calculateRevenue(Ticket tickets[], int n, int hh, int mm){
    double totalRevenue = 0.0;
    for (int i = 0; i < n; i++)
    {
        if (tickets[i].hour == hh || tickets[i].minutes == mm)
        {
            totalRevenue += calculateTicketPrice(tickets[i]);
        }
    }
    return totalRevenue;
}