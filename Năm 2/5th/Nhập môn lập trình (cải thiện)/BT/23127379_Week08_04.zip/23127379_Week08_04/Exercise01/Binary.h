#pragma once
#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;

unsigned int convert(char bin[]);