#include "Order.h"

int main()
{
    Package packages[MAX_LENGTH];

    int size;
    readOrders(packages, size);

    char deliveryDist[] = "Q12";
    writePackages(packages, size, deliveryDist);

    return 0;
}