#pragma once
#include <iostream>
#include <string.h>
#include <string>
using namespace std;

struct Package
{
    char idOrder[18];
    char receiver[16];
    char address[51];
    char phone[11];
    double weight;
};
#define MAX_LENGTH 100
void readOrders(Package packages[], int &size);
void writePackages(Package Packages[], int size, char deliveryDist[]);
