#include "Order.h"

void readOrders(Package packages[], int &size)
{
    size = 0;
    FILE *pFile = fopen("Files/input.txt", "r");
    if (pFile == nullptr)
        return;
    const int MAX = 200;
    char line[MAX];
    bool isFirstLine = true;
    while (fgets(line, MAX, pFile) != nullptr)
    {
        if (isFirstLine)
        {
            isFirstLine = false;
            continue;
        }
        Package p;
        sscanf(line, "%[^|]|%[^|]|%[^|]|%[^|]|%lf", p.idOrder, p.receiver, p.address, p.phone, &p.weight);

        packages[size++] = p;
    }
    fclose(pFile);
}
void writePackages(Package Packages[], int size, char deliveryDist[])
{
    FILE *pFile = fopen("Files/output.txt", "w");
    if (pFile == nullptr)
        return;
    fputs("Ma don hang|Ten nguoi nhan|Dia chi|So dien thoai|Khoi luong\n", pFile);
    for (int i = 0; i < size; i++)
    {
        Package p = Packages[i];
        char *address = p.address;
        char temp[51];
        char district[51];

        sscanf(address, "%[^,], %[^,], %[^,], %[^,]", temp, temp, temp, district);
        if (strcmp(district, deliveryDist) == 0)
        {
            fprintf(pFile, "%s|%s|%s|%s|%.1lf\n", p.idOrder, p.receiver, p.address, p.phone, p.weight);
        }
    }
    fclose(pFile);
}