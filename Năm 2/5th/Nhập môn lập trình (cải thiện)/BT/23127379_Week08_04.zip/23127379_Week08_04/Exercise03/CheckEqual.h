#pragma once
#include <iostream>
#include <string.h>
using namespace std;

#define MAX_LENGTH 100
long long getValue(char str[]);
bool CheckEqual(char first[], char second[], char target[]);

