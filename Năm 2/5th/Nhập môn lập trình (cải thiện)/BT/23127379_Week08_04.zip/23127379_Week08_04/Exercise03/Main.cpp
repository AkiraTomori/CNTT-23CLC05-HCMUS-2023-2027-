#include "CheckEqual.h"

int main()
{
    cout << "Nhap vao kich thuoc cua chuoi dau tien: ";
    int n; cin >> n;
    cout << "Nhap vao chuoi 1: ";
    char first[MAX_LENGTH];
    cin.ignore();
    cin.getline(first, n + 1);

    cout << "Nhap vao kich thuoc cua chuoi thu hai: ";
    int m; cin >> m;
    cout << "Nhap vao chuoi 2: ";
    char second[MAX_LENGTH];
    cin.ignore();
    cin.getline(second, m + 1);

    cout << "Nhap vao kich thuoc cua chuoi thu 3: ";
    int p; cin >> p;
    cout << "Nhap vao chuoi 3: ";
    char target[MAX_LENGTH];
    cin.ignore();
    cin.getline(target, p + 1);

    bool isEqualTarget = CheckEqual(first, second, target);
    if (isEqualTarget)
    {
        cout << "Bang nhau\n";
    }
    else
        cout << "Khong bang nhau\n";
    return 0;
}