#include "CheckEqual.h"

long long getValue(char str[])
{
    long long sum = 0;
    long long factor = 1;
    int n = strlen(str);
    for (int i = n - 1; i >= 0; i--)
    {
        int value = str[i] - 'a';
        sum = sum + value * factor;
        if (value < 10)
        {
            factor *= 10;
        }
        else
        {
            factor *= 100;
        }
    }
    return sum;
}
bool CheckEqual(char first[], char second[], char target[])
{
    return getValue(first) + getValue(second) == getValue(target);
}