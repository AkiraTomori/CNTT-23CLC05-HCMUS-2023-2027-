#include "SquareMatrix.h"

void inputSquareMatrix(int matrix[][MAX_LENGTH], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << "Nhap phan tu matrix[" << i + 1 << "][" << j + 1 << "]: ";
            cin >> matrix[i][j];
        }
    }
}
void outputSquareMatrix(int matrix[][MAX_LENGTH], int n)
{
    cout << "Danh sach cac phan tu trong ma tran: \n";
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << matrix[i][j] << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}
void counterClockWise(int matrix[][MAX_LENGTH], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = i; j < n; j++)
        {
            swap(matrix[i][j], matrix[j][i]);
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n / 2; j++)
        {
            swap(matrix[i][j], matrix[i][n - 1 - j]);
        }
    }
}
bool isMagicSquare(int matrix[][MAX_LENGTH], int n)
{
    if (n == 0) return false;
    int rowSum[n] = {0};
    int colSum[n] = {0};
    int mainDiagonalSum = 0, subDiagonalSum = 0;

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            rowSum[i] += matrix[i][j];
            colSum[j] += matrix[i][j];
            if (i == j) mainDiagonalSum += matrix[i][j];
            if (i + j == n - 1) subDiagonalSum += matrix[i][j];
        }
    }
    int sumRef = rowSum[0];
    for (int i = 0; i < n; i++)
    {
        if (rowSum[i] != sumRef || colSum[i] != sumRef)
            return false;
    }
    if (mainDiagonalSum != sumRef || subDiagonalSum != sumRef)
        return false;
    return true;
}