#include "Binary.h"

unsigned int convert(char bin[])
{
    unsigned int sum = 0;
    int n = strlen(bin);
    for (int i = 0; bin[i] != '\0'; i++)
    {
        sum = sum * 2 + (bin[i] - '0');
    }
    return sum;
}