#include "Binary.h"

int main()
{
    char bin[100];
    cout << "Nhap kich thuoc chuoi nhi phan: ";
    int n;
    cin >> n;
    cout << "Nhap chuoi nhi phan: ";
    cin.ignore();
    cin.getline(bin, n + 1);
    unsigned int sum = convert(bin);
    cout << "Chuan hoa ve tong: "<< sum << "";
    return 0;
}