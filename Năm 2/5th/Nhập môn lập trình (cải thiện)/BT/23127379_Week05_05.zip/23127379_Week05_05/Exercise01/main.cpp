#include "Operation.h"

int main()
{
    int n;
    do
    {
        cout << "So luong phan tu cua mang can nhap: ";
        cin >> n;
        if (n <= 0)
        {
            cout << "So luong phan tu khong hop le.\n";
        }
    } while (n <= 0);
    int arr[MAX_LENGTH];
    int choice;
    bool isArrayInput = false;
    cout << "\nMenu:\n";
    cout << "1. Nhap phan tu cua mang.\n";
    cout << "2. In ra cac phan tu cua mang.\n";
    // cout << "3. Tim gia tri lon nhat co trong mang.\n";
    // cout << "4. Tim so chan dau tien xuat hien trong mang.\n";
    // cout << "5. Tim so chan nho nhat xuat hien trong mang.\n";
    // cout << "6. Tim vi tri cua so chan nho nhat trong mang.\n";
    // cout << "7. Tim gia tri x sao cho gia tri do chua toan bo cac gia tri khac trong mang.\n";
    // cout << "8. Tim gia tri dau tien co dang 2^k.\n";
    // cout << "9. Liet ke nhung gia tri ma phan tu do lon hon tri tuyet doi truoc no va nho hon tri tuyet doi sau no.\n";
    // cout << "10. Liet ke vi tri cua so chan lon nhat xuat hien trong mang.\n";
    // cout << "11. Tinh tong gia tri ma phan tu co gia tri le o dau.\n";
    // cout << "12. Tinh trung binh cac phan tu duong.\n";
    // cout << "13. Dem so luong so nguyen to trong mang.\n";
    // cout << "14. Dem so luong phan tu phan biet trong mang.\n";
    // cout << "15. Liet ke tan suat xuat hien cua tung phan tu.\n";
    // cout << "16. Liet ke danh sach cac phan tu chi xuat hien o tung mang.\n";
    // cout << "17. Kiem tra mang co duoc sap xep tang dan khong.\n";
    // cout << "18. Kiem tra xem mang co phai la mot day cap so cong khong va tim cong sai neu co.\n";
    // cout << "19. Sap xep mang theo thu tu tang dan.\n";
    // cout << "20. Sap xep mang voi so le tang dan con lai giu nguyen.\n";
    // cout << "21. Kiem tra xem mot mang cung phan tu la phai la hoan vi khong.\n";
    // cout << "22. Gop hai mang thanh 1 mang xep tang.\n";
    // cout << "23. Them 1 phan tu vao mang.\n";
    // cout << "24. Them 1 phan tu vao mang nhung van giu nguyen gia tri tang dan.\n";
    // cout << "25. Xoa 1 phan tu bat ki trong mang.\n";
    cout << "26. Xoa cac phan tu bang voi mot gia tri duoc nhap.\n";
    cout << "27. Xoa cac phan tu trung trong mang.\n";
    cout << "28. Xoay trai mang k lan.\n";
    cout << "29. Xoay phai mang k lan.\n";
    cout << "30. Tao 1 mang tu cac so nguyen to cua mang ban dau.\n";
    cout << "0. Thoat chuong trinh.\n";
    
    while (1)
    {
        cout << "Nhap vao lua chon cong viec can thuc hien: ";
        cin >> choice;
        switch(choice)
        {
            case 1:
                inputArray(arr, n);
                isArrayInput = true;
                break;
            case 2:
                if (isArrayInput)
                    outputArray(arr, n);
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 3:
                if (isArrayInput)
                    cout << "Gia tri lon nhat cua mang: " << FindMaximumValue(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 4:
                if (isArrayInput)
                    cout << "Gia tri chan dau tien xuat hien trong mang: " << FindFirstEvenNumber(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 5:
                if (isArrayInput)
                    cout << "Gia tri chan nho nhat xuat hien trong mang: " << FindSmallestEven(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (Lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 6:
                if (isArrayInput)
                    cout << "Vi tri cua so chan nho nhat: " << FindPositionOfSmallestEven(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 7:
                if (isArrayInput)
                    cout << "Gia tri x chua tat ca gia tri cua mot mang: " << FindXContainsAllValuesInTheArray(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 8:
                if (isArrayInput)
                    cout << "Gia tri dau tien co dang 2^k: " << FindTheFirstValueIsPowerOfTwo(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 9:
                if (isArrayInput)
                    FindSpecialValues(arr, n);
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 10:
                if (isArrayInput)
                    FindLargestEvenPositions(arr, n);
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 11:
                if (isArrayInput)
                    cout << "Tong cac phan tu ma so dau tien cua phan tu do la so le: " << CalculateSumWithFirstOddDigit(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 12:
                if (isArrayInput)
                    cout << "Trung binh cac phan tu duong trong mang: "<< CalculateAveragePositiveNumber(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 13:
                if (isArrayInput)
                    cout << "So luong so nguyen to co trong mang: " << CountPrimeNumber(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 14:
                if (isArrayInput)
                    cout << "So luong cac phan tu phan biet o trong mang: " << CountDistinctValues(arr, n) << "\n";
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 15:
                if (isArrayInput)
                    listFrequencies(arr, n);
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien nhiem vu.\n";
                break;
            case 16:
                if (isArrayInput)
                {
                    cout << "Nhap vao so luong phan tu cua mang thu hai: ";
                    int m; cin >> m;
                    int b[MAX_LENGTH];
                    inputArray(b, m);
                    listUniqueValues(arr, n, b, m);
                }
                else
                {
                    cout << "Hay nhap cac phan tu cua mang thu nhat truoc khi thuc hien cong viec.\n";
                }
                break;
            case 17:
                if (isArrayInput)
                {
                    if (isSorted(arr, n))
                        cout << "Mang duoc sap xep tang dan.\n";
                    else
                        cout << "Mang khong duoc sap xep tang dan.\n";
                }
                else
                    cout << "Hay nhap cac phan tu (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 18:
                if (isArrayInput)
                {
                    if (isArithmeticSequence(arr, n))
                    {
                        cout << "Mang la 1 day cap so cong.\n";
                        cout << "Cong sai la: " << getArithmeticNumber(arr, n) << "\n";
                    }
                    else
                    {
                        cout << "Mang khong phai la day cap so cong va cong sai bang 0.\n";
                    }
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 19:
                if (isArrayInput)
                {
                    sortArray(arr, n);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 20:
                if (isArrayInput)
                {
                    sortOddNumber(arr, n);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 21:
                if (isArrayInput)
                {
                    cout << "Hay nhap so luong phan tu cua mang thu hai (cung so luong phan tu voi mang thu nhat): ";
                    int m; cin >> m;
                    int b[MAX_LENGTH];
                    inputArray(b, m);
                    if (isPermutation(arr, b, n))
                        cout << "Hai mang la hoan vi cua nhau.\n";
                    else
                        cout << "Khong phai la hoan vi cua nhau.\n";
                }
                else
                    cout << "Hay nhap cac phan tu cua mang thu nhat truoc khi thuc hien cong viec.\n";
                break;
            case 22:
                if (isArrayInput)
                {
                    cout << "Hay nhap so luong cac phan tu cua mang thu hai: ";
                    int m; cin >> m;
                    int b[MAX_LENGTH];
                    inputArray(b, m);
                    int c[n + m];
                    sortArray(arr, n);
                    sortArray(b, m);
                    mergeArray(arr, n, b, m, c);
                    outputArray(c, n + m);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang thu nhat truoc khi thuc hien cong viec.\n";
                break;
            case 23:
                if (isArrayInput)
                {
                    cout << "Nhap vao vi tri phan tu can duoc them vao: ";
                    int k; cin >> k;
                    if (k < 0 || k > n)
                    {
                        cout << "Vi tri khong hop le.\n";
                        break;
                    }
                    cout << "Nhap vao gia tri phan tu muon them vao: ";
                    int x; cin >> x;
                    insertElement(arr, n, x, k);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 24:
                if (isArrayInput)
                {
                    cout << "Nhap vao gia tri phan tu muon them vao: ";
                    int x; cin >> x;
                    insertAtSortedPosition(arr, n, x);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 25:
                if (isArrayInput)
                {
                    cout << "Nhap vao vi tri phan tu can xoa: ";
                    int k; cin >> k;
                    if (k < 0 || k > n)
                    {
                        cout << "Vi tri khong hop le.\n";
                        break;
                    }
                    deleteElement(arr, n, k);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 26:
                if (isArrayInput)
                {
                    cout << "Nhap vao gia tri muon xoa khoi mang.\n";
                    int x; cin >> x;
                    deleteElements(arr, n, x);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 27:
                if (isArrayInput)
                {
                    removeDupclicates(arr, n);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 28:
                if (isArrayInput)
                {
                    cout << "So lan xoay mang ve ban trai: ";
                    int k; cin >> k;
                    leftRotate(arr, n, k);
                    outputArray(arr, n);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 29:
                if (isArrayInput)
                {
                    cout << "So lan xoay mang ve ben phai: ";
                    int k; cin >> k;
                    rightRotate(arr, n, k);
                    outputArray(arr, n);
                }
                else
                {
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                }
                break;
            case 30:
                if (isArrayInput)
                {
                    int b[MAX_LENGTH];
                    int m;
                    createArrayFromPrimeNumber(arr, n, b, m);
                    outputArray(b, m);
                }
                else
                    cout << "Hay nhap cac phan tu cua mang (lua chon 1) truoc khi thuc hien cong viec.\n";
                break;
            case 0:
                cout << "Chuong trinh thoat.\n";
                return 0;
        }
    }
    return 0;
}