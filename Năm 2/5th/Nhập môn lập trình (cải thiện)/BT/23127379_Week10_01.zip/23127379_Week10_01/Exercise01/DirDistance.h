#pragma once
#include <iostream>
#include <string.h>
#include <string>
using namespace std;

#define MAX_LENGTH 100
void getFolders(const char path[], char folders[][MAX_LENGTH], int &count);
int calcDirDistance(const char f1[], const char f2[]);