#include "DirDistance.h"

int main()
{
    string f1 = "/dirA/file1";
    string f2 = "/dirB/file2";
    string f3 = "/dirB/dirC/file3";
    string f4 = "/dirB/dirC/file4";

    string f5 = "/dirB/dirB/file5";
    string f6 = "/dirD/dirC/file6";

    cout << calcDirDistance(f4.c_str(), f3.c_str()) << "\n";
    cout << calcDirDistance(f4.c_str(), f2.c_str()) << "\n";
    cout << calcDirDistance(f4.c_str(), f1.c_str()) << "\n";
    cout << calcDirDistance(f2.c_str(), f1.c_str()) << "\n";

    cout << calcDirDistance(f5.c_str(), f4.c_str()) << "\n"; 
    cout << calcDirDistance(f6.c_str(), f4.c_str()) << "\n"; 

    return 0;
}