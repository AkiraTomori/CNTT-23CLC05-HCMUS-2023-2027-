#pragma once

#include <iostream>
using namespace std;

void inputNumber(double &grade);
void checkGrade(double grade);