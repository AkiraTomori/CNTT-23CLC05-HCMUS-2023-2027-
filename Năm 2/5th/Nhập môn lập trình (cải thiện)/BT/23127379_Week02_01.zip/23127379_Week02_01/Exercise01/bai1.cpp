#include "bai1.h"

void inputTriangle(int &a, int &b, int &c){
    cout << "Nhap vao canh thu nhat: ";
    cin >> a;
    cout << "Nhap vao canh thu hai: ";
    cin >> b;
    cout << "Nhap vao canh thu ba: ";
    cin >> c;
}
bool checkValidTriangle(int a, int b, int c){
    if (a < b + c && b < a + c && c < a + b){
        return 1;
    }
    return 0;
}

int PerimeterOfTriangle(int a, int b, int c){
    int perimeter = 0;
    if (checkValidTriangle(a, b, c)){
        perimeter = (a + b + c);
    }
    return perimeter;
}

double AreaOfTriangle(int a, int b, int c){
    double Area = 0.0;
    if (checkValidTriangle(a, b, c)){
        double p = (a + b + c) * (1.0) / 2;
        Area = sqrt(p * (p - a) * (p - b) * (p - c));
    }
    return Area;
}