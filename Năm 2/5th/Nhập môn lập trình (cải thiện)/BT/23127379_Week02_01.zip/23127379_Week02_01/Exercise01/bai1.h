#pragma once

#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;
void inputTriangle(int &a, int &b, int &c);
bool checkValidTriangle(int a, int b, int c);
int PerimeterOfTriangle(int a, int b, int c);
double AreaOfTriangle(int a, int b, int c);
