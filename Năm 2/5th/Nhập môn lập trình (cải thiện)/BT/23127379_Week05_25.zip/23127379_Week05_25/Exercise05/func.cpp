#include "func.h"

void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Phan tu " << i + 1 << ": ";
        cin >> arr[i];
    }
}
void outputArray(int arr[], int n)
{
    cout << "Danh sach cac phan tu: \n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
// Yeu cau 1
void printNumsEqualSum(int arr[], int n)
{
    cout << "Danh sach cac phan tu bang tong cac phan tu truoc no: \n";
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        if (sum == arr[i])
            cout << arr[i] << " ";
        sum += arr[i];
    }
    cout << "\n";
}
// Yeu cau 2
bool isPrime(int n)
{
    if (n < 2) return false;
    int canBac2CuaN = sqrt(n);
    for (int i = 2; i <= canBac2CuaN; i++)
    {
        if (n % i == 0)
            return false;
    }
    return true;
}
void removePrimeNums(int arr[], int &n)
{
    int newSize = 0;
    for (int i = 0; i < n; i++)
    {
        if (!isPrime(arr[i]))
        {
            arr[newSize++] = arr[i];
        }
    }
    n = newSize;
}

// Yeu cau 3
// 215 -83 476
// 521 -38 764
void generateRotations(int num, int rotations[], int &count)
{
    char str[12];
    int temp = abs(num);
    sprintf(str, "%d", temp);

    int len = strlen(str);
    count = 0;
    for (int i = 0; i < len; i++)
    {
        char rotated[12];
        strncpy(rotated, str + i, len - i);
        strncpy(rotated + (len - i), str, i);
        rotated[len] = '\0';
        
        int rotatedNum = atoi(rotated);
        if (num < 0) rotatedNum *= -1;
        rotations[count++] = rotatedNum;
    }
}
long long biggestSumRotated(int arr[], int n)
{
    long long sum = 0;
    for (int i = 0; i < n; i++)
    {
        int rotations[10];
        int count = 0;

        generateRotations(arr[i], rotations, count);

        int maxVal = rotations[0];
        for (int j = 1; j < count; j++)
        {
            if (rotations[j] > maxVal)
                maxVal = rotations[j];
        }
        sum += maxVal;
    }
    return sum;
}