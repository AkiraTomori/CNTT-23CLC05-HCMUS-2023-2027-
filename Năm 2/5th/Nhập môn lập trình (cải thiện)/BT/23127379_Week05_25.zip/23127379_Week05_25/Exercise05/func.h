#pragma once

#include <iostream>
#include <math.h>
#include <string.h>
#include <string>

using namespace std;
#define MAX_LENGTH 100

void inputArray(int arr[], int n);
void outputArray(int arr[], int n);
// Yeu cau 1
void printNumsEqualSum(int arr[], int n);
// Yeu cau 2
bool isPrime(int n);
void removePrimeNums(int arr[], int &n);
// Yeu cau 3
void generateRotations(int num, int rotations[], int &count);
long long biggestSumRotated(int arr[], int n);
