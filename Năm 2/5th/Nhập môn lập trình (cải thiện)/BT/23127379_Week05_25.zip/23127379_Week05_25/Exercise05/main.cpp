#include "func.h"

int main()
{
    int n;
    do
    {
        cout << "Nhap vao gia tri n cua mang thu nhat: ";
        cin >> n;
        if (n < 0)
        {
            cout << "Gia tri n nhap vao khong hop le.\n";
        }
    } while (n < 0);
    
    int arr[MAX_LENGTH];
    inputArray(arr, n);
    outputArray(arr, n);
    printNumsEqualSum(arr, n);
    
    int m;
    do
    {
        cout << "Nhap vao gia tri m cua mang thu hai: ";
        cin >> m;
        if (m < 0)
        {
            cout << "Gia tri m nhap vao khong hop le.\n";
        }
    } while (m < 0);
    int arr2[MAX_LENGTH];
    inputArray(arr2, m);
    outputArray(arr2, m);
    removePrimeNums(arr2, m);
    outputArray(arr2, m);
    int p;
    do
    {
        cout << "Nhap vao gia tri p cua mang thu ba: ";
        cin >> p;
        if (p < 0)
        {
            cout << "Gia tri p nhap vao khong hop le.\n";
        }
    } while (p < 0);
    int arr3[MAX_LENGTH];
    inputArray(arr3, p);
    outputArray(arr3, p);

    cout << "Tong xoay vong lon nhat: " << biggestSumRotated(arr3, p) << "\n";
    return 0;
}