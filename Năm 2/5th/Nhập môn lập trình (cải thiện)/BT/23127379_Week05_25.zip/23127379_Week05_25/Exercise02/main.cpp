#include "func.h"

int main()
{
    int n;
    do
    {
        cout << "Nhap vao gia tri n cua mang thu nhat: ";
        cin >> n;
        if (n < 0)
        {
            cout << "Gia tri n nhap vao khong hop le.\n";
        }
    } while (n < 0);
    // Phan 1
    int score[MAX_LENGTH];
    inputArray(score, n);
    outputArray(score, n);
    int status1;
    restorePoints(score, n, status1);
    outputArray(score, n);
    // Phan 2
    int m;
    do
    {
        cout << "Nhap vao gia tri m cua mang thu hai: ";
        cin >> m;
        if (m < 0)
        {
            cout << "Gia tri n nhap vao khong hop le.\n";
        }
    } while (m < 0);
    int score1[MAX_LENGTH];
    int start2, end2;
    inputArray(score1, m);
    outputArray(score1, m);
    findLongestArithmeticSubArray(score1, m, start2, end2);
    cout << "Start = " << start2 << "\n";
    cout << "End = " << end2 << "\n";
    return 0;
}