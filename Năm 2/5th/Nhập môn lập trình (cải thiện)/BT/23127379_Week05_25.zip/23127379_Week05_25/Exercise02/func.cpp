#include "func.h"

void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap vao gia tri thu " << i + 1 << ": ";
        cin >> arr[i];
    }
}
void outputArray(int arr[], int n)
{
    cout << "Gia tri cua cac phan tu trong mang.\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
// 30 -1 70 90 -> 30 50 70 90 

void restorePoints(int score[], int n, int &status)
{
    int idx = -1;
    for (int i = 0; i < n; i++)
    {
        if (score[i] == -1)
        {
            idx = i;
            break;
        }
    }
    if (idx == -1)
    {
        status = 0;
        return;
    }

    int prev = (idx > 0) ? score[idx - 1] : -1;
    int next = (idx < n - 1) ? score[idx + 1] : -1;
    if (prev != -1 && next != -1)
    {
        int diff = (next - prev) / 2;
        if (prev + diff == next - diff)
        {
            score[idx] = prev + diff;
            status = 1;
            return;
        }
    }
    status = 0;
}
// 0 10 20 40 60 100
void findLongestArithmeticSubArray(int score[], int n, int &start, int &end)
{
    int maxLength = 0;
    start = -1, end = -1;
    for (int i = 0; i < n - 2; i++)
    {
        int diff = score[i + 1] - score[i];
        int j = i + 1;
        while (j < n - 1 && score[j + 1] - score[j] == diff)
            j++;
        if (j - i + 1 >= 3)
        {
            if (j - i + 1 > maxLength || (j - i + 1 == maxLength && i > start))
            {
                maxLength = j - i + 1;
                start = i;
                end = j;
            }
        }
    }
}