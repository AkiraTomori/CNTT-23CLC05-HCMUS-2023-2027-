#pragma once

#include <iostream>
#include <math.h>
#include <string.h>
using namespace std;

#define MAX_LENGTH 100
void inputArray(int arr[], int n);
void outputArray(int arr[], int n);
void restorePoints(int score[], int n, int &status);
void findLongestArithmeticSubArray(int score[], int n, int &start, int &end);