#include "func.h"

int main()
{
    // Phan 1
    int n;
    do
    {
        cout << "Nhap vao gia tri n cua mang thu nhat: ";
        cin >> n;
        if (n < 0)
            cout << "Gia tri nhap vao khong hop le.\n";
    } while (n < 0);
    int arr[MAX_LENGTH];
    inputArray(arr, n);
    outputArray(arr, n);
    bool checkEvenOddThree = checkThreeEvenOdd(arr, n);
    if (checkEvenOddThree)
    {
        cout << "Mang co chua 3 gia tri chan hoac le lien tiep trong mang.\n";
    }
    else
    {
        cout << "Mang khong co chua 3 gia tri chan hoac le lien tiep trong mang.\n";
    }
    // Phan 2
    int m;
    do
    {
        cout << "Nhap vao gia tri m cua mang thu hai: ";
        cin >> m;
        if (m < 0)
            cout << "Gia tri nhap vao khong hop le.\n";
    } while (m < 0);
    int arr_2[MAX_LENGTH];
    inputArray(arr_2, m);
    outputArray(arr_2, m);
    cout << "Tong cac so nguyen trong mang: " << sumExcluding67(arr_2, m) << "\n";
    // Phan 3
    int p;
    do
    {
        cout << "Nhap vao gia tri p cua mang thu ba: ";
        cin >> p;
        if (p < 0)
            cout << "Gia tri nhap vao khong hop le.\n";
    } while (p < 0);
    int arr_3[MAX_LENGTH];
    inputArray(arr_3, p);
    outputArray(arr_3, p);
    bool spiltArray = canSpiltArray(arr_3, p);
    if (spiltArray)
    {
        cout << "Mang co the duoc chia thanh 2 phan co tong bang nhau.\n";
    }
    else
    {
        cout << "Mang khong the chia thanh 2 phan co tong bang nhau.\n";
    }
    return 0;
}