#pragma once

#include <iostream>
#include <math.h>
#include <string.h>

using namespace std;

#define MAX_LENGTH 100
void inputArray(int arr[], int n);
void outputArray(int arr[], int n);

// Phan 1
bool checkThreeEvenOdd(int arr[], int n);
// Phan 2
int sumExcluding67(int arr[], int n);
// Phan 3
int calculateSum(int arr[], int n);
bool canSpiltArray(int arr[], int n);
