#include "func.h"

void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap vao gia tri thu " << i + 1 << ": ";
        cin >> arr[i];
    }
}
void outputArray(int arr[], int n)
{
    cout << "Gia tri cua tung phan tu trong mang.\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
// Phan 1
bool checkThreeEvenOdd(int arr[], int n)
{
    for (int i = 0; i < n - 2; i++)
    {
        if ((arr[i] % 2 == arr[i + 1] % 2) && (arr[i + 1] % 2 == arr[i + 2] % 2))
            return true;
    }
    return false;
}
// Phan 2
int sumExcluding67(int arr[], int n)
{
    int sum = 0;
    bool skip = false;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == 6)
            skip = true;
        else if (!skip)
            sum += arr[i];
        else if (arr[i] == 7)
            skip = false;
    }
    return sum;
}
// Phan 3
int calculateSum(int arr[], int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++)
        sum = sum + arr[i];
    return sum;
}
// 1 1 1 2 1
// Tong mang = 6
// Right = 6, left = 0
// Right = 5, left = 1
// Right = 4, left = 2
// Right = 3, left = 3

bool canSpiltArray(int arr[], int n)
{
    int leftSum = 0, rightSum = calculateSum(arr, n);
    for (int i = 0; i < n; i++)
    {
        if (leftSum == rightSum)
            return true;
        else
        {
            rightSum -= arr[i];
            leftSum += arr[i];
        }
    }
    return false;
}
