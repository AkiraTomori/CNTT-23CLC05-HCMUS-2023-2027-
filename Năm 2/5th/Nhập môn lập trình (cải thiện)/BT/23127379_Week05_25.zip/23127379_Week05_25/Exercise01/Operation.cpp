#include "Operation.h"

// Homework tuan 4
// Bài 1
void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Nhap vao gia tri thu " << i + 1 << ": ";
        cin >> arr[i];
    }
}
// Bài 2
void outputArray(int arr[], int n)
{
    cout << "Gia tri cua tung phan tu trong mang.\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
// Bài 3
int FindMaximumValue(int arr[], int n)
{
    if (n == 0) return arr[0];
    int maxValue = arr[0];
    for (int i = 1; i < n; i++)
    {
        if (maxValue < arr[i])
        {
            maxValue = arr[i];
        }
    }
    return maxValue;
}
// Bài 4
int FindFirstEvenNumber(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        if (arr[i] % 2 == 0)
            return arr[i];
    }
    return -1;
}
// Bài 5
int FindSmallestEven(int arr[], int n)
{
    int minEven = -1;
    for (int i = 0; i < n; i++)
    {
        if (minEven == -1 || (minEven > arr[i] && arr[i] % 2 == 0))
        {
            minEven = arr[i];
        }
    }
    return minEven;
}
// Bài 6
int FindPositionOfSmallestEven(int arr[], int n)
{
    int SmallestEven = FindSmallestEven(arr, n);
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == SmallestEven)
            return arr[i];
    }
    return -1;
}
// Bai 7
int Max(int a, int b)
{
    return a > b ? a : b;
}
int FindXContainsAllValuesInTheArray(int arr[], int n)
{
    if (n == 1)
    {
        return arr[0];
    }
    int maxValue = arr[0];
    int minValue = arr[0];
    for (int i = 1; i < n; i++)
    {
        if (maxValue < arr[i])
        {
            maxValue = arr[i];
        }
        if (minValue > arr[i])
        {
            minValue = arr[i];
        }
    }
    int x = Max(maxValue, minValue);
    return x;
}
// Bai 8
bool isPowerOfTwo(int n)
{
    return n > 0 && (n & (n - 1)) == 0;
}
int FindTheFirstValueIsPowerOfTwo(int arr[], int n)
{
    int FirstValue = 0;
    for (int i = 0; i < n; i++)
    {
        if (isPowerOfTwo(arr[i]))
        {
            FirstValue = arr[i];
            break;
        }
    }
    return FirstValue;
}
// Bai 9
void FindSpecialValues(int arr[], int n)
{
    int temp[MAX_LENGTH];
    int index = 0;
    for (int i = 1; i < n - 1; i++)
    {
        if (abs(arr[i - 1]) < arr[i] && arr[i] < abs(arr[i + 1]))
        {
            temp[index++] = arr[i];
        }
    }
    cout << "Danh sach cac phan tu thoa yeu cau: " << "\n";
    for (int i = 0; i < index; i++)
    {
        cout << temp[i] << " ";
    }
    cout << "\n";
}
// Bai 10
void FindLargestEvenPositions(int arr[], int n)
{
    int largestEven = INT_MIN;
    for (int i = 0; i < n; i++)
    {
        if (largestEven < arr[i] && arr[i] % 2 == 0)
        {
            largestEven = arr[i];
        }
    }
    int temp[MAX_LENGTH];
    int index = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == largestEven)
        {
            temp[index++] = i;
        }
    }
    cout << "Danh sach vi tri cac phan tu co gia tri trung voi gia tri chan lon nhat: " << "\n";
    for (int i = 0; i < index; i++)
    {
        cout << temp[i] << " ";
    }
    cout << "\n";
}
// Bai 11
bool isFirstDigitOdd(int n)
{
    while (n > 10)
    {
        n /= 10;
    }
    return n % 2 == 1;
}
int CalculateSumWithFirstOddDigit(int arr[], int n)
{
    int SumFirstOddDigit = 0;
    for (int i = 0; i < n; i++)
    {
        if (isFirstDigitOdd(arr[i]))
        {
            SumFirstOddDigit = SumFirstOddDigit + arr[i];
        }
    }
    return SumFirstOddDigit;
}
// Bai 12
double CalculateAveragePositiveNumber(int arr[], int n)
{
    double AveragePositve = 0.0;
    int countPositive = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > 0)
        {
            AveragePositve = AveragePositve + (double)(arr[i]);
            countPositive++;
        }
    }
    return (countPositive == 0 ? 0.0 : AveragePositve / (double)(countPositive));
}
// Bai 13
bool isPrime(int n)
{
    if (n < 2)
        return false;
    int CanBac2 = sqrt(n);
    for (int i = 2; i <= CanBac2; i++)
    {
        if (n % i == 0)
            return false;
    }
    return true;
}
int CountPrimeNumber(int arr[], int n)
{
    int countPrime = 0;
    for (int i = 0; i < n; i++)
    {
        if (isPrime(arr[i]))
        {
            countPrime++;
        }
    }
    return countPrime;
}
// Bai 14
int CountDistinctValues(int arr[], int n)
{
    int distinctValues[MAX_LENGTH];
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        bool found = false;
        for (int j = 0; j < count; j++)
        {
            if (arr[i] == distinctValues[j])
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            distinctValues[count++] = arr[i];
        }
    }
    return count;
}
// Bai 15
void listFrequencies(int arr[], int n)
{
    int distinctValues[MAX_LENGTH];
    int Frequencies[MAX_LENGTH];
    int count = 0;
    
    for (int i = 0; i < n; i++)
    {
        bool found = false;
        for (int j = 0; j < count; j++)
        {
            if (arr[i] == distinctValues[j])
            {
                Frequencies[j]++;
                found = true;
                break;
            }
        }
        if (!found)
        {
            distinctValues[count] = arr[i];
            Frequencies[count] = 1;
            count++;
        }
    }
    cout << "So lan xuat hien cua tung phan tu: \n";
    for (int i = 0; i < count; i++)
    {
        cout << distinctValues[i] << ": "<< Frequencies[i] << "\n";
    }
}
// Bai 16
void listUniqueValues(int arr1[], int n, int arr2[], int m)
{
    cout << "Danh sach cac phan tu rieng biet cua mang thu nhat.\n";
    for (int i = 0; i < n; i++)
    {
        bool found = false;
        for (int j = 0; j < m; j++)
        {
            if (arr1[i] == arr2[j])
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            cout << arr1[i] << " ";
        }
    }
    cout << "\n";
    cout << "Danh sach cac phan tu rieng biet cua mang thu hai.\n";
    for (int i = 0; i < m; i++)
    {
        bool found = false;
        for (int j = 0; j < n; j++)
        {
            if (arr1[j] == arr2[i])
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            cout << arr2[i] << " ";
        }
    }
    cout << "\n";
}
// Bai 17
bool isSorted(int arr[], int n)
{
    for (int i = 1; i < n; i++)
    {
        if (arr[i] < arr[i - 1])
            return false;
    }
    return true;
}
// Bai 18
bool isArithmeticSequence(int arr[], int n)
{
    if (n < 2)
        return false;
    int d = arr[1] - arr[0];
    for (int i = 2; i < n; i++)
    {
        if (d != arr[i] - arr[i - 1])
            return false;
    }
    return true;
}
int getArithmeticNumber(int arr[], int n)
{
    if (isArithmeticSequence(arr, n))
        return arr[1] - arr[0];
    else 
        return 0;
}
// Bai 19
void sortArray(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] > arr[j])
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}
// Bai 20
void sortOddNumber(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] % 2 != 0 && arr[j] % 2 != 0 && arr[i] > arr[j])
            {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}
// Bai 21
bool isPermutation(int a[], int b[], int n)
{
    int countA[MAX_LENGTH] = {0};
    int countB[MAX_LENGTH] = {0};
    for (int i = 0; i < n; i++)
    {
        countA[a[i]]++;
        countB[b[i]]++;
    }
    for (int i = 0; i < MAX_LENGTH; i++)
    {
        if (countA[i] != countB[i])
            return false;
    }
    return true;
}
// Bai 22
void mergeArray(int a[], int n, int b[], int m, int result[])
{
    int i = 0, j = 0, k = 0;
    while (i < n && j < m) {
        if (a[i] < b[j]) {
            result[k++] = a[i++];
        } else {
            result[k++] = b[j++];
        }
    }
    while (i < n) {
        result[k++] = a[i++];
    }
    while (j < m) {
        result[k++] = b[j++];
    }
}
// Bai 23
void insertElement(int arr[], int &n, int x, int k)
{
    for (int i = n; i > k; i--)
    {
        arr[i] = arr[i - 1];
    }
    arr[k] = x;
    n++;
}
// Bai 24
void insertAtSortedPosition(int arr[], int &n, int x)
{
    arr[n++] = x;
    sortArray(arr, n);
}
// Bai 25
void deleteElement(int arr[], int &n, int k)
{
    for (int i = k; i < n; i++)
    {
        arr[i] = arr[i + 1];
    }
    n--;
}
// Homework tuan 5
// Bai 26
void deleteElements(int arr[], int &n, int x)
{
    int j = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] != x)
        {
            arr[j++] = arr[i];
        }
    }
    n = j;
}
// Bai 27
void removeDupclicates(int arr[], int &n)
{
    sortArray(arr, n);
    int j = 0;
    for (int i = 1; i < n; i++)
    {
        if (arr[i] != arr[j])
        {
            arr[++j] = arr[i];
        }
    }
    n = j + 1;
}
// Bai 28
// 1 2 3 4 5 6
// 3 4 5 6 1 2
void leftRotate(int arr[], int n, int k)
{
    k = k % n;
    int temp[k];
    for (int i = 0; i < k; i++)
    {
        temp[i] = arr[i];
    }
    for (int i = k; i < n; i++)
    {
        arr[i - k] = arr[i]; 
    }
    for (int i = 0; i < k; i++)
    {
        arr[n - k + i] = temp[i];
    }
}
// Bai 29
void rightRotate(int arr[], int n, int k)
{
    k = k % n;
    int temp[k];
    for (int i = 0; i < k; i++)
    {
        temp[i] = arr[n - k + i];
    }
    for (int i = n - 1; i >= k; i--)
    {
        arr[i] = arr[i - k];
    }
    for (int i = 0; i < k; i++)
    {
        arr[i] = temp[i];
    }
}
// Bai 30
void createArrayFromPrimeNumber(int arr[], int n, int b[], int &m)
{
    m = 0;
    for (int i = 0; i < n; i++)
    {
        if (isPrime(arr[i]))
        {
            b[m++] = arr[i];
        }
    }
}