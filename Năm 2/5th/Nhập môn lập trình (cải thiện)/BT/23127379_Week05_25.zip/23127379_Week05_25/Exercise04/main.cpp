#include "func.h"

int main()
{
    int n;
    do
    {
        cout << "Nhap vao gia tri n cua mang thu nhat: ";
        cin >> n;
        if (n < 0)
        {
            cout << "Gia tri n nhap vao khong hop le.\n";
        }
    } while (n < 0);
    
    int arr[MAX_LENGTH];
    inputArray(arr, n);
    outputArray(arr, n);
    findLongestT(arr, n);

    return 0;
}