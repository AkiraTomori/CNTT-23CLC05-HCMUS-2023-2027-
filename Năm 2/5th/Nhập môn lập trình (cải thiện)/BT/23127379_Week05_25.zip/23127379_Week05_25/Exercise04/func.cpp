#include "func.h"

void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << "Phan tu " << i + 1 << ": ";
        cin >> arr[i];
    }
}
void outputArray(int arr[], int n)
{
    cout << "Danh sach cac phan tu trong mang:\n";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
void findLongestT(int arr[], int n)
{
    if (n == 0) return;
    int inc[100], dec[100];
    for (int i = 0; i < n; i++)
    {
        inc[i] = 1;
        dec[i] = 1;
    }

    for (int i = 1; i < n; i++)
    {
        if (arr[i] > arr[i - 1])
        {
            inc[i] = inc[i - 1] + 1;
        }
    }
    for (int i = n - 2; i >= 0; i--)
    {
        if (arr[i] > arr[i + 1])
        {
            dec[i] = dec[i + 1] + 1;
        }
    }
    int maxLen = 0, peak = 0;
    for (int i = 0; i < n; i++)
    {
        if (inc[i] + dec[i] - 1 > maxLen)
        {
            maxLen = inc[i] + dec[i] - 1;
            peak = i;
        }
    }
    int start = peak - inc[peak] + 1;
    int end = peak + dec[peak] - 1;
    cout << "Day con dai nhat: \n";
    for (int i = start; i <= end; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}