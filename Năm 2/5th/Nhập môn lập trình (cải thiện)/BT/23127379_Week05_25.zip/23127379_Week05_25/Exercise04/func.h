#pragma once

#include <iostream>
#include <math.h>
using namespace std;
#define MAX_LENGTH 100

void inputArray(int arr[], int n);
void outputArray(int arr[], int n);
void findLongestT(int arr[], int n);