#include "Merge.h"

void printList(ListNode *head){
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head){
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

ListNode *readFile(const char* filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == 0) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head){
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout << 0 << " ";
    fout.close();
}

ListNode *mergeAlternate(ListNode *l1, ListNode *l2){
    if (!l1 || !l2) return nullptr;
    
    ListNode* head = l1;
    ListNode *p1 = l1;
    ListNode *p2 = l2;

    while (p1 && p2){
        ListNode *next1 = p1->next;
        ListNode *next2 = p2->next;

        p1->next = p2;

        if (!next1) break;

        p2->next = next1;

        p1 = next1;
        p2 = next2;
    }

    return head;
}