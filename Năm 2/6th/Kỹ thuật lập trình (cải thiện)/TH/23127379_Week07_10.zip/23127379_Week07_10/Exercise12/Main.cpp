#include <iostream>
#include <string>
#include <vector>
#include <cctype>
using namespace std;

class Solution{
    private:
        vector<string> list;
        void backtrack(string s, int n, int start){
            if (start == n){
                list.push_back(s);
                return;
            }
            if (isalpha(s[start])){
                s[start] = toupper(s[start]);
                backtrack(s, n , start + 1);

                s[start] = tolower(s[start]);
                backtrack(s, n, start + 1);
            }
            else{
                backtrack(s, n, start + 1);
            }
        }
    public:
        vector<string> letterCasePermutation(string s){
            int n = s.size();
            backtrack(s, n, 0);
            return list;
        }
};

int main(){
    cout << "Enter string: ";
    string ans; getline(cin, ans);

    Solution solution;
    vector<string> list = solution.letterCasePermutation(ans);
    for (int i = 0; i < list.size(); i++){
        cout << list[i] << "\n";
    }
    return 0;
}