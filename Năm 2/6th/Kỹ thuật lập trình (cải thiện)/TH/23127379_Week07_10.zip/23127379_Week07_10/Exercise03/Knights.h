#ifndef _KNIGHTS_H_
#define _KNIGHTS_H_

#include <iostream>
#include <stdio.h>
#include <string.h>

#define MAX 20

extern int board[MAX][MAX];
extern int dx[8];
extern int dy[8];

bool isValid(int x, int y, int N);
bool solve(int x, int y, int N, int moveNum);

#endif