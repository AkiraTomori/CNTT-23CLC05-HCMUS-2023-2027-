#include "Knights.h"

int board[MAX][MAX];
int dx[8] = {2, 1, -1, -2, -2, -1, 1, 2};
int dy[8] = {1, 2, 2, 1, -1, -2, -2, -1};

bool isValid(int x, int y, int N)
{
    return (x >= 0 && x < N && y >= 0 && y < N && board[x][y] == 0);
}
bool solve(int x, int y, int N, int moveNum)
{
    if (moveNum == N * N + 1)
        return true;
    for (int i = 0; i < 8; i++){
        int nextX = x + dx[i];
        int nextY = y + dy[i];
        if (isValid(nextX, nextY, N)){
            board[nextX][nextY] = moveNum;
            if (solve(nextX, nextY, N, moveNum + 1))
                return true;
            board[nextX][nextY] = 0;
        }
    }
    return false;
}