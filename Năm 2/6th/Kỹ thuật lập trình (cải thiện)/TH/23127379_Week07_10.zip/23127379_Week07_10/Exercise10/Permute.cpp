#include "Permute.h"

void permuteString(string &ans, int n, int start){
    if (start == n){
        cout << ans << "\n";
        return;
    }
    for (int i = start; i < n; i++){
        swap(ans[i], ans[start]);
        permuteString(ans, n, start + 1);
        swap(ans[i], ans[start]);
    }
}