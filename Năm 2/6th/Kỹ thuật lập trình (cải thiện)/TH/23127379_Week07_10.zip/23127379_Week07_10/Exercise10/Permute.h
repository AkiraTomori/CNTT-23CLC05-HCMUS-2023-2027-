#ifndef _PERMUTE_H_
#define _PERMUTE_H_

#include <iostream>
#include <string.h>
#include <string>
using namespace std;

void permuteString(string &ans, int n, int start);

#endif
