#include "Permute.h"

int main(){
    cout << "Enter string: ";
    string ans;
    getline(cin, ans);
    int n = ans.size();
    permuteString(ans, n, 0);
    return 0;
}