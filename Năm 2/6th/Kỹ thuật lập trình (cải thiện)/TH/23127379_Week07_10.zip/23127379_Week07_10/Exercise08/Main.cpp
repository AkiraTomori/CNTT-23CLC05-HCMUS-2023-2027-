#include <iostream>
#include <vector>
#include <map>
using namespace std;

class Solution{
    private:
        vector<vector<int>> list;
        map<vector<int>, int> dict;

        void getPermute(vector<int> &nums, int start){
            if (start == nums.size()){
                dict[nums]++;
                if (dict[nums] == 1) list.push_back(nums);
                return;
            }
            for (int i = start; i < nums.size(); i++){
                swap(nums[i], nums[start]);
                getPermute(nums, start + 1);
                swap(nums[i], nums[start]);
            }
        }
    public:
        vector<vector<int>> permuteUnique(vector<int> &nums){
            getPermute(nums, 0);
            return list;
        }
};

void inputArray(vector<int> &nums, int &n){
    cout << "Enter n: ";
    cin >> n;
    for (int i = 0; i < n; i++){
        cout << "Enter x: ";
        int x; cin >> x;
        nums.push_back(x);
    }
}

int main(){
    Solution solution;
    int n; vector<int> nums;
    inputArray(nums, n);
    
    vector<vector<int>> list = solution.permuteUnique(nums);
    for (int i = 0; i < list.size(); i++){
        for (int j = 0; j < list[i].size(); j++){
            cout << list[i][j] << " ";
        }
        cout << "\n";
    }
    return 0;
}