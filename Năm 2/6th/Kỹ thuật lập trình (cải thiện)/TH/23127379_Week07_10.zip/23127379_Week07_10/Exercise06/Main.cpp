#include "Permutation.h"

int main(){
    int n;
    std::cout << "Enter n: ";
    std::cin >> n;
    int *arr = new int[n];

    inputArray(arr, n);
    printPermutation(arr, n, 0);

    delete []arr;
    return 0;
}