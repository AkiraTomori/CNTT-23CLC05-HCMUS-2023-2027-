#ifndef _PERMUTATION_H_
#define _PERMUTATION_H_

#include <iostream>

void inputArray(int *arr ,int n);
void printPermutation(int *arr, int n, int start);

#endif