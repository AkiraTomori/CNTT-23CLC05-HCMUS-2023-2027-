#include "Permutation.h"

void inputArray(int *arr, int n)
{
    for (int i = 0; i < n; i++){
        arr[i] = i + 1;
    }
}
void printPermutation(int *arr, int n, int start)
{
    if (start == n){
        for (int i = 0; i < n; i++){
            std::cout << arr[i] << " ";
        }
        std::cout << "\n";
        return;
    } 
    for (int i = start; i < n; i++){
        std::swap(arr[i], arr[start]);
        printPermutation(arr, n, start + 1);
        std::swap(arr[i], arr[start]);
    }
}