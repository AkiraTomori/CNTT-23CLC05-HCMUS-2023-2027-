#include "Knights.h"

int board[MAX][MAX];
int dx[8] = {2, 1, -1, -2, -2, -1, 1, 2};
int dy[8] = {1, 2, 2, 1, -1, -2, -2, -1};
int countSolution = 0;

bool isValid(int x, int y, int N)
{
    return (x >= 0 && x < N && y >= 0 && y < N && board[x][y] == 0);
}

void solve(int x, int y, int N, int moveNum)
{
    if (moveNum == N * N + 1){
        std::cout << "Solution #" << ++countSolution << ":\n";
        for (int i = 0; i < N; i++){
            for (int j = 0; j < N; j++){
                std::cout << board[i][j] << "\t";
            }
            std::cout << "\n";
        }
        std::cout << "\n";
        return;
    }

    for (int i = 0; i < 8; i++){
        int nextX = x + dx[i];
        int nextY = y + dy[i];
        if (isValid(nextX, nextY, N)){
            board[nextX][nextY] = moveNum;
            solve(nextX, nextY, N, moveNum + 1);
            board[nextX][nextY] = 0;
        }
    }
}