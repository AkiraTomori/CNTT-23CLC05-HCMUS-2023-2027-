#include "Knights.h"

int main(){
    std::cout << "Enter n: ";
    int n; std::cin >> n;

    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            board[i][j] = 0;
        }
    }
    board[0][0] = 1;
    solve(0, 0, n, 2);
    if (countSolution == 0){
        std::cout << "No solution found.\n";
    }
    else{
        std::cout << "Total solutions: " << countSolution << "\n";
    }
    return 0;
}