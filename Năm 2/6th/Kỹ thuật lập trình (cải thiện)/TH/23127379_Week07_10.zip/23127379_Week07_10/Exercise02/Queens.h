#ifndef _QUEENS_H_
#define _QUEENS_H_

#include <iostream>
#include <stdio.h>
#include <string.h>

#define MAX 20

void solve(int row, int N);
bool isSafe(int row, int col);

#endif