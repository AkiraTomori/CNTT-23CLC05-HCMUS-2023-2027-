#include "Queens.h"

int queenInCol[MAX];
int solutionCount = 0;

// bool solve(int row, int N)
// {
//     if (row == N){
//         for (int i = 0; i < N; i++){
//             std::cout << "(" << i << ", " << queenInCol[i] << ")\n";
//         }
//         return true;
//     }
//     for (int col = 0; col < N; col++){
//         if (isSafe(row, col)){
//             queenInCol[row] = col;
//             if (solve(row + 1, N))
//                 return true;
//         }
//     }
//     return false;
// }

void solve(int row, int N){
    if (row == N){
        std::cout << "Solution #" << ++solutionCount << ":\n";
        for (int i = 0; i < N; i++){
            std::cout << "(" << i << ", " << queenInCol[i] << ")\n";
        }
        std::cout << "\n";
        return;
    }
    for (int col = 0; col < N; col++){
        if (isSafe(row, col)){
            queenInCol[row] = col;
            solve(row + 1, N);
        }
    }
}
bool isSafe(int row, int col)
{
    for (int prevRow = 0; prevRow < row; prevRow++){
        int prevCol = queenInCol[prevRow]; // Same column
        if (prevCol == col || abs(prevCol - col) == abs(prevRow - row)) // same diagonal
            return false;
    }
    return true;
}