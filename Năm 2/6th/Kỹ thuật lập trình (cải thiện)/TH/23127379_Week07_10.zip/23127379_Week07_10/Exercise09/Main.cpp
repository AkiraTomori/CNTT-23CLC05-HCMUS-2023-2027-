#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution{
    public:
        void nextPermutation(vector<int> &nums){
            int n = nums.size(), k, l;
            for (k = n - 2; k >= 0; k--){
                if (nums[k] < nums[k + 1])
                    break;
            }
            if (k < 0){
                reverse(nums.begin(), nums.end());
            }
            else{
                for (l = n - 1; l > k; l--){
                    if (nums[l] > nums[k])
                        break;
                } 
                swap(nums[l], nums[k]);
                reverse(nums.begin() + k + 1, nums.end());
            }
        }
};

void inputArray(vector<int> &nums, int &n){
    cout << "Enter n: ";
    cin >> n;
    for (int i = 0; i < n; i++){
        cout << "Enter x: ";
        int x; cin >> x;
        nums.push_back(x);
    }
}

void outputArray(vector<int> &nums, int n){
    for (int i = 0; i < n; i++){
        cout << nums[i] << " ";
    }
}
int main(){
    Solution solution;
    int n; vector<int> nums;
    inputArray(nums, n);
    
    solution.nextPermutation(nums);
    outputArray(nums, n);

    return 0;
}