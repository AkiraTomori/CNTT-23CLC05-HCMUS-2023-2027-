#include "Queens.h"

int queenInCol[MAX];

bool solve(int row, int N)
{
    if (row == N){
        for (int i = 0; i < N; i++){
            std::cout << "(" << i << ", " << queenInCol[i] << ")\n";
        }
        return true;
    }
    for (int col = 0; col < N; col++){
        if (isSafe(row, col)){
            queenInCol[row] = col;
            if (solve(row + 1, N))
                return true;
        }
    }
    return false;
}
bool isSafe(int row, int col)
{
    for (int prevRow = 0; prevRow < row; prevRow++){
        int prevCol = queenInCol[prevRow]; // Same column
        if (prevCol == col || abs(prevCol - col) == abs(prevRow - row)) // same diagonal
            return false;
    }
    return true;
}