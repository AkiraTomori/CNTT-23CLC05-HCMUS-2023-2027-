#include "Queens.h"

int main(){
    solve(0, 8);
    return 0;
}