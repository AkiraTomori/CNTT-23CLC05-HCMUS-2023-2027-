#ifndef _CYCLE_H_
#define _CYCLE_H_

#include <iostream>
#include <math.h>
#include <string.h>
#include <fstream>

struct ListNode{
    int data;
    ListNode *next;

    ListNode() : data(0), next(nullptr) {};
    ListNode(int val) : data(val), next(nullptr) {};
    ListNode(int val, ListNode *next) : data(val), next(next) {}
};

void printList(ListNode *head);
void deleteList(ListNode *head);

ListNode *readFile(const char* filename);
void outputList(const char *filename, ListNode *head);

bool hasCycle(ListNode *head);
ListNode *readListWithCycle(const char *filename);
void writeResult(const char *filename, bool has_cycle);
void freeList(ListNode *head, bool hasCycle);

#endif
