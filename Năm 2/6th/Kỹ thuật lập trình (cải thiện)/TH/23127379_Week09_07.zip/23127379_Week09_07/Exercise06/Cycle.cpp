#include "Cycle.h"

void printList(ListNode *head){
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head){
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

ListNode *readFile(const char* filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == 0) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head){
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout << 0 << " ";
    fout.close();
}

bool hasCycle(ListNode *head){
    if (!head) return false;

    ListNode *slow = head;
    ListNode *fast = head;
    while (fast && fast->next){
        slow = slow->next;
        fast = fast->next->next;

        if (slow == fast) return true;
    }

    return false;
}

ListNode *readListWithCycle(const char *filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;

    ListNode *dummy = new ListNode(-1);
    ListNode *curr = dummy;
    int val;

    while (fin >> val && val != 0){
        curr->next = new ListNode(val);
        curr = curr->next;
    }

    int loopVal;
    if (fin >> loopVal){
        ListNode *tail = dummy->next;
        while (tail){
            if (tail->data == loopVal){
                curr->next = tail;
                break;
            }
            tail = tail->next;
        }
    }
    return dummy->next;
}

void writeResult(const char *filename, bool has_cycle){
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    fout << (has_cycle ? "YES" : "NO") << "\n";
    fout.close();
}

void freeList(ListNode *head, bool hasCycle){
    if (hasCycle) return;
    deleteList(head);
}