#include "Cycle.h"

int main(){
    ListNode *head = readListWithCycle("Files/input.txt");
    bool cycle = hasCycle(head);
    writeResult("Files/output.txt", cycle);
    std::cout << "Check completed. Please check file output.txt.\n";
    freeList(head, cycle);
    return 0;
}