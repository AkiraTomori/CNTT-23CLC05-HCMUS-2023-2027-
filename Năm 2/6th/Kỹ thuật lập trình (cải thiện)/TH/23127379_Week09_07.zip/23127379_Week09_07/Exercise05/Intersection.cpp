#include "Intersection.h"

void printList(ListNode *head){
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head){
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

ListNode *readFile(const char* filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == -1) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head){
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout << -1 << " ";
    fout.close();
}

ListNode *findIntersection(ListNode *l1, ListNode *l2){
    if (!l1 || !l2) return nullptr;
    ListNode *p1 = l1, *p2 = l2;
    while (p1 != p2){
        p1 = (p1 == nullptr) ? l2 : p1->next;
        p2 = (p2 == nullptr) ? l1 : p2->next;
    }
    return p1;
}

std::pair<ListNode*, ListNode*> readJoinedList(const char* filename){
    std::ifstream fin(filename);
    int val;

    ListNode *list1 = new ListNode(-1), *currA = list1;
    while (fin >> val && val != 0){
        currA->next = new ListNode(val);
        currA = currA->next;
    }

    ListNode *list2 = new ListNode(-1), *currB = list2;
    while (fin >> val && val != 0){
        currB->next = new ListNode(val);
        currB = currB->next;
    }

    int joinVal; fin >> joinVal;

    ListNode *joinNode = list1->next;
    while (joinNode && joinNode->data != joinVal){
        joinNode = joinNode->next;
    }

    if (joinNode){
        currB->next = joinNode;
    }

    return {list1->next, list2->next};
}

void writeResult(const char *filename, ListNode *shared){
    std::ofstream fout(filename);
    if (shared)
        fout << shared->data << std::endl;
    else
        fout << "No intersection" << std::endl;
    fout.close();

}

void deleteUntil(ListNode *head, ListNode *stop){
    while (head && head != stop){
        ListNode *temp = head;
        head = head->next;
        delete temp;
    }
}