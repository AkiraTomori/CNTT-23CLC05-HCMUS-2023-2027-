#include "Intersection.h"

int main(){
    auto [list1, list2] = readJoinedList("Files/input.txt");
    ListNode *shared = findIntersection(list1, list2);
    writeResult("Files/output.txt", shared);
    std::cout << "Completed. Please check on file output.txt.\n";
    deleteUntil(list1, shared);
    deleteUntil(list2, shared);
    deleteList(shared);
    return 0;
}