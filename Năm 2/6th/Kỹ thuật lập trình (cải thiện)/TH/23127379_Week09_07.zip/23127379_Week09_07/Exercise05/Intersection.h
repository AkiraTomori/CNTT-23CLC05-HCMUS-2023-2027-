#ifndef _INTERSECTION_H_
#define _INTERSECTION_H_

#include <iostream>
#include <math.h>
#include <string.h>
#include <fstream>
#include <string>

struct ListNode{
    int data;
    ListNode *next;

    ListNode() : data(0), next(nullptr) {};
    ListNode(int val) : data(val), next(nullptr) {};
    ListNode(int val, ListNode *next) : data(val), next(next) {}
};

void printList(ListNode *head);
void deleteList(ListNode *head);

ListNode *readFile(const char* filename);
void outputList(const char *filename, ListNode *head);

ListNode *findIntersection(ListNode *l1, ListNode *l2);
std::pair<ListNode*, ListNode*> readJoinedList(const char* filename);
void writeResult(const char *filename, ListNode *shared);
void deleteUntil(ListNode *head, ListNode *stop);

#endif