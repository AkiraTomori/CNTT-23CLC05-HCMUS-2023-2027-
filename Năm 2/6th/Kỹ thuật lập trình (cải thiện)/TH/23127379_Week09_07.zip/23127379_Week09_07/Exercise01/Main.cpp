#include "Merge.h"

int main(){
    ListNode *list1 = readFile("Files/input1.txt");
    ListNode *list2 = readFile("Files/input2.txt");

    ListNode *merged = mergeAlternate(list1, list2);
    outputList("Files/output.txt", merged);
    std::cout << "Merge completed. Please check on output.txt file.\n";
    deleteList(merged);

    return 0;
}