#include "BookStore.h"

Book getInformation(){
    printf("Enter information: \n");
    Book b;
    printf("Enter title: ");
    fgets(b.title, TITLE + 1, stdin);
    b.title[strcspn(b.title, "\n")] = 0;

    printf("Enter ISBN: ");
    fgets(b.isbn, ISBN + 1, stdin);
    b.isbn[strcspn(b.isbn, "\n")] = 0;

    printf("Enter author: ");
    fgets(b.author, AUTHOR + 1, stdin);
    b.author[strcspn(b.author, "\n")] = 0;

    printf("Enter languages: ");
    fgets(b.language, LANGUAGE + 1, stdin);
    b.language[strcspn(b.language, "\n")] = 0;

    printf("Enter year: "); scanf("%d", &b.yearPublished);
    printf("Enter price: "); scanf("%lf", &b.price);
    printf("Enter stock: "); scanf("%d", &b.stock);

    return b;
}

void printBook(const Book& book){
    printf("Title: %s.\n", book.title);
    printf("ISBN: %s.\n", book.isbn);
    printf("Author: %s.\n", book.author);
    printf("Languages: %s.\n", book.language);
    printf("Year published: %d.\n", book.yearPublished);
    printf("Prices: %.2lf.\n", book.price);
    printf("Stock: %d.\n", book.stock);
    printf("\n");
}

void initList(List &list){
    list.head = nullptr;
}

ListNode *createNode(Book book){
    ListNode *newNode = new ListNode();
    newNode->data = book;
    newNode->next = nullptr;
    return newNode;
}

void insertBook(List &list, Book book){
    ListNode *curr = list.head;
    while (curr != nullptr){
        if (strcmp(curr->data.isbn, book.isbn) == 0){
            curr->data.stock += book.stock;
            printf("Book already exists. Stock updated.\n");
            return;
        }
        curr = curr->next;
    }
    ListNode *newNode = createNode(book);
    newNode->next = list.head;
    list.head = newNode;
    printf("Book added successfully.\n");
}

void sellBook(List &list, const char* isbn) {
    ListNode* curr = list.head;
    while (curr != NULL) {
        if (strcmp(curr->data.isbn, isbn) == 0) {
            if (curr->data.stock > 0) {
                printf("Selling Book: %s - $%.2f\n", curr->data.title, curr->data.price);
                curr->data.stock--;
                if (curr->data.stock == 0) {
                    printf("OUT OF STOCK.\n");
                }
            } else {
                printf("OUT OF STOCK.\n");
            }
            return;
        }
        curr = curr->next;
    }
    printf("Book not found.\n");
}

void findBook(List &list, const char *keyword){
    ListNode *curr = list.head;
    bool found = false;
    while (curr){
        if (strstr(curr->data.title, keyword) != nullptr){
            printf("ISBN: %s | Title: %s\n", curr->data.isbn, curr->data.title);
            found = true;
        }
        curr = curr->next;
    }
    if (!found){
        printf("No book found with title containing: %s.\n", keyword);
    }
}

void removeLowStock(List &list, int k)
{
    while (list.head != nullptr && list.head->data.stock < k){
        ListNode *temp = list.head;
        list.head = list.head->next;
        delete temp;
    }

    ListNode *curr = list.head;
    while (curr && curr->next){
        if (curr->next->data.stock < k){
            ListNode *temp = curr->next;
            curr->next = temp->next;
            delete temp;
        }
        else{
            curr = curr->next;
        }
    }
    printf("Books with stock less than %d removed.\n", k);
}

void clearList(List &list){
    while (list.head){
        ListNode *temp = list.head;
        list.head = list.head->next;
        delete temp;
    }
}

void showList(List &list){
    ListNode *curr = list.head;
    int i = 1;
    while (curr){
        printf("Book %d.\n", i);
        printBook(curr->data);
        curr = curr->next;
        ++i;
    }
}