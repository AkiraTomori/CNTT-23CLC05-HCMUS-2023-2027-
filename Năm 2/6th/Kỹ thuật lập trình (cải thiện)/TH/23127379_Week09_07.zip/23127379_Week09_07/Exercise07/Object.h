#ifndef _OBJECT_H_
#define _OBJECT_H_

typedef enum{
    TITLE = 200,
    ISBN = 10,
    AUTHOR = 40,
    LANGUAGE = 30
} MAXIMUM_LENGTH;

typedef enum{
    EXIT,
    INSERTBOOK,
    SELLBOOK,
    FINDBOOK,
    REMOVEBOOK,
    SHOWLIST
} MENU;

struct Book{
    char title[TITLE + 1];
    char isbn[ISBN + 1];
    char author[AUTHOR + 1];
    char language[LANGUAGE + 1];
    int yearPublished;
    double price;
    int stock;
};

struct ListNode{
    Book data;
    ListNode *next;
};

struct List{
    ListNode *head;
};

#endif