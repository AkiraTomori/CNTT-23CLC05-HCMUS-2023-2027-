#include "Menu.h"

void menu(){
    List list;
    initList(list);

    int choice;
    printf("---------BOOKSTORE MANAGEMENT--------\n");
    printf("1. Insert Book\n");
    printf("2. Sell Book.\n");
    printf("3. Find book by title.\n");
    printf("4. Remove books with low stock user defined.\n");
    printf("5. Show list of books.\n");
    printf("0. Exit program.\n");
    do{
        printf("\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        getchar();
        switch (choice)
        {
            case INSERTBOOK:
            {
                Book book = getInformation();
                insertBook(list, book);
                break;
            }
            case SELLBOOK:
            {
                char isbn[ISBN + 1];
                printf("Enter ISBN to sell: ");
                fgets(isbn, ISBN + 1, stdin);
                isbn[strcspn(isbn, "\n")] = 0;

                sellBook(list, isbn);
                break;
            }
            case FINDBOOK:
            {
                char keyword[TITLE + 1];
                printf("Enter title to find: ");
                fgets(keyword, TITLE + 1, stdin);
                keyword[strcspn(keyword, "\n")] = 0;

                findBook(list, keyword);
                break;
            }
            case REMOVEBOOK:
            {
                int k; 
                printf("Enter stock threshold: "); scanf("%d", &k);
                removeLowStock(list, k);
                break;
            }
            case SHOWLIST:
            {
                showList(list);
                break;
            }
            case EXIT:
            {
                printf("Exit the program.\n");
                break;
            }
            default:
            {
                printf("Invalid choice.\n");
                break;
            }
        }
    } while (choice != EXIT);
    clearList(list);
}