#ifndef _BOOKSTORE_H_
#define _BOOKSTORE_H_

#include "Object.h"
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <iostream>

Book getInformation();

void printBook(const Book& book);

ListNode *createNode(Book book);

void initList(List &list);

void insertBook(List &list, Book book);

void sellBook(List &list, const char *isbn);

void findBook(List &list, const char *keyword);

void removeLowStock(List &list, int k);

void showList(List &list);

void clearList(List &list);

void menu();

#endif