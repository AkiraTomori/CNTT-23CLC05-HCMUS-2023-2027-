#include "Join.h"

int main(){
    ListNode *list1 = readFile("Files/input1.txt");
    ListNode *list2 = readFile("Files/input2.txt");

    ListNode *joined = joinTwoList(list1, list2);
    outputList("Files/output.txt", joined);
    std::cout << "Join completed. Please check on output.txt file.\n";
    deleteList(joined);
    return 0;
}