#ifndef _NUMBER_H_
#define _NUMBER_H_

#include <iostream>
#include <math.h>
#include <string.h>
#include <fstream>
#include <string>

struct ListNode{
    int data;
    ListNode *next;

    ListNode() : data(0), next(nullptr) {};
    ListNode(int val) : data(val), next(nullptr) {};
    ListNode(int val, ListNode *next) : data(val), next(next) {}
};

void printList(ListNode *head);
void deleteList(ListNode *head);

ListNode *readFile(const char* filename);
void outputList(const char *filename, ListNode *head);
void outputResult(const char *filename, int val);

int getNumber(ListNode *head);
#endif