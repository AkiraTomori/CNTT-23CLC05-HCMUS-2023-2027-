#include "Number.h"

int main(){
    ListNode *head = readFile("Files/input.txt");

    int number = getNumber(head);
    outputResult("Files/output.txt", number);
    std::cout << "Change to number completed. Please check on output.txt files.\n";
    deleteList(head);
    return 0;
}