#include "List.h"

void printList(ListNode *head){
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head){
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

ListNode *readFile(const char* filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == -1) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head){
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout << -1 << " ";
    fout.close();
}

int inputNumber(const char *filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return -1;
    int val; fin >> val;
    fin.close();
    return val;
}

ListNode *createList(int number){
    if (number == -1) return nullptr;
    int temp = number;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    while (temp != 0){
        int remainder = temp % 10;
        curr->next = new ListNode(remainder);
        curr = curr->next;
        temp /= 10;
    }
    return head->next;
}

ListNode *reverseList(ListNode *head){
    if (!head) return nullptr;

    ListNode *curr = head;
    ListNode *nextNode = nullptr;
    ListNode *prev = nullptr;

    while (curr){
        nextNode = curr->next;
        curr->next = prev;
        prev = curr;
        curr = nextNode;
    }

    return prev;
}