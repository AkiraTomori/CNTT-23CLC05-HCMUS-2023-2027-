#include "List.h"

int main(){
    int val = inputNumber("Files/input.txt");

    ListNode *head = createList(val);
    ListNode *reverseHead = reverseList(head);
    
    outputList("Files/output.txt", reverseHead);
    std::cout << "Change to list completed. Please check on output.txt file.\n";
    deleteList(head);

    return 0;
}