#include "RemoveX.h"

void printList(ListNode *head){
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head){
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

void removeX(ListNode *&head, int x){
    if (head == nullptr) return;
    while (head && head->data == x){
        ListNode *temp = head;
        head = head->next;
        delete temp;
    }
    ListNode *curr = head;
    while (curr && curr->next){
        if (curr->next->data == x){
            ListNode *temp = curr->next;
            curr->next = curr->next->next;
            delete temp;
        }
        curr = curr->next;
    }
}

ListNode *readFile(const char* filename){
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == 0) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head){
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout.close();
}