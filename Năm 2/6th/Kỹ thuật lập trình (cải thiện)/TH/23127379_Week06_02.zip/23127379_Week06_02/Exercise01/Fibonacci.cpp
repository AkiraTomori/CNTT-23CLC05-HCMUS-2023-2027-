#include "Fibonacci.h"

int Fibo(int n){
    if (n == 0 || n == 1) return 1;
    else return Fibo(n - 1) + Fibo(n - 2);
}