#include "Fibonacci.h"

int main(){
    printf("Enter n: ");
    int n;
    scanf("%d", &n);
    int result = Fibo(n);
    printf("Result: %d", result);
    return 0;
}