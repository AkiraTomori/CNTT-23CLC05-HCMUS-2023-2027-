#ifndef _BINARY_H_
#define _BINARY_H_

#include <iostream>
#include <string>
#include <string.h>
#include <stdio.h>

std::string toBinary(int x);

#endif