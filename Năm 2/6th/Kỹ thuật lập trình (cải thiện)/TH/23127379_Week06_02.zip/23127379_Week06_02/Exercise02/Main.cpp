#include "Binary.h"

int main(){
    int n;
    std::cout << "Enter n: ";
    std::cin >> n;
    std::string result = toBinary(n);
    std::cout << "Result: " << result << "\n";
    return 0;
}