#include "Cars.h"
using namespace std;

int main() {
    int n;
    cout << "Enter number of cars: ";
    cin >> n;
    Car* cars = new Car[n];
    cin.ignore();

    for (int i = 0; i < n; i++) {
        cout << "Car #" << i + 1 << endl;
        inputCar(cars[i]);
    }

    int countExpensive;
    Car* expensiveCars = filterExpensiveCars(cars, n, countExpensive);
    cout << "\nCars with price > 50000:\n";
    for (int i = 0; i < countExpensive; i++)
        displayCar(expensiveCars[i]);

    Car* topHonda = top3HondaCars(cars, n);
    cout << "\nTop 3 HONDA cars by price:\n";
    for (int i = 0; i < 3; i++)
        if (topHonda[i].name != nullptr)
            displayCar(topHonda[i]);

    sortByName(topHonda, 3);
    writeToFile(topHonda, 3, "out.bin");

    cout << "\nReading from binary file:\n";
    readFromFile("out.bin");

    for (int i = 0; i < n; i++) {
        delete[] cars[i].name;
        delete[] cars[i].make;
    }
    delete[] cars;
    delete[] expensiveCars;
    delete[] topHonda;

    return 0;
}