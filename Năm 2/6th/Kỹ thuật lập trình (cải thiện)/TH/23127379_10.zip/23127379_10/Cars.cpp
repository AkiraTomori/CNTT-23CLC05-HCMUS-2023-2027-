#include "Cars.h"

void inputCar(Car &car)
{
    cout << "Enter ID car: ";
    cin >> car.ID;

    cout << "Enter Name car: ";
    char carName[100];
    cin.ignore();
    cin.getline(carName, 100);
    car.name = new char[strlen(carName) + 1];
    strcpy(car.name, carName);

    cout << "Enter price car: ";
    cin >> car.Price;

    cout << "Enter car Make: ";
    char carMake[100];
    cin.ignore();
    cin.getline(carMake, 100);
    car.make = new char[strlen(carMake) + 1];
    strcpy(car.make, carMake);

    cout << "Input complete.\n";
}

Car *filterExpensiveCars(Car *cars, int n, int &countExpensive)
{
    if (cars == nullptr) return nullptr;
    countExpensive = 0;
    for (int i = 0; i < n; i++)
    {
        if (cars[i].Price > 50000)
        {
            countExpensive++;
        }
    }
    Car *expensiveCars = new Car[countExpensive];
    if (expensiveCars == nullptr) return nullptr;
    int index = 0;
    for (int i = 0; i < n; i++)
    {
        if (cars[i].Price > 50000)
        {
            expensiveCars[index++] = cars[i];
        }
    }
    return expensiveCars;
}

void displayCar(const Car &car)
{
    printf("ID: %d\n", car.ID);
    printf("Name: %s\n", car.name);
    printf("Price: %2.lf\n", car.Price);
    printf("Make: %s\n", car.make);
    printf("\n");
}

Car *top3HondaCars(Car *cars, int n)
{
    if (cars == nullptr) return nullptr;
    int countHonda = 0;
    for (int i = 0; i < n; i++)
    {
        if (strcmp(cars[i].make, "HONDA") == 0)
        {
            countHonda++;
        }
    }
    int index = 0;
    Car *topHonda = new Car [countHonda];
    for (int i = 0; i < n; i++)
    {
        if (strcmp(cars[i].make, "HONDA") == 0)
        {
            topHonda[index++] = cars[i];
        }
    }
    for (int i = 0; i < countHonda - 1; i++)
    {
        for (int j = i + 1; j < countHonda; j++)
        {
            if (topHonda[i].Price < topHonda[j].Price)
            {
                swap(topHonda[i], topHonda[j]);
            }
        }
    }
    Car *top3 = new Car[3];

    for (int i = 0; i < 3 && i < countHonda; i++){
        top3[i] = topHonda[i];
    }
    delete []topHonda;
    return top3;
}

void sortByName(Car *topHonda, int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (strcmp(topHonda[i].name, topHonda[j].name) > 0)
            {
                swap(topHonda[i], topHonda[j]);
            }
        }
    }
}

void writeToFile(Car *topHonda, int size, const char *filename)
{
    FILE *fp = fopen(filename, "wb");
    if (fp == NULL){
        printf("Cannot open file %s.\n", filename);
        return;
    }

    for (int i = 0; i < size; i++)
    {
        fwrite(&topHonda[i].ID, sizeof(int), 1, fp);
        fwrite(&topHonda[i].Price, sizeof(double), 1, fp);
        int sizeName = strlen(topHonda[i].name);
        fwrite(&sizeName, sizeof(int), 1, fp);
        fwrite(topHonda[i].name, sizeName, 1, fp);
        int sizeMake = strlen(topHonda[i].make);
        fwrite(&sizeMake, sizeof(int), 1, fp);
        fwrite(topHonda[i].make, sizeMake, 1, fp);
    }
    fclose(fp);
}

void readFromFile(const char *filename)
{
    FILE *fp = fopen(filename, "rb");
    if (fp == NULL)
    {
        printf("Cannot open file %s.\n", filename);
        return;
    }
    fseek(fp, 0, SEEK_END);
    int size = (int)ftell(fp);
    rewind(fp);

    Car *listCar = new Car[size];
    for (int i = 0; i < size; i++)
    {
        fread(&listCar[i].ID, sizeof(int), 1, fp);
        fread(&listCar[i].Price, sizeof(double), 1, fp);
        int sizeName = 0;
        fread(&sizeName, sizeof(int), 1, fp);
        fread(listCar[i].name, sizeName, 1, fp);
        int sizeMake = 0;
        fread(&sizeMake, sizeof(int), 1, fp);
        fread(listCar[i].make, sizeMake, 1, fp);
    }
    for (int i = 0; i < size; i++)
    {
        printf("Name: %s, Price: %.2lf.\n", listCar[i].name, listCar[i].Price);
    }
    delete []listCar;
}