#ifndef _CARS_H_
#define _CARS_H_

#include <iostream>
#include <string.h>
#include <string>
#include <stdlib.h>
#include <fstream>
#include <algorithm>

using namespace std;

struct Car{
    int ID;
    char *name;
    double Price;
    char *make;
};

void inputCar(Car &car);

Car *filterExpensiveCars(Car *cars, int n, int &countExpensive);

void displayCar(const Car &car);

Car *top3HondaCars(Car *cars, int n);

void sortByName(Car *topHonda, int size);

void writeToFile(Car *topHonda, int size, const char *filename);

void readFromFile(const char *filename);
#endif