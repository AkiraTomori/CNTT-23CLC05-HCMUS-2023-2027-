#ifndef _FIBONACCI_H_
#define _FIBONACCI_H_
#include <iostream>
#include <stdio.h>
#include <string.h>

int Fibo(int n);

#endif