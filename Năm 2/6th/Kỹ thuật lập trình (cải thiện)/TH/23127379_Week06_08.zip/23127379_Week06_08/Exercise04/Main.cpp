#include "DigitSum.h"

int main(){
    int x;
    cout << "Enter x: ";
    cin >> x;
    int result = sumOfDigits(x);
    cout << "Result: " << result << "\n";
    return 0;
}