#include "DigitSum.h"

int sumOfDigits(int x){
    if (x == 0)
        return 0;
    int remainder = x % 10;
    return sumOfDigits(x / 10) + remainder; 
}