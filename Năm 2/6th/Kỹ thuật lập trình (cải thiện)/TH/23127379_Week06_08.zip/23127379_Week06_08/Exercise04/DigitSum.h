#ifndef _DIGIT_SUM_H_
#define _DIGIT_SUM_H_

#include <iostream>
#include <string>
#include <string.h>
using namespace std;

int sumOfDigits(int x);
#endif