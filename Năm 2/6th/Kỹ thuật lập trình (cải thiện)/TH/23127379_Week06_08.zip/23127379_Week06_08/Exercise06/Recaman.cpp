#include "Recaman.h"

bool isUsed(int arr[], int size, int val)
{
    for (int i = 0; i < size; i++){
        if (arr[i] == val)
            return true;
    }
    return false;
}
void Recaman(int arr[], int n, int index)
{
    if (index == n){
        return;
    }
    int prev = arr[index - 1];
    int candidate = prev - index;

    if (candidate > 0 && !isUsed(arr, index, candidate)){
        arr[index] = candidate;
    }
    else{
        arr[index] = prev + index;
    }
    Recaman(arr, n, index + 1);
}