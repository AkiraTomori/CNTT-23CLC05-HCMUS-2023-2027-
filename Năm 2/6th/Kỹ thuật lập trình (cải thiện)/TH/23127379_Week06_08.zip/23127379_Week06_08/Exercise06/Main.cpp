#include "Recaman.h"

int main(){
    int n;
    cout << "Enter number: ";
    cin >> n;

    int *arr = new int[n];
    arr[0] = 0;
    Recaman(arr, n, 1);

    for (int i = 0; i < n; i++){
        cout << arr[i] << " ";
    }
    delete []arr;
    return 0;
}