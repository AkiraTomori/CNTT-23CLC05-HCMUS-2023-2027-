#ifndef _RECAMAN_H_
#define _RECAMAN_H_

#include <iostream>
#include <string>
using namespace std;

bool isUsed(int arr[], int size, int val);
void Recaman(int arr[], int n, int index);

#endif