#ifndef _PALINDROME_H_
#define _PALINDROME_H_

#include <stdio.h>
#include <string.h>
#include <iostream>

bool isPalindrome(int l, int r, char *s);


#endif