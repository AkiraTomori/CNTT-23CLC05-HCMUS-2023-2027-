#include "Palindrome.h"

#define MAX 100
int main(){
    char line[MAX];
    std::cout << "Enter paragraph: ";
    std::cin.getline(line, MAX);
    int length = strlen(line);
    bool checkPalindrome = isPalindrome(0, length - 1, line);
    std::string result = (checkPalindrome ? "Is palindrome" : "Not a palindrome");
    std::cout << result << "\n";
    return 0;
}