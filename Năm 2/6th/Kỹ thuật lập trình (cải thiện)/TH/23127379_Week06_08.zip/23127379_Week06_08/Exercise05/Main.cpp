#include "Prime.h"

int main(){
    cout << "Enter n: ";
    int n; cin >> n;
    bool checkPrime = isPrime(n);
    string result = (checkPrime ? "Is prime number" : "Not a prime number");
    cout << result;
    return 0;
}