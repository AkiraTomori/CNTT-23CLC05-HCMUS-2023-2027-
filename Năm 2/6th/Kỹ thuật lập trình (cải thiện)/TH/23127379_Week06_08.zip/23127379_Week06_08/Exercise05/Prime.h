#ifndef _PRIME_H_
#define _PRIME_H_

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

bool isPrime(int n);
bool isPrimeHelper(int n, int i);

#endif