#include "Array.h"
void inputArray(int arr[], int n)
{
    for (int i = 0; i < n; i++){
        printf("arr[%d]: ", i + 1);
        scanf("%d", &arr[i]);
    }
}
void printArray(int arr[], int n)
{
    if (n == 0) return;
    printArray(arr, n - 1);
    std::cout << arr[n - 1] << " ";
}
void printReverseArray(int arr[], int n)
{
    if (n == 0) return;
    std::cout << arr[n - 1] << " ";
    printReverseArray(arr, n - 1);
}
int sumPositive(int arr[], int n)
{
    if (n == 0) return 0;
    int last = arr[n - 1];
    return (last > 0 ? last : 0) + sumPositive(arr, n - 1);
}

bool isFirstOccurence(int arr[], int n)
{
    for (int i = 0; i < n - 1; i++){
        if (arr[i] == arr[n - 1])
            return false;
    }
    return true;
}
int countDistinct(int arr[], int n)
{
    if (n == 0) return 0;
    return (isFirstOccurence(arr, n) ? 1 : 0) + countDistinct(arr, n - 1);
}