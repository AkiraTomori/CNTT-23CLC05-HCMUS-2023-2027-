#include "Array.h"

int main()
{
    int n;
    std::cout << "Enter number of elements: ";
    std::cin >> n;
    int *arr = new int [n];
    inputArray(arr, n);
    
    std::cout << "1. Print array.\n";
    std::cout << "2. Print reverse array.\n";
    std::cout << "3. Sum of positive Numbers.\n";
    std::cout << "4. Count distinct Values.\n";
    std::cout << "0. Exit program.\n";
    
    int choice;
    do{
        std::cout << "Enter your choice.\n";
        std::cin >> choice;
        switch (choice)
        {
        case PRINT:
            printArray(arr, n);
            std::cout << "\n";
            break;
        case PRINTREVERSED:
            printReverseArray(arr, n);
            std::cout << "\n";
            break;
        case SUMPOSITIVE:
            std::cout << "Total positive sum: " << sumPositive(arr, n) << "\n";
            break;
        case COUNTDISTINCT:
            std::cout << "Number of distinct Numbers: " << countDistinct(arr, n) << "\n";
            break;
        case EXIT:
            std::cout << "Exit program.\n";
            break;
        default:
            std::cout << "Invalid choice.\n";
            break;
        }
    } while (choice != Selection::EXIT);

    delete []arr;
    return 0;
}