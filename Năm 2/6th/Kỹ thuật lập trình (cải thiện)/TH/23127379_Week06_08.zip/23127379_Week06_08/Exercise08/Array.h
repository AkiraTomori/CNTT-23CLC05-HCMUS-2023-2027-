#ifndef _ARRAY_H_
#define _ARRAY_H_

#include <iostream>
#include <string>
#include <stdio.h>
#include <string.h>

typedef enum{
    EXIT,
    PRINT,
    PRINTREVERSED,
    SUMPOSITIVE,
    COUNTDISTINCT
} Selection;

void inputArray(int arr[], int n);
void printArray(int arr[], int n);
void printReverseArray(int arr[], int n);
int sumPositive(int arr[], int n);

bool isFirstOccurence(int arr[], int n);
int countDistinct(int arr[], int n);

#endif