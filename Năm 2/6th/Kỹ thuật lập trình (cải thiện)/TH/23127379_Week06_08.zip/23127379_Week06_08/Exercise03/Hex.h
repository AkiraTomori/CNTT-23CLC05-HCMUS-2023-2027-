#ifndef _HEX_H_
#define _HEX_H_

#include <iostream>
#include <string>
using namespace std;

string toHex(int x);
string convertToHex(int x);

#endif