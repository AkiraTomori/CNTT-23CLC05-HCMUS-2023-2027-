#include "Hex.h"

int main(){
    int n;
    cout << "Enter n: ";
    cin >> n;
    string result = convertToHex(n);
    cout << "Result: " << result << "\n";
    return 0;
}