#include "Hex.h"

string toHex(int x)
{
    if (x == 0){
        return "";
    }
    int remainder = x % 16;
    char hexDigit;
    if (remainder < 10){
        hexDigit = '0' + remainder;
    }
    else{
        hexDigit = 'A' + (remainder - 10);
    }
    return toHex(x / 16) + hexDigit;
}

string convertToHex(int x)
{
    if (x == 0) return "0";
    return toHex(x);
}