#include "BuffaloMath.h"

bool isFullBuffalo(int stand_buffalo, int lying_buffalo, int old_buffalo)
{
    return (stand_buffalo + lying_buffalo + old_buffalo == MAX_BUFFALO);
}
bool isFullGrass(int stand_buffalo, int lying_buffalo, int old_buffalo)
{
    return (15 * stand_buffalo + 9 * lying_buffalo + old_buffalo == 3 * MAX_GRASS);
}
void printSolution(int stand_buffalo, int lying_buffalo, int old_buffalo)
{
    printf("So trau dung: %d \n", stand_buffalo);
    printf("So trau nam: %d\n", lying_buffalo);
    printf("So trau gia: %d\n", old_buffalo);
    printf("\n");
}
void printAllPossibleSolution()
{
    int stand_buffalo, lying_buffalo, old_buffalo;
    for (stand_buffalo = 0; stand_buffalo <= 20; stand_buffalo++)
    {
        for (lying_buffalo = 0; lying_buffalo <= 33; lying_buffalo++)
        {
            old_buffalo = MAX_BUFFALO - stand_buffalo - lying_buffalo;
            if (isFullBuffalo(stand_buffalo, lying_buffalo, old_buffalo) && isFullGrass(stand_buffalo, lying_buffalo, old_buffalo))
            {
                printSolution(stand_buffalo, lying_buffalo, old_buffalo);
            }
        }
    }
}