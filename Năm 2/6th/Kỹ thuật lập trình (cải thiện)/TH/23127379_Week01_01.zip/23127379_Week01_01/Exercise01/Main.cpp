#include "BuffaloMath.h"

int main()
{
    printAllPossibleSolution();
    return 0;
}