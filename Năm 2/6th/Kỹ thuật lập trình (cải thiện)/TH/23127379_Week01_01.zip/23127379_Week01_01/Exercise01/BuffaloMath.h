#ifndef _BUFFALO_MATH_H_
#define _BUFFALO_MATH_H_

#define MAX_BUFFALO 100
#define MAX_GRASS 100
#include <stdio.h>
#include <iostream>
using namespace std;

bool isFullBuffalo(int stand_buffalo, int lying_buffalo, int old_buffalo);
bool isFullGrass(int stand_buffalo, int lying_buffalo, int old_buffalo);
void printSolution(int stand_buffalo, int lying_buffalo, int old_buffalo);
void printAllPossibleSolution();
#endif