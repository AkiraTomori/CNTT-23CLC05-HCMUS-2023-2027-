#include "replaceString.h"
char *replaceStr(char *src, char *sub, char *rep)
{
    if (src == nullptr) return nullptr;
    if (sub == nullptr || *sub == '\0') return strdup(src);

    int count = 0;
    char *pos = src;
    int subLen = strlen(sub);
    while ((pos = strstr(pos, sub)) != nullptr)
    {
        count++;
        pos += subLen;
    }
    int repLen = strlen(rep);
    int srcLen = strlen(src);
    int newLen = srcLen + count * (repLen - subLen);
    char *result = (char *)malloc(newLen + 1);
    if (result == nullptr) return nullptr;

    char *resPtr = result;
    pos = src;
    while (*pos)
    {
        if (strstr(pos, sub) == pos)
        {
            strcpy(resPtr, rep);
            resPtr += repLen;
            pos += subLen;
        }
        else{
            *resPtr++ = *pos++;
        }
    }
    *resPtr = '\0';
    return result;
}