#ifndef _REPLACE_STRING_H_
#define _REPLACE_STRING_H_
#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

char *replaceStr(char *src, char *sub, char *rep);
#endif