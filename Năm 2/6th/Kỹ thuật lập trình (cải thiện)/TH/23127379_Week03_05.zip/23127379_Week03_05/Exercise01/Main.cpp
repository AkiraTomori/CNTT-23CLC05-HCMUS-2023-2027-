#include "replaceString.h"

int main()
{
    char *src = "brown fox and brown dog";
    char *result = replaceStr(src, "brown", "red");
    printf("Result: %s", result);
    free(result);
    return 0;
}