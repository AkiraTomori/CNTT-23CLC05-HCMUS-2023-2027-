#ifndef _PASCAL_H_
#define _PASCAL_H_

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

int **createPascalTriangle(int n);
void printTriangle(int **triangle, int n);
void realeaseMemory(int **triangle, int n);

#endif