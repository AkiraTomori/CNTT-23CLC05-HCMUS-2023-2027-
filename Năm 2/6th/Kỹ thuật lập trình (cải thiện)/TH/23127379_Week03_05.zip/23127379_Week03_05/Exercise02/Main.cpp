#include "Pascal.h"

int main()
{
    int n;
    printf("Enter number of rows for triangle: ");
    scanf("%d", &n);
    int **triangle = createPascalTriangle(n);
    printTriangle(triangle, n);
    realeaseMemory(triangle, n);
    return 0;
}