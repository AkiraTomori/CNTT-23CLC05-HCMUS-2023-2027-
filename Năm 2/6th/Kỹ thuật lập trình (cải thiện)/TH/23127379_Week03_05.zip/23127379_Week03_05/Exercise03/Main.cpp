#include "Labs.h"

int main()
{
    int **labs = NULL;
    int *stationsPerLabs = NULL;
    int numLabs;

    initializeLab(labs, stationsPerLabs, numLabs);
    menu(labs, stationsPerLabs, numLabs);
    freeLabs(labs, stationsPerLabs, numLabs);
    return 0;
}