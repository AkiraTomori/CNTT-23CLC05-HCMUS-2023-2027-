#include "Labs.h"

void initializeLab(int **&labs, int *&stationsPerLabs, int &numLabs)
{
    printf("Enter number of labs: ");
    scanf("%d", &numLabs);

    if (numLabs <= 0)
    {
        labs = NULL;
        stationsPerLabs = NULL;
        return;
    }

    // cac phong labs
    labs = (int **)malloc(numLabs * sizeof(int *));
    // mot mang chua danh sach cac may tinh
    stationsPerLabs = (int *)malloc(numLabs * sizeof(int));
    for (int i = 0; i < numLabs; i++)
    {
        printf("Enter number of computers for lab %d: ", i + 1);
        scanf("%d", &stationsPerLabs[i]);

        int sizeOfLabs = stationsPerLabs[i];
        labs[i] = (int *)malloc(sizeOfLabs * sizeof(int));
        for (int j = 0; j < stationsPerLabs[i]; j++)
        {
            labs[i][j] = 0; // Empty.
        }
    }
}
void logIn(int **labs, int *stationsPerLabs, int numLabs)
{
    int id, station, lab;
    printf("Enter your ID (5-digit numeber): ");
    scanf("%d", &id);
    printf("Enter station: ");
    scanf("%d", &station);
    printf("Enter lab: ");
    scanf("%d", &lab);

    if (lab < 1 || lab > numLabs || station < 1 || station > stationsPerLabs[lab - 1])
    {
        printf("Invalid station or labs.\n");
        return;
    }

    if (labs[lab - 1][station - 1] != 0)
    {
        printf("This station has already been used.\n");
        return;
    }

    labs[lab - 1][station - 1] = id;
    printf("User %d has logged in station %d at lab %d\n", id, station, lab);
}
void logOut(int **labs, int *stationsPerLabs, int numLabs)
{
    int station, lab;
    printf("Enter station: ");
    scanf("%d", &station);
    printf("Enter lab: ");
    scanf("%d", &lab);

    if (lab < 1 || lab > numLabs || station < 1 || station > stationsPerLabs[lab - 1])
    {
        printf("Invalid station or labs.\n");
        return;
    }
    if (labs[lab - 1][station - 1] == 0)
    {
        printf("This station is already empty.\n");
        return;
    }
    int id = labs[lab - 1][station - 1];
    printf("User %d has logged out station %d at lab %d\n", id, station, lab);
    labs[lab - 1][station - 1] = 0;
}
void searchUser(int **labs, int *stationsPerLabs, int numLabs)
{
    int id;
    printf("Enter ID (5-digits) for searching: ");
    scanf("%d", &id);
    bool found = false;
    for (int i = 0; i < numLabs; i++)
    {
        for (int j = 0; j < stationsPerLabs[i]; j++)
        {
            if (labs[i][j] == id)
            {
                found = true;
                break;
            }
        }
    }
    if (!found)
    {
        printf("Can't find user %d\n", id);
        return;
    }
    printf("Found user %d\n", id);
}
void displayUser(int **labs, int *stationsPerLabs, int numLabs)
{
    printf("-----------LABS STATUS-----------------\n");
    for (int i = 0; i < numLabs; i++)
    {
        printf("Labs %d: ", i + 1);
        for (int j = 0; j < stationsPerLabs[i]; j++)
        {
            if (labs[i][j] == 0)
            {
                printf("[EMPTY] ");
            }
            else
            {
                printf("[%d] ", labs[i][j]);
            }
        }
        printf("\n");
    }
}
void freeLabs(int **labs, int *stationsPerLabs, int numLabs)
{
    for (int i = 0; i < numLabs; i++)
    {
        free(labs[i]);
    }
    free(labs);
    free(stationsPerLabs);
}
void menu(int **labs, int *stationsPerLabs, int numLabs)
{
    int choice;
    printf("-------MENU------\n");
    printf("1. Log in.\n");
    printf("2. Log out.\n");
    printf("3. Display users.\n");
    printf("4. Search Users.\n");
    printf("0. Exit program.\n");
    printf("Enter admin's choice.\n");
    do
    {
        scanf("%d", &choice);
        switch (choice)
        {
        case LOG_IN:
        {
            logIn(labs, stationsPerLabs, numLabs);
            break;
        }
        case LOG_OUT:
        {
            logOut(labs, stationsPerLabs, numLabs);
            break;
        }
        case DISPLAY_LABS:
        {
            displayUser(labs, stationsPerLabs, numLabs);
            break;
        }
        case SEARCH_USER:
        {
            searchUser(labs, stationsPerLabs, numLabs);
            break;
        }
        case EXIT:
        {
            printf("Exit program.\n");
            break;
        }
        default:
        {
            printf("Invalid choice.\n");
            break;
        }
        }
    } while (choice != EXIT);
}