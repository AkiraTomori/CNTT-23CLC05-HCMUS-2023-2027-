#ifndef _LABS_H_
#define _LABS_H_

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

typedef enum{
    EXIT,
    LOG_IN,
    LOG_OUT,
    DISPLAY_LABS,
    SEARCH_USER
} Admin;

void initializeLab(int **&labs, int *&stationsPerLabs, int &numLabs);
void logIn(int **labs, int *stationsPerLabs, int numLabs);
void logOut(int **labs, int *stationsPerLabs, int numLabs);
void searchUser(int **labs, int *stationsPerLabs, int numLabs);
void displayUser(int **labs, int *stationsPerLabs, int numLabs);
void freeLabs(int **labs, int *stationsPerLabs, int numLabs);
void menu(int **labs, int *stationsPerLabs, int numLabs);

#endif