#include "Ticket.h"

void initializeMemory(char **&seats)
{
    seats = (char **)malloc(ROW * sizeof(char *));
    for (int i = 0; i < ROW; i++)
    {
        seats[i] = (char *)malloc(SEATS * sizeof(char));
    }
}

void releaseMemory(char **seats, int *prices)
{
    for (int i = 0; i < ROW; i++)
    {
        free(seats[i]);
    }
    free(seats);
    free(prices);
}

void initializeSeats(char **&seats)
{
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < SEATS; j++)
        {
            seats[i][j] = '#';
        }
    }
}

void enterPrices(int *prices)
{
    for (int i = 0; i < ROW; i++)
    {
        printf("Enter price for row %d: ", i + 1);
        scanf("%d", &prices[i]);
    }
}

int *readPriceText(const char *filename)
{
    FILE *fp = fopen(filename, "r");
    if (fp == NULL){
        printf("Cannot open file %s.\n", filename);
        return NULL;
    }
    int n = 0;
    fscanf(fp, "%d", &n);
    if (n != ROW || n <= 0){
        return NULL;
    }
    int *prices = (int *)malloc(n * sizeof(int));
    if (prices == NULL) return NULL;
    for (int i = 0; i < n; i++)
    {
        fscanf(fp, "%d ", &prices[i]);
    }
    return prices;
}

void showPrices(int *prices)
{
    for (int i = 0; i < ROW; i++)
    {
        printf("%d ", prices[i]);
    }
}
void displaySeats(char **seats)
{
    cout << "         ";
    for (int j = 0; j < SEATS; j++)
    {
        cout << setw(2) << (j + 1);
    }
    cout << "\n";

    for (int i = 0; i < ROW; i++)
    {
        cout << "Row " << setw(2) << i + 1 << ": ";
        for (int j = 0; j < SEATS; j++)
        {
            cout << setw(2) << seats[i][j];
        }
        cout << "\n";
    }
}

bool isValidSeats(int row, int seat)
{
    return (row >= 1 && row <= ROW && seat >= 1 && seat <= SEATS);
}

bool isAvailable(char **seats, int row, int seat)
{
    return (seats[row - 1][seat - 1] == '#');
}

int sellTickets(char **&seats, const int *prices, int &totalPrices)
{
    int row, seat;
    printf("Enter row (1-15): ");
    scanf("%d", &row);
    printf("Enter seat (1-30): ");
    scanf("%d", &seat);

    if (!isValidSeats(row, seat))
    {
        printf("Invalid seat\n");
        return 0;
    }
    if (!isAvailable(seats, row, seat))
    {
        printf("This seat has already  been sold.\n");
        return 0;
    }

    seats[row - 1][seat - 1] = '*';
    totalPrices += prices[row - 1];
    printf("Sold: Price: %d VND.\n", prices[row - 1]);
    return prices[row - 1];
}

void showStatistics(char **seats, const int *prices)
{
    int totalSold = 0, totalAvailable = 0;
    for (int i = 0; i < ROW; i++)
    {
        int sold = 0;
        for (int j = 0; j < SEATS; j++)
        {
            if (seats[i][j] == '*')
                sold++;
        }
        printf("Row: %d sold: %d, Available: %d\n", i + 1, sold, SEATS - sold);
        totalSold += sold;
    }
    totalAvailable = ROW * SEATS - totalSold;
    printf("Total sold: %d.\n", totalSold);
    printf("Total available seats: %d.\n", totalAvailable);
}

void menu(char **seats, int *prices, int &totalSales)
{
    int choice = 0;
    printf("-----MENU----\n");
    printf("1. Display seats.\n");
    printf("2. Buy tickets.\n");
    printf("3. Revenue.\n");
    printf("4. Statistic.\n");
    printf("0. Exit program.\n");

    do
    {
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice)
        {
        case DISPLAY_SEATS:
        {
            displaySeats(seats);
            break;
        }
        case BUY_TICKETS:
        {
            sellTickets(seats, prices, totalSales);
            break;
        }
        case REVENUE:
        {
            printf("Total: %d.\n", totalSales);
            break;
        }
        case STATISTICS:
        {
            showStatistics(seats, prices);
            break;
        }
        case EXIT:
        {
            printf("Exit program.\n");
            break;
        }
        default:
        {
            printf("Invalid choice.\n");
            break;
        }
        }
    } while (choice != EXIT);
}