#ifndef _TICKET_H_
#define _TICKET_H_

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iomanip>
#include <fstream>
using namespace std;

#define ROW 15
#define SEATS 30

typedef enum
{
    EXIT,
    DISPLAY_SEATS,
    BUY_TICKETS,
    REVENUE,
    STATISTICS
} AdminTheaters;

void initializeMemory(char **&seats);
void releaseMemory(char **seats, int *prices);
void initializeSeats(char **&seats);
void enterPrices(int *prices);
void displaySeats(char **seats);
bool isValidSeats(int row, int seat);
bool isAvailable(char **seats, int row, int seat);
int sellTickets(char **&seats, const int *prices, int &totalPrices);
void showStatistics(char **seats, const int *prices);
void menu(char **seats, int *prices, int &totalSales);
int *readPriceText(const char *filename);
void showPrices(int *prices);
#endif