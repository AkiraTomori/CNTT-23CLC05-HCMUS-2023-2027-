#include "Ticket.h"

int main()
{
    char **seats = NULL;
    int *prices = NULL;

    initializeMemory(seats);
    initializeSeats(seats);
    
    int totalSales = 0;
    prices = readPriceText("Files/prices.txt");

    menu(seats, prices, totalSales);
    releaseMemory(seats, prices);
    return 0;
}