#ifndef _ZOO_H_
#define _ZOO_H_

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

#define WEEK 7

int **initializeMemory(int n);
void realeaseMemory(int **monkeys, int n);
void printData(int **monkeys, int n);
void inputFood(int **&monkeys, int n);
double calculateAverageFoodEaten(int **monkeys, int n);
int findLeastFoodOneMonkey(int *monkey);
int findMaxFoodOneMonkey(int *monkey);

#endif