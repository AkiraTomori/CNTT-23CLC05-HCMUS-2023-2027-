#include "Zoo.h"

int **initializeMemory(int n)
{
    if (n <= 0) return NULL;
    int **monkeys = (int **)malloc(n * sizeof(int*));
    if (monkeys == NULL)
        return NULL;
    for (int i = 0; i < n; i++)
    {
        monkeys[i] = (int*)malloc(WEEK * sizeof(int));
        if (monkeys[i] == NULL)
            return NULL;
    }
    return monkeys;
}
void realeaseMemory(int **monkeys, int n)
{
    for (int i = 0; i < n; i++)
    {
        free(monkeys[i]);
    }
    free(monkeys);
}
void printData(int **monkeys, int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < WEEK; j++)
        {
            printf("%d ", monkeys[i][j]);
        }
        printf("\n");
    }
}
void inputFood(int **&monkeys, int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < WEEK; j++)
        {
            int pounds;
            do
            {
                printf("Enter pounds food monkey %d eat on day %d: ", i + 1, j + 1);
                scanf("%d", &pounds);
                if (pounds < 0)
                {
                    printf("Invalid pounds, pounds can't be negative.\n");
                }
            } while (pounds < 0);
            monkeys[i][j] = pounds;
            printf("\n");
        }
    }
}
double calculateAverageFoodEaten(int **monkeys, int n)
{
    double sum = 0.0;
    double average = 0.0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < WEEK; j++)
        {
            sum += monkeys[i][j];
        }
    }
    average = (sum) / (n * WEEK);
    return average;
}
int findLeastFoodOneMonkey(int *monkey)
{
    int minFood = monkey[0];
    for (int i = 1; i < WEEK; i++)
    {
        if (minFood > monkey[i])
        {
            minFood = monkey[i];
        }
    }
    return minFood;
}
int findMaxFoodOneMonkey(int *monkey)
{
    int maxFood = monkey[0];
    for (int i = 1; i < WEEK; i++)
    {
        if (maxFood < monkey[i])
        {
            maxFood = monkey[i];
        }
    }
    return maxFood;
}