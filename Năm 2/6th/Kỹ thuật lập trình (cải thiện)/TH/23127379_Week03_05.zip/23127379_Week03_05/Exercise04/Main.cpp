#include "Zoo.h"

int main()
{
    int n;
    printf("Enter number of monkeys: ");
    scanf("%d", &n);
    
    int **monkeys = initializeMemory(n);
    inputFood(monkeys, n);
    printData(monkeys, n);
    double averageFoodEaten = calculateAverageFoodEaten(monkeys, n);
    printf("Which monkey do you want to get information.\n");
    int i;
    scanf("%d", &i);
    int *ptr = monkeys[i - 1];
    int maxFoodEaten = findMaxFoodOneMonkey(ptr);
    int minFoodEaten = findLeastFoodOneMonkey(ptr);
    printf("Average amount of food eaten per day by the whole family of monkeys: %.2lf\n", averageFoodEaten);
    printf("The least amount of food eaten during the week by monkey %d: %d\n", i, minFoodEaten);
    printf("The greatest amount of food eaten during the week by monkey %d: %d\n", i, maxFoodEaten);
    
    realeaseMemory(monkeys, n);
    return 0;
}