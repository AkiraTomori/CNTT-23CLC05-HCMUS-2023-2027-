#include "SplitList.h"

void printList(ListNode *head)
{
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head)
{
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

ListNode *readFile(const char* filename)
{
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == 0) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head)
{
    std::ofstream fout(filename, std::ios::app);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout << 0 << " ";
    fout << "\n";
    fout.close();
}

void splitList(ListNode *head, ListNode *&odd, ListNode *&even){
    odd = nullptr;
    ListNode *Oddtail = nullptr;
    even = nullptr;
    ListNode *Eventail = nullptr;

    int pos = 1;
    ListNode *curr = head;
    while (curr){
        ListNode *nextNode = curr;
        if (pos % 2 == 1){
            if (!odd){
                odd = Oddtail = nextNode;
            }
            else{
                Oddtail->next = nextNode;
                Oddtail = nextNode;
            }
        }
        else{
            if (!even){
                even = Eventail = nextNode;
            }
            else{
                Eventail->next = nextNode;
                Eventail = nextNode;
            }
        }
        pos++;
        curr = curr->next;
    }
    if (Oddtail) Oddtail->next = nullptr;
    if (Eventail) Eventail->next = nullptr;
}