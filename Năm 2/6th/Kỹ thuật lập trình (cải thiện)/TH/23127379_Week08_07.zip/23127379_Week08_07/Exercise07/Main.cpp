#include "SplitList.h"

int main(){
    ListNode *head = readFile("Files/input.txt");
    ListNode *odd, *even;
    
    splitList(head, odd, even);
    outputList("Files/output.txt", odd);
    outputList("Files/output.txt", even);
    std::cout << "Split completed. Please check on output.txt file.\n";
    deleteList(head);
    return 0;
}