#ifndef _REMOVEX_H_
#define _REMOVEX_H_

#include <iostream>
#include <math.h>
#include <string.h>
#include <fstream>

struct ListNode{
    int data;
    ListNode *next;

    ListNode() : data(0), next(nullptr) {};
    ListNode(int val) : data(val), next(nullptr) {};
    ListNode(int val, ListNode *next) : data(val), next(next) {}
};

void printList(ListNode *head);
void deleteList(ListNode *head);

void removeX(ListNode *&head, int x);
ListNode *readFile(const char* filename);
void outputList(const char *filename, ListNode *head);

#endif