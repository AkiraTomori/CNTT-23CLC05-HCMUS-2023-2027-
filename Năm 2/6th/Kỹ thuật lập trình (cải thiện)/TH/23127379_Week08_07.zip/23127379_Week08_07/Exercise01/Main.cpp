#include "RemoveX.h"

int main(){
    ListNode *head = readFile("Files/input.txt");

    // printList(head);
    removeX(head, 2);
    // printList(head);
    outputList("Files/output.txt", head);
    deleteList(head);

    return 0;
}