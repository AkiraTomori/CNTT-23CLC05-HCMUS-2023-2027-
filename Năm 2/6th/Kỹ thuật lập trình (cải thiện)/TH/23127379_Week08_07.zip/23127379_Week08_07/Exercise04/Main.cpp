#include "InsertList.h"

int main(){
    ListNode *head = readFile("Files/input.txt");

    insertEvenBeforeEachNode(head);
    outputList("Files/output.txt", head);
    deleteList(head);

    return 0;
}