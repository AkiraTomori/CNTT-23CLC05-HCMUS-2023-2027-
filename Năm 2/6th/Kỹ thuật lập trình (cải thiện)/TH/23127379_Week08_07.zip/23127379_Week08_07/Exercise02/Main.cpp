#include "RemoveDup.h"

int main(){
    ListNode *head = readFile("Files/input.txt");

    removeDuplicates(head);
    outputList("Files/output.txt", head);
    deleteList(head);

    return 0;
}