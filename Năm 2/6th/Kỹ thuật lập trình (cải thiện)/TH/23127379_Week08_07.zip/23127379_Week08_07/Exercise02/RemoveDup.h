#ifndef _REMOVE_DUP_H_
#define _REMOVE_DUP_H_

#include <iostream>
#include <string.h>
#include <fstream>

struct ListNode{
    int data;
    ListNode *next;

    ListNode() : data(0), next(nullptr) {};
    ListNode(int val) : data(val), next(nullptr) {};
    ListNode(int val, ListNode *next) : data(val), next(next) {}
};

void printList(ListNode *head);
void deleteList(ListNode *head);

ListNode *readFile(const char* filename);
void outputList(const char *filename, ListNode *head);
void removeDuplicates(ListNode *&head);

#endif