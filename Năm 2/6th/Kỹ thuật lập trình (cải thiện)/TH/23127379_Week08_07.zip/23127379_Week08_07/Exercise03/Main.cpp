#include "Reverse.h"

int main(){
    ListNode *head = readFile("Files/input.txt");

    ListNode *reverse = reverseList(head);
    outputList("Files/output.txt", reverse);
    deleteList(head); // Just delete head because reverse list doesn't allocate any node, it points to same memory.

    return 0;
}