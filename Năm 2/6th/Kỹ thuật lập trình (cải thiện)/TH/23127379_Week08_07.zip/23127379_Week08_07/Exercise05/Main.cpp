#include "SortedList.h"

int main(){
    ListNode *head = readFile("Files/input.txt");

    int val;
    std::cout << "Enter val: ";
    std::cin >> val;

    insertSorted(head, val);
    std::cout << "Insert completed. Please check on file output.txt\n";
    outputList("Files/output.txt", head);
    deleteList(head);

    return 0;
}