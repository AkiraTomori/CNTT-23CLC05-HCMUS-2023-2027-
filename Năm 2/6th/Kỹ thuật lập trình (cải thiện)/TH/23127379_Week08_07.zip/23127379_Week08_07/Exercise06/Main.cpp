#include "ListSum.h"

int main(){
    ListNode *head = readFile("Files/input.txt");
    ListNode *newHead = culmutiveList(head);

    outputList("Files/output.txt", newHead);
    std::cout << "Write to file completed. Please check on output file.\n";
    deleteList(head);
    deleteList(newHead);

    return 0;
}