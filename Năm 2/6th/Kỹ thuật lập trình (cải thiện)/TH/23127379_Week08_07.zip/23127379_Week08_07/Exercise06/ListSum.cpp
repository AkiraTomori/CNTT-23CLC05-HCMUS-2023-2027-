#include "ListSum.h"

void printList(ListNode *head)
{
    ListNode *curr = head;
    while (curr){
        std::cout << curr->data << " ";
        curr = curr->next;
    }
    std::cout << "\n";
}

void deleteList(ListNode *head)
{
    while (head != nullptr){
        ListNode *curr = head;
        head = head->next;
        delete curr;
    }
}

ListNode *readFile(const char* filename)
{
    std::ifstream fin(filename);
    if (!fin.is_open()) return nullptr;
    ListNode *head = new ListNode(-1);
    ListNode *curr = head;
    
    int val;
    while (fin >> val){
        if (val == 0) break;
        curr->next = new ListNode(val);
        curr = curr->next;    
    }
    fin.close();
    return head->next;
}

void outputList(const char *filename, ListNode *head)
{
    std::ofstream fout(filename);
    if (!fout.is_open()) return;
    ListNode *curr = head;
    while (curr){
        fout << curr->data << " ";
        curr = curr->next;
    }
    fout << 0 << " ";
    fout.close();
}

ListNode *culmutiveList(ListNode *head){
    if (!head) return nullptr;

    ListNode *curr = head;
    ListNode *newHead = new ListNode(-1);
    ListNode *temp = newHead;
    int sum = 0;
    while (curr){
        sum += curr->data;

        temp->next = new ListNode(sum);
        temp = temp->next;

        curr = curr->next;
    }
    return newHead->next;
}