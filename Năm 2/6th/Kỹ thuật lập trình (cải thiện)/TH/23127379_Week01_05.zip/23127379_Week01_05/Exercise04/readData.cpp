#include "readData.h"

void readNumberFromFile(const char *filename, int arr[], int &n)
{
    FILE *file = fopen(filename, "r");
    if (!file)
    {
        printf("Khong the mo duoc file %s.\n", filename);
        return;
    }
    fscanf(file, "%d", &n);
    for (int i = 0; i < n; i++)
    {
        fscanf(file, "%d", &arr[i]);
    }
    fclose(file);
}
double CalculateAverage(int arr[], int n)
{
    double average = 0.0;
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        if (arr[i] > 0)
        {
            average += arr[i];
            count++;
        }
    }
    return (count == 0 ? 0 : static_cast<double>(average / count));
}
void writetoFiles(const char *filename, int arr[], int n, double average)
{
    FILE *file = fopen(filename, "w");
    if (!file)
    {
        printf("Khong the mo duoc file %s.\n", filename);
        return;
    }
    fprintf(file, "{\n");
    fprintf(file, "\"DanhSach\": [");
    for (int i = 0; i < n; i++)
    {
        fprintf(file, "%d", arr[i]);
        if (i < n - 1) fprintf(file, ", ");
    }
    fprintf(file, "],\n");
    fprintf(file, "\"TrungBinhCong\": %.2lf \n", average);
    fprintf(file, "}");
    fclose(file);
}