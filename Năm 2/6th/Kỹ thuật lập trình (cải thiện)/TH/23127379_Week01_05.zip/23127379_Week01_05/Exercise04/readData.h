#ifndef _READDATA_H_
#define _READDATA_H_
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
using namespace std;

#define MAX_LENGTH 100

void readNumberFromFile(const char *filename, int arr[], int &n);
double CalculateAverage(int arr[], int n);
void writetoFiles(const char *filename, int arr[], int n, double average);
#endif