#include "readData.h"

int main()
{
    int arr[MAX_LENGTH];
    int n = 0;
    readNumberFromFile("Files/input.txt", arr, n);
    double average = CalculateAverage(arr, n);
    writetoFiles("Files/output.json", arr, n, average);
    return 0;
}