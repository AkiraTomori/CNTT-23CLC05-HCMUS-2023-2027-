#include "Binary.h"

int main()
{
    char binary[MAX_LENGTH + 1];
    // fgets(binary, MAX_LENGTH, stdin);
    printf("Nhap chuoi nhi phan can tinh: ");
    cin.getline(binary, MAX_LENGTH + 1);
    unsigned int sum = convert(binary);
    cout << "Chuoi nhi phan duoc bieu dien o thap phan la: " << sum << "\n";
    return 0;
}