#ifndef _BINARY_H_
#define _BINARY_H_

#define MAX_LENGTH 100
#include <stdio.h>
#include <iostream>
#include <string.h>
using namespace std;

unsigned int convert(char bin[]);
#endif