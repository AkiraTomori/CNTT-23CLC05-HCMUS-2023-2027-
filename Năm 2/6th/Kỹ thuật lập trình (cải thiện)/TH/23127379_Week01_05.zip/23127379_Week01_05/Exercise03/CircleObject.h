#ifndef _CIRCLE_OBJECT_H_
#define _CIRCLE_OBJECT_H_

typedef enum{
    ZERO_INTERSECTION,
    ONE_INTERSECTION,
    TWO_INTERSECTION,
    THREE_INTERSECTION
} NumberIntersections;

typedef struct
{
    double x, y;
    double radius;
} Circle;
#endif