#include "Circle.h"

int main()
{
    Circle c1, c2;
    printf("Nhap thong tin cua duong tron dau tien: \n");
    printf("Toa do x va y: ");
    scanf("%lf %lf", &c1.x, &c1.y);
    printf("Ban kinh cua duong tron thu nhat: ");
    scanf("%lf", &c1.radius);

    printf("Nhap thong tin cua duong tron thu hai: \n");
    printf("Toa do x va y: ");
    scanf("%lf %lf", &c2.x, &c2.y);
    printf("Ban kinh cua duong tron thu hai: ");
    scanf("%lf", &c2.radius);
    
    int numsOfIntersections = checkOverLapped(c1, c2);
    printf("So giao diem cua hai duong tron la: %d", numsOfIntersections);
    return 0;
}