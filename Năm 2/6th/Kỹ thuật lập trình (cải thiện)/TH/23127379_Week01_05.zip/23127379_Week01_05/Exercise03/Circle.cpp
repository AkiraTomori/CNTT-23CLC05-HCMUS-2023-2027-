#include "Circle.h"

double calculateDistance(Circle c1, Circle c2)
{
    double x_value = c1.x - c2.x;
    double y_value = c2.y - c2.y;
    return sqrt(x_value * x_value + y_value * y_value);   
}

int checkOverLapped(Circle c1, Circle c2)
{
    NumberIntersections numsIntersection;
    double distance = calculateDistance(c1, c2);
    double rSum = c1.radius + c2.radius;
    double rDiff = fabs(c1.radius - c2.radius);

    if (distance == 0 && c1.radius == c2.radius)
        return NumberIntersections::THREE_INTERSECTION;
    else if (distance > rSum || distance < rDiff)
        return NumberIntersections::ZERO_INTERSECTION;
    else if (distance == rSum || distance == rDiff)
        return NumberIntersections::ONE_INTERSECTION;
    else
        return NumberIntersections::TWO_INTERSECTION;
}