#ifndef _CIRCLE_H_
#define _CIRCLE_H_
#include "CircleObject.h"
#include <stdio.h>
#include <iostream>
#include <math.h>
using namespace std;

double calculateDistance(Circle c1, Circle c2);
int checkOverLapped(Circle c1, Circle c2);

#endif