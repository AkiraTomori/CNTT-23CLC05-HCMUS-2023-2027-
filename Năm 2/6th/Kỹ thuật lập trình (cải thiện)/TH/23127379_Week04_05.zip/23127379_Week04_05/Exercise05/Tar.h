#ifndef _TAR_H_
#define _TAR_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long long fileSizeToDecimal(char fileSizeField[12]);
void printFiles(const char *tarfile);

#endif