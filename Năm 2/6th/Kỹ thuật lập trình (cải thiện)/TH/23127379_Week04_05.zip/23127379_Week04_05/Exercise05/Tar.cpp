#include "Tar.h"

long long fileSizeToDecimal(char fileSizeField[12])
{
    long long size = 0;
    for (int i = 0; i < 12 && fileSizeField[i] != '\0'; ++i){
        if (fileSizeField[i] >= '0' && fileSizeField[i] <= '7'){
            size = size * 8 + (fileSizeField[i] - '0');
        }
    }
    return size;
}
void printFiles(const char *tarfile)
{
    FILE *fp = fopen(tarfile, "rb");
    if (!fp) {
        printf("Can't open file: %s", tarfile);
        return;
    }

    char header[512];
    while ((fread(header, 1, 512, fp)) == 512){
        int isEmpty = 1;
        for (int i = 0; i < 512; i++){
            if (header[i] != '\0'){
                isEmpty = 0;
                break;
            }
        }
        if (isEmpty) break;
        char filename[101];
        strncpy(filename, header, 100);
        long long filesize = fileSizeToDecimal(header + 124);
        printf("File: %s, Size: %lld.\n", filename, filesize);

        long long datasize = ((filesize + 511) / 512) * 512;
        fseek(fp, datasize, SEEK_CUR);
    }
}


