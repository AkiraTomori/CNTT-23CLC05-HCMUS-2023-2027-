#include "Tar.h"

int main(){
    printFiles("Files/Other.tar");
    return 0;
}