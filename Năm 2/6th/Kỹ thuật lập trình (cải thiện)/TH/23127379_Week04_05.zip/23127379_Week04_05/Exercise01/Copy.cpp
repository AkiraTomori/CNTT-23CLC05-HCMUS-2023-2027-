#include "Copy.h"

bool copyFile(const char *src, const char *dest)
{
    FILE *fp1 = fopen(src, "rb");
    FILE *fp2 = fopen(dest, "wb");
    if (!fp1 || !fp2){
        return false;
    }
    char buffer[BUFFER_SIZE];
    size_t bytes;
    while ((bytes = fread(buffer, 1, BUFFER_SIZE, fp1)) > 0){
        fwrite(buffer, 1, bytes, fp2);
    }
    fclose(fp1);
    fclose(fp2);
    return true;
}
const char *getFileName(const char *src)
{
    const char *last_slash = strrchr(src, '/');
    if (last_slash == NULL){
        last_slash = strrchr(src, '\\');
    }
    return last_slash ? last_slash + 1 : src;
}
void buildDestinationpath(char *dest_path, const char *dest_dir, const char *source_path){
    const char *filename = getFileName(source_path);
    snprintf(dest_path, 1024, "%s/%s", dest_dir, filename);
}