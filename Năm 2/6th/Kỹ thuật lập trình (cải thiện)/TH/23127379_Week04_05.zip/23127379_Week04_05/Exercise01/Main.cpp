#include "Copy.h"

int main(int argc, char **argv)
{
    if (argc != 5){
        printf("Usage: MYCOPYFILE -s source path -d destination_directory.\n");
        return 1;
    }
    const char *source_path = NULL;
    const char *destination_dir = NULL;
    source_path = argv[2];
    destination_dir = argv[4];
    if (!source_path || !destination_dir){
        printf("Invalid argument.\n");
        return 1;
    }

    char destination_path[1024];
    buildDestinationpath(destination_path, destination_dir, source_path);
    if (copyFile(source_path, destination_path)){
        printf("File successfully copied.\n");
    }
    return 0;
}