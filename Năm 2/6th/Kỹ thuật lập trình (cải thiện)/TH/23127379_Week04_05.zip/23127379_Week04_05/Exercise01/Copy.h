#ifndef _COPY_H_
#define _COPY_H_

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFFER_SIZE 1024

bool copyFile(const char *src, const char *dest);
const char *getFileName(const char *src);
void buildDestinationpath(char *dest_path, const char *dest_dir, const char *source_path);
#endif