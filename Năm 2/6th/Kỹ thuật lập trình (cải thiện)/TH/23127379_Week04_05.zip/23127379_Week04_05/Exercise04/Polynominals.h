#ifndef _POLYNOMINALS_H_
#define _POLYNOMINALS_H_

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <fstream>


typedef struct{
    float degree;
    float coefficient;
} Term;

typedef struct{
    unsigned short noTerms;
    Term *term;
} Polynominal;

Polynominal *createPoly(const char *filename, int &countPoly);
int findMaxDegreeIndex(Polynominal *polys, int count);
void write_Polynominals(const char *filename, Polynominal *p);
#endif