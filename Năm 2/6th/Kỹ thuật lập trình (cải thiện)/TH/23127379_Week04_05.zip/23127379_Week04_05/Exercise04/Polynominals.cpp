#include "Polynominals.h"

Polynominal *createPoly(const char *filename, int &countPoly){
    FILE *fp = fopen(filename, "rb");
    if (!fp) return NULL;

    Polynominal *polys = NULL;
    countPoly = 0;
    while (!feof(fp)){
        unsigned short no;
        fread(&no, sizeof(unsigned short), 1, fp);

        Polynominal p;
        p.noTerms = no;
        p.term = (Term *)malloc(no * sizeof(Term));
        for (int i = 0; i < no; i++){
            Term term;
            fread(&term.degree, sizeof(float), 1, fp);
            fread(&term.coefficient, sizeof(float), 1, fp);
            p.term[i] = term;
        }
        polys = (Polynominal *)realloc(polys, sizeof(Polynominal) * (countPoly + 1));
        polys[countPoly++] = p; 
    }
    fclose(fp);
    return polys;
}
// Polynominal *create(const char *filename, int &countPoly){
//     std::fstream fin(filename, std::ios::in | std::ios::binary);
//     if (!fin.is_open()) return NULL;
//     Polynominal *polys = NULL;
//     countPoly = 0;
//     while (!fin.eof()){
//         unsigned short no;
//         fin.read((char *)&no, sizeof(unsigned short));
//         Polynominal p;
//         p.noTerms = no;
//         p.term = (Term *)malloc(no * sizeof(Polynominal));
//         for (int i = 0; i < no; i++){
//             Term term;
//             fin.read((char *)&term.degree, sizeof(float));
//             fin.read((char *)&term.coefficient, sizeof(float));
//             p.term[i] = term;
//         }
//         polys = (Polynominal *)realloc(polys, (countPoly + 1) * sizeof(Polynominal));
//         polys[countPoly++] = p;
//     }
//     fin.close();
// }
int findMaxDegreeIndex(Polynominal *polys, int count)
{
    float max_degree = -1;
    int index = -1;
    for (int i = 0; i < count; i++){
        for (int j = 0; j < polys[i].noTerms; j++){
            if (polys[i].term[j].degree > max_degree){
                max_degree = polys[i].term[j].degree;
                index = i;
            }
        }
    }
    return index;
}

void write_Polynominals(const char *filename, Polynominal *p)
{
    FILE *fp = fopen(filename, "wb");
    if (!fp) return;
    fwrite(&p->noTerms, sizeof(unsigned short), 1, fp);
    for (int i = 0; i < p->noTerms; i++){
        fwrite(&p->term[i].degree, sizeof(float), 1, fp);
        fwrite(&p->term[i].coefficient, sizeof(float), 1, fp);
    }
    fclose(fp);
}
// void write(const char *filename, Polynominal *p)
// {
//     std::fstream fout(filename, std::ios::out | std::ios::binary);
//     if (!fout.is_open()) return;
//     fout.write((char *)&p->noTerms, sizeof(unsigned short));
//     for (int i = 0; i < p->noTerms; i++){
//         Term term = p->term[i];
//         fout.write((char *)&term.degree, sizeof(float));
//         fout.write((char *)&term.coefficient, sizeof(float));
//     }
// }