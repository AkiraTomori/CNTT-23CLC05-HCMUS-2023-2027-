#include "Polynominals.h"

int main()
{
    int count;
    Polynominal *polys = createPoly("POLY.bin", count);
    if (!polys){
        printf("Error loading POLY.bins.\n");
        return 1;
    }
    int max_index = findMaxDegreeIndex(polys, count);
    if (max_index >= 0){
        write_Polynominals("POLY_LARGEST.bin", &polys[max_index]);
    }
    for (int i = 0; i < count; i++){
        free(polys[i].term);
    }
    free(polys);
    return 0;
}