#ifndef _MERGE_H_
#define _MERGE_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define BUFFER_SIZE 1024
const char *getFileName(const char *path);
void getBaseFileName(char *output, const char *part_filename);
void buildPartFilename(char *output, const char *base, int part_num);
bool merge_parts(const char *part01_path, const char *dest_dir);

#endif