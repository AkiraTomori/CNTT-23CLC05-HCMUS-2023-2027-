#include "Merge.h"

const char *getFileName(const char *path)
{
    const char *lastSlash = strrchr(path, '/');
    if (lastSlash == NULL){
        lastSlash = strrchr(path, '\\');
    }
    return lastSlash ? lastSlash + 1 : path;
}
void getBaseFileName(char *output, const char *part_filename)
{
    char *dot = strrchr(part_filename, '.');
    if (dot && strncmp(dot, ".part", 5) == 0){
        size_t len = dot - part_filename;
        strncpy(output, part_filename, len);
        output[len] = '\0';
    }else{
        strcpy(output, part_filename);
    }
}
void buildPartFilename(char *output, const char *base, int part_num)
{
    sprintf(output, "%s.part%02d", base, part_num);
}
bool merge_parts(const char *part01_path, const char *dest_dir)
{
    char base_path[1024];
    getBaseFileName(base_path, part01_path);

    const char *filename_only = getFileName(base_path);
    char final_path[1024];
    sprintf(final_path, "%s/%s", dest_dir, filename_only);

    FILE* output = fopen(final_path, "wb");
    if (!output){
        return false;
    }
    char buffer[BUFFER_SIZE];
    char part_path[1024];
    int part_num = 1;
    size_t bytes_read;
    while (1)
    {
        buildPartFilename(part_path, base_path, part_num);
        FILE *part = fopen(part_path, "rb");
        if (!part)
        {
            if (part_num == 1)
            {
                fclose(output);
                remove(final_path);
                return false;
            }
            else{
                // printf("Finished merging %d parts.\n", part_num - 1);
                break;
            }
        }
        printf("Merging: %s\n", part_path);
        while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, part)) > 0){
            fwrite(buffer, 1, bytes_read, output);
        }
        fclose(part);
        part_num++;
    }
    fclose(output);
    return true;
}