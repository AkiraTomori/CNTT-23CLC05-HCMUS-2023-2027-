#include "Merge.h"

int main(int argc, char *argv[]) {
    if (argc != 5) {
        printf("Usage: MYMERGEFILE -s path_of_part01 -d path_of_destination\n");
        return 1;
    }

    const char *source_part01 = NULL;
    const char *dest_dir = NULL;

    for (int i = 1; i < argc; i += 2) {
        if (strcmp(argv[i], "-s") == 0) {
            source_part01 = argv[i + 1];
        } else if (strcmp(argv[i], "-d") == 0) {
            dest_dir = argv[i + 1];
        }
    }

    if (!source_part01 || !dest_dir) {
        printf("Error: Invalid arguments.\n");
        return 1;
    }

    return merge_parts(source_part01, dest_dir);
}