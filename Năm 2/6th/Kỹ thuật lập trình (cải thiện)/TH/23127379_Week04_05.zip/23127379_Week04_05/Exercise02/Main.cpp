#include "Split.h"

int main(int argc, char **argv)
{
    if (argc != 7)
    {
        printf("Usage:\n");
        printf("  MYSPLITFILE -s source_path -d destination_path -numpart x\n");
        printf("  OR\n");
        printf("  MYSPLITFILE -s source_path -d destination_path -sizeapart x\n");
        return 1;
    }
    const char *sourcePath = NULL;
    const char *dest_dir = NULL;
    int num_parts = 0;
    long size_per_parts = 0;
    int split_by_size = 0; // 0 for parts, 1 for size

    for (int i = 1; i < argc; i += 2) {
        if (strcmp(argv[i], "-s") == 0) {
            sourcePath = argv[i + 1];
        } else if (strcmp(argv[i], "-d") == 0) {
            dest_dir = argv[i + 1];
        } else if (strcmp(argv[i], "-numpart") == 0) {
            num_parts = atoi(argv[i + 1]);
            if (num_parts <= 0) {
                printf("Error: Number of parts must be a positive integer.\n");
                return 1;
            }
            split_by_size = 0;
        } else if (strcmp(argv[i], "-sizeapart") == 0) {
            size_per_parts = atol(argv[i + 1]);
            if (size_per_parts <= 0) {
                printf("Error: Size per part must be a positive integer.\n");
                return 1;
            }
            split_by_size = 1;
        } else {
            printf("Error: Unknown option %s\n", argv[i]);
            return 1;
        }
    }
    if (!sourcePath || !dest_dir || (num_parts == 0 && size_per_parts == 0)){
        printf("Missing required arguments.\n");
        return 1;
    }
    return split_file(sourcePath, dest_dir, num_parts, size_per_parts, split_by_size);
}