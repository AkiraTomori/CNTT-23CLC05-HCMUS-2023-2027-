#ifndef _SPLIT_H_
#define _SPLIT_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUFFER_SIZE 1024
bool split_file(const char *source_path, const char *dest_dir, int num_parts, long size_per_part, int split_by_size);
const char *getFileName(const char *path);
long getFileSize(FILE *file);
void buildPartFileName(char *buffer, const char *dest_dir, const char *base_filename, int part_num);


#endif