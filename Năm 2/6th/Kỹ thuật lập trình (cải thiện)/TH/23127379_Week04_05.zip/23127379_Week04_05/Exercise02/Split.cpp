#include "Split.h"

bool split_file(const char *source_path, const char *dest_dir, int num_parts, long size_per_part, int split_by_size)
{
    FILE *source = fopen(source_path, "rb");
    if (!source) return false;
    long total_size = getFileSize(source);
    if (split_by_size){
        num_parts = (total_size + size_per_part - 1) / size_per_part;
    }
    else{
        size_per_part = (total_size + num_parts - 1) / num_parts;
    }

    const char *base_filename = getFileName(source_path);
    char part_filename[1024];
    char buffer[BUFFER_SIZE];
    size_t bytes_read;
    int part_index = 1;

    for (int i = 0; i < num_parts; i++){
        buildPartFileName(part_filename, dest_dir, base_filename, part_index++);
        FILE *part_file = fopen(part_filename, "wb");
        if (!part_file){
            fclose(source);
            return false;
        }
        long written = 0;
        while (written < size_per_part && (bytes_read = fread(buffer, 1, BUFFER_SIZE, source)) > 0){
            if (written + bytes_read > size_per_part){
                bytes_read = size_per_part - written;
            }
            fwrite(buffer, 1, bytes_read, part_file);
            written += bytes_read;
        }
        fclose(part_file);
        if (feof(source)) break;
    }
    fclose(source);
    printf("File split successfully into %d part(s).\n", num_parts);
    return true;
}

const char *getFileName(const char *path)
{
    const char *last_slash = strrchr(path, '/');
    if (last_slash == NULL){
        last_slash = strrchr(path, '\\');
    }
    return last_slash ? last_slash + 1 : path;
}

long getFileSize(FILE *file)
{
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);
    return size;
}
void buildPartFileName(char *buffer, const char *dest_dir, const char *base_filename, int part_num)
{
    sprintf(buffer, "%s/%s.part%02d", dest_dir, base_filename, part_num);
}