#include "Menu.h"

int main(){
    menu();
    return 0;
}