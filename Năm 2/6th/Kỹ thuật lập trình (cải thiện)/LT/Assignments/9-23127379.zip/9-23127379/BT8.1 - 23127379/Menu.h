#ifndef _MENU_H_
#define _MENU_H_

#include "Method.h"
void menu();
MenuOption getMenuChoice();
void showMenuSelection();

#endif