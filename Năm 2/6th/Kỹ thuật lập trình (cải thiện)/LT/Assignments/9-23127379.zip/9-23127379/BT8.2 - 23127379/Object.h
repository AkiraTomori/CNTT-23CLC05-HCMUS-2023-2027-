#ifndef _OBJECT_H_
#define _OBJECT_H_

struct SNode{
    int val;
    SNode *next;
};

struct SList{
    SNode *head;
};

#endif