#include "Copy.h"

int main(int argc, char **argv)
{
    return process_Argv(argc, argv);
}