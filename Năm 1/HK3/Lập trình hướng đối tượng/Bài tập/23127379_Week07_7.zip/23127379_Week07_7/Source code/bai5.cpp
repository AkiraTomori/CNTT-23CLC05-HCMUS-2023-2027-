#include "bai5.h"

DateFormatException::DateFormatException(const string& date): invalidDate(date) {}
const string& DateFormatException::getDate() const{
    return this->invalidDate;
}

DateCheck::DateCheck(const string& date): date(date) {}
bool DateCheck::isLeapYear(int year){
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

bool DateCheck::isValidDate(int day, int month, int year){
    const int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (year < 1) return false;
    if (month < 1 || month > 12) return false;
    if (day < 1) return false;

    int maxDays = daysInMonth[month - 1];
    if (month == 2 && isLeapYear(year))
        maxDays = 29;
    return day <= maxDays;
}
void DateCheck::parseDate(){
    int day, month, year;
    char delimeter1, delimeter2;

    stringstream ss(date);
    ss >> day >> delimeter1 >> month >> delimeter2 >> year;

    if (ss.fail() || delimeter1 != '/' || delimeter2 != '/'){
        throw DateFormatException(date);
    }
    if (!isValidDate(day, month, year)){
        throw DateFormatException(date);
    }
    cout << "Valid date: " << day << "/" << month << "/" << year << "\n";
}