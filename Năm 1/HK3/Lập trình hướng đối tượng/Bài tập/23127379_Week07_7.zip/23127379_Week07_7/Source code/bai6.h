#pragma once
#include <iostream>
#include <string>
#include <exception>
#include <sstream>
using namespace std;

class TimeFormatException : public exception{
    private:
        string invalidTime;
    public:
        TimeFormatException(const string& time);
        const char *what() const throw(){
            return "Invalid time format and value";
        }
        const string& getTime() const;
};

class TimeCheck{
    private:
        string time;
        bool isValidTime(int hour, int minutes, int second);
    public:
        TimeCheck(const string& time);
        void parseTime();
};