#pragma once
#include <iostream>
#include <string>
#include <exception>
using namespace std;

class IndexOutOfRange : public exception{
    public:
        const char* what() const throw(){
            return "index out of range !";
        }
};
class Array{
    private:
        int *arr;
        int size;
    public:
        Array(int size);
        ~Array();
        int getValueAt(int index);
        void displayArray();
};