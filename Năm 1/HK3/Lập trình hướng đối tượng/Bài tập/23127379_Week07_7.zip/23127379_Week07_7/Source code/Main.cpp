#include "bai1.h"
#include "bai2.h"
#include "bai3.h"
#include "bai4.h"
#include "bai5.h"
#include "bai6.h"
#include "bai7.h"

int main()
{
    // Bai 1
    cout << "Bai 1\n";
    Fraction fraction;
    try{
        int num, dem;
        cout << "Numerator: ";
        cin >> num;
        cout << "Demoniator: ";
        cin >> dem;

        fraction.setValue(num, dem);
        fraction.display();
    } catch (const DividedByZeroException& e){
        cerr << "Error: " << e.what() << "\n";
    }
    // Bai 2
    cout << "\nBai 2\n";
    try{
        int size;
        cout << "Enter size of the array: ";
        cin >> size;
        Array myArray(size);
        myArray.displayArray();

        int index = -1;
        cout << "Enter index to get value: ";
        cin >> index;
        int value = myArray.getValueAt(index);
        cout << "Value at index: " << value << "\n";
    }
    catch(const IndexOutOfRange& e){
        cerr << "Error: " << e.what() << "\n";
    }
    catch(const invalid_argument& e){
        cerr << "Error: " << e.what() << "\n";
    }
    cin.ignore();
    // Bai 3
    cout << "\nBai 3 \n";
    try{
        string filePath;
        cout << "Enter file you want to check: ";
        getline(cin, filePath);
        FileHandler file(filePath);
        file.openfile();
        // FileHandler filehandler("hello.txt");
        // filehandler.openfile();
    }
    catch(const FileNotFoundException& e){
        cout << "Error: " << e.what() << "\n";
        cout << "Invalid file path: " << e.getFilePath() << "\n";
    }
    catch(const exception& e){
        cout << "Standard exception: " << e.what() << "\n";
    }
    // Bai 4
    cout << "\nBai 4\n";
    try{
        string input;
        cout << "Enter the number: ";
        getline(cin, input);
        StringToInt s(input);
        int result = s.getParse();
        cout << "Number: " << result << "\n";
    }
    catch(const IntergerFormatException& e){
        cerr << "Error: " << e.what() << "\n";
        cerr << "Error: " << e.getInvalidInput() << "\n";
    }
    // Bai 5
    cout << "\nBai 5\n";
    try{
        string inputDate;
        cout << "Enter date: ";
        getline(cin, inputDate);
        DateCheck date(inputDate);
        date.parseDate();
    }
    catch(const DateFormatException& e){
        cerr << "Error: " << e.what() << "\n";
        cerr << "Error: " << e.getDate() << "\n";
    }
    // Bai 6
    cout << "\nBai 6 \n";
    try{
        string inputTime;
        cout << "Enter time: ";
        getline(cin, inputTime);
        TimeCheck time(inputTime);
        time.parseTime();
    }
    catch(const TimeFormatException& e){
        cerr << "Error: " << e.what() << "\n";
        cerr << "Error: " << e.getTime() << "\n";
    }
    // bai 7
    cout << "\nBai 7 \n";
    try{
        Stack stack(3);
        stack.push(10);
        stack.push(20);
        stack.push(30);
        cout << "Top of Stack: " << stack.getTopValue() << "\n";

        stack.push(40);
    }
    catch (const StackOverFlowException& e){
        cerr << "Stack error: " << e.what() << "\n";
    }
    catch (const StackUnderFlowException& e){
        cerr << "Stack error: " << e.what() << "\n";
    }
    try{
        Queue queue(2);
        queue.enQueue(1);
        queue.enQueue(2);
        cout << "Front value: " << queue.getFrontValue() << "\n";

        queue.enQueue(4);
    }
    catch(const QueueOverFlowException& e){
        cerr << "Queue Error: " << e.what() << "\n";
    }
    catch(const QueueUnderFlowException& e){
        cerr << "Queue Error: " << e.what() << "\n";
    }
    system("pause");
    return 0;
}