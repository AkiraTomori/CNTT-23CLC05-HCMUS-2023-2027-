#include "bai2.h"

Array::Array(int s){
    if (s <= 0){
        throw invalid_argument("Size must be greater than zero.");
    }
    size = s;
    arr = new int[size];
    for (int i = 0; i < size; i++){
        arr[i] = i + 1;
    }
}
Array::~Array(){
    delete []arr;
}
int Array::getValueAt(int index){
    if (index < 0 || index >= size){
        throw IndexOutOfRange();
    }
    return arr[index];
}
void Array::displayArray(){
    for (int i = 0; i < size; i++){
        cout << arr[i] << " ";
    }
    cout << "\n";
}