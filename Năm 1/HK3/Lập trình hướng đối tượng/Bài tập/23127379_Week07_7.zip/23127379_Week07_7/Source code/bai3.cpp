#include "bai3.h"

FileNotFoundException::FileNotFoundException(const string& path){
    this->filePath = path;
}
const string& FileNotFoundException::getFilePath() const{
    return this->filePath;
}
FileHandler::FileHandler(const string& filepath) : filePath(filepath) {}
void FileHandler::openfile(){
    fin.open(filePath);
    if (!fin.is_open()){
        throw FileNotFoundException(filePath);
    }
    cout << "File opened successfully: " << filePath << ".\n";
}
void FileHandler::closeFile(){
    if (fin.is_open()){
        fin.close();
        cout << "File closed successfully: " << filePath << ".\n";
    }
    else{
        cout << "File is not open: " << filePath << ".\n";
    }
}
FileHandler::~FileHandler(){
    closeFile();
}