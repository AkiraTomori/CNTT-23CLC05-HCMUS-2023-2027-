#include "bai6.h"

TimeFormatException::TimeFormatException(const string& time): invalidTime(time) {}
const string& TimeFormatException::getTime() const{
    return this->invalidTime;
}
TimeCheck::TimeCheck(const string& time): time(time) {}
bool TimeCheck::isValidTime(int hour, int minutes, int second){
    if (hour < 0 || hour > 23) return false;
    if (minutes < 0 || minutes > 59) return false;
    if (second < 0 || second > 59) return false;
    return true;
}

void TimeCheck::parseTime(){
    int hour, minutes, second;
    char delimeter1, delimeter2;
    stringstream ss(time);
    ss >> hour >> delimeter1 >> minutes >> delimeter2 >> second;
    if (ss.fail() || delimeter1 != '/' || delimeter2 != '/'){
        throw TimeFormatException(time);
    }
    if (!isValidTime(hour, minutes, second)){
        throw TimeFormatException(time);
    }
    cout << "Time: " << hour << ":" << minutes << ":" << second << "\n";
}