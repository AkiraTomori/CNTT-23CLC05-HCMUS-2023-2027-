#include "bai4.h"

IntergerFormatException::IntergerFormatException(const string& input) : invalidInput(input) {}
const string& IntergerFormatException::getInvalidInput() const{
    return this->invalidInput;
}
StringToInt::StringToInt(const string& number) : input(number) {}
int StringToInt::getParse(){
    if (input.empty()){
        throw IntergerFormatException(input);
    }
    for (size_t i = 0; i < input.size(); i++){
        if (!isdigit(input[i]) && !(i == 0 && input[i] == '-')){
            throw IntergerFormatException(input);
        }
    }
    return stoi(input);
}