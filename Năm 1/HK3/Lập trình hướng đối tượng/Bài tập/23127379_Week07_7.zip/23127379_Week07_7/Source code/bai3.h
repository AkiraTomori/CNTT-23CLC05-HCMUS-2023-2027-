#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <exception>
using namespace std;

class FileNotFoundException{
    private:
        string filePath;
    public:
        FileNotFoundException(const string& path);
        const char *what() const throw(){
            return "File not found or cannot be opened.";
        }
        const string& getFilePath() const;
};

class FileHandler{
    private:
        string filePath;
        ifstream fin;
    public:
        FileHandler(const string& filePath);
        void openfile();
        void closeFile();
        ~FileHandler();
};