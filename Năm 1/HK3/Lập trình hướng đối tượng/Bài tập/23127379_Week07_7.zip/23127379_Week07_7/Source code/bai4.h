#pragma once
#include <iostream>
#include <string>
#include <exception>
#include <cctype>
using namespace std;

class IntergerFormatException : public exception{
    private:
        string invalidInput;
    public:
        IntergerFormatException(const string& input);
        const char *what() const throw(){
            return "Invalid format: Cannot convert string to interger.";
        }
        const string& getInvalidInput() const;
};

class StringToInt{
    private:
        string input;
    public:
        StringToInt(const string& number);
        int getParse();
};