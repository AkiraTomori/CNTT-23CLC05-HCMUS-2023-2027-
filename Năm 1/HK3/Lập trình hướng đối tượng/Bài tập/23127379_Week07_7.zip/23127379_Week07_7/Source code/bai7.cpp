#include "bai7.h"

Stack::Stack() : arr(nullptr), topIndex(-1), size(0) {}
Stack::Stack(int size) : size(size), topIndex(-1)
{
    arr = new int [size];
}
Stack::~Stack()
{
    delete [] arr;
    topIndex = -1;
    size = 0;
}
bool Stack::isEmpty()
{
    return topIndex == -1;
}
bool Stack::isFull()
{
    return topIndex == size - 1;
}

void Stack::push(int value){
    if (isFull()){
        throw StackOverFlowException();
    }
    arr[++topIndex] = value;
}
void Stack::pop(){
    if (isEmpty()){
        throw StackUnderFlowException();
    }
    --topIndex;
}
int Stack::getTopValue(){
    if (isEmpty())
        throw StackUnderFlowException();
    return arr[topIndex];
}

Queue::Queue(): arr(nullptr), front(0), rear(-1), size(0), count(0) {}
Queue::Queue(int size): front(0), rear(-1), size(size), count(0){
    arr = new int [size];
}
Queue::~Queue(){
    delete []arr;
}
bool Queue::isEmpty()
{
    return count == 0;
}
bool Queue::isFull()
{
    return count == size;
}
void Queue::enQueue(int value){
    if (isFull()) {
        throw QueueOverFlowException();
    }
    rear = (rear + 1) % size;
    arr[rear] = value;
    ++count;
}
void Queue::deQueue(){
    if (isEmpty())
        throw QueueUnderFlowException();
    front = (front + 1) % size;
    --count;
}
int Queue::getFrontValue(){
    if (isEmpty())
        throw QueueUnderFlowException();
    return arr[front];
}