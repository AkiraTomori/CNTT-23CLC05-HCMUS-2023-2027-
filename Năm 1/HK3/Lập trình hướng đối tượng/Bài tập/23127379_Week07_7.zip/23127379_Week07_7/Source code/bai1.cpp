#include "bai1.h"

void Fraction::setValue(int num, int dem){
    if (dem == 0){
        throw DividedByZeroException();
    }
    this->numerator = num;
    this->demoniatior = dem;
}
void Fraction::display(){
    cout << this->numerator << "/" <<this->demoniatior << "\n";
}
