#pragma once
#include <iostream>
#include <string>
#include <exception>
#include <sstream>
using namespace std;

class DateFormatException : public exception{
    private:
        string invalidDate;
    public:
        DateFormatException(const string& date);
        const char *what() const throw(){
            return "Invalid date format and value.";
        }
        const string& getDate() const;
};

class DateCheck{
    private:
        string date;
        bool isLeapYear(int year);
        bool isValidDate(int day, int month, int year);
    public:
        DateCheck(const string& date);
        void parseDate();
};