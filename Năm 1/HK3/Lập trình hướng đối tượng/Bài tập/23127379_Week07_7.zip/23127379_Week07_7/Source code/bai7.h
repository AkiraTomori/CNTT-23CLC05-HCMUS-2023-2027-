#pragma once
#include <iostream>
#include <exception>
using namespace std;

class StackOverFlowException: public exception{
    public:
        const char* what() const throw(){
            return "Stack overflow. Cannot push onto a full stack.";
        }
};

class StackUnderFlowException: public exception{
    public:
        const char* what() const throw(){
            return "Stack underflow. Cannot pop from or access an empty stack.";
        }
};
class QueueOverFlowException: public exception{
    public:
        const char* what() const throw(){
            return "Queue overflow. Cannot enqueue into a full queue.";
        }
};
class QueueUnderFlowException: public exception{
    public:
        const char* what() const throw(){
            return "Queue underflow. Cannot dequeue from or access to an empty queue.";
        }
};
class Stack
{
    private:
        int *arr;
        int topIndex;
        int size;
    public:
        Stack();
        Stack(int size);
        ~Stack();
        bool isEmpty();
        bool isFull();
        void push(int);
        void pop();
        int getTopValue();
};

class Queue
{
    private:
        int *arr;
        int front;
        int rear;
        int size;
        int count;
    public:
        Queue();
        Queue(int size);
        ~Queue();
        bool isEmpty();
        bool isFull();
        void enQueue(int value);
        void deQueue();
        int getFrontValue();
};