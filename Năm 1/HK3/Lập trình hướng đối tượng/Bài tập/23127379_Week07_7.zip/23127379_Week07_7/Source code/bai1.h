#pragma once
#include <iostream>
#include <exception>
#include <string>

using namespace std;

class DividedByZeroException : public exception{
    public:
        const char *what() const throw(){
            return "Exception: Cannot divide by zero";
        }
};

class Fraction{
    private:
        int numerator;
        int demoniatior;
    public:
        void setValue(int num, int dem);
        void display();
};