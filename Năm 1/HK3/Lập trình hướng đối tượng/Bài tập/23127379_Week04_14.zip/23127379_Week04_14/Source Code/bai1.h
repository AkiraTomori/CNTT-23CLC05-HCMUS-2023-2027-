#pragma once
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include <iomanip>
#include <fstream>
#include <sstream>
using namespace std;

// Lop co so 
class Employee{
    protected:
        string name;
        int yearJoined;
        int baseSalary;
    public:
        Employee();
        Employee(string name);
        Employee(string name, int yearJoined);
        Employee(string name, int yearJoinded, int baseSalary);
        Employee(const Employee& other);
        string getName();
        // virtual ~Employee();

        void input();
        void output();

        virtual int calculateSalary() const = 0;
};

class OfficeEmployee: public Employee{
    private:
        int workingDays;
        int allowance;
    public:
        OfficeEmployee();
        OfficeEmployee(string name);
        OfficeEmployee(string name, int yearJoined);
        OfficeEmployee(string name, int yearJoined, int baseSalary, int WorkingDays, int allowance);
        OfficeEmployee(const OfficeEmployee& other);

        void input();
        void output();
        int calculateSalary() const;
};

class ProductionEmployee : public Employee{
    private:
        int numberOfProducts;
    public:
        ProductionEmployee();
        ProductionEmployee(string name);
        ProductionEmployee(string name, int yearJoined);
        ProductionEmployee(string name, int yearJoined, int baseSalary, int numberOfProducts);
        ProductionEmployee(const ProductionEmployee& other);

        void input();
        void output();
        int calculateSalary() const;
};

class ManagerEmployee : public Employee{
    private:
        int positionFactor;
        int bonus;
    public:
        ManagerEmployee();
        ManagerEmployee(string name);
        ManagerEmployee(string name, int yearJoined);
        ManagerEmployee(string name, int yearJoined, int baseSalary, int positionFactor, int bonus);
        ManagerEmployee(const ManagerEmployee& other);

        void input();
        void output();
        int calculateSalary() const;
};

class Company{
    private:
        string companyName;
        vector<OfficeEmployee> officeEmployees;
        vector<ProductionEmployee> productionEmployees;
        vector<ManagerEmployee> managerEmployees;
    public:
        Company();
        Company(string name);
        
        void inputEmployees();
        void displayEmployees();
        void printOfficeEmployees();
        void printProdctionEmployees();
        void printManagerEmployees();
        
        int CalculateSalary();
        void findEmployeeByName(const string& searchName);
        void loadOfficeEmployees(const string& file_name);
        void loadProductionEmployees(const string& file_name);
        void loadManagerEmployees(const string& file_name);
};