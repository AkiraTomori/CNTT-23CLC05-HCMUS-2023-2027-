#include "bai1.h"

Employee::Employee() : name(" "), yearJoined(0), baseSalary(0) {}
Employee::Employee(string name) : name(name), yearJoined(0), baseSalary(0) {}
Employee::Employee(string name, int yearJoined): name(name), yearJoined(yearJoined), baseSalary(0) {}
Employee::Employee(string name, int yearJoined, int basesalary): name(name), yearJoined(yearJoined), baseSalary(basesalary) {}
Employee::Employee(const Employee& other) {
    this->name = other.name;
    this->yearJoined = other.yearJoined;
    this->baseSalary = other.baseSalary;    
}
string Employee::getName(){
    return this->name;
}

void Employee::input(){
    cout << "Enter name: ";
    getline(cin, this->name);
    
    cout << "Enter year joined: ";
    cin >> this->yearJoined;
    
    cout << "Enter base salary: ";
    cin >> this->baseSalary;
}

void Employee::output(){
    cout << "Name: " << this->name << "\n";
    cout << "Year joined: " << this->yearJoined << "\n";
    cout << "Base salary: " << this->baseSalary << "\n";
}

OfficeEmployee::OfficeEmployee(): Employee(), workingDays(0), allowance(0) {}
OfficeEmployee::OfficeEmployee(string name): Employee(name), workingDays(0), allowance(0) {}
OfficeEmployee::OfficeEmployee(string name, int yearJoined): Employee(name, yearJoined), workingDays(0) ,allowance(0) {}
OfficeEmployee::OfficeEmployee(string name, int yearJoined, int salary, int workingDays, int allowance): Employee(name, yearJoined, salary), workingDays(workingDays), allowance(allowance) {}
OfficeEmployee::OfficeEmployee(const OfficeEmployee& other): Employee(other), workingDays(other.workingDays), allowance(other.allowance) {}

void OfficeEmployee::input(){
    Employee::input();
    cout << "Enter working days: ";
    cin >> this->workingDays;
    cout << "Enter allowance: ";
    cin >> this->allowance;
    cin.ignore();
}
void OfficeEmployee::output(){
    Employee::output();
    cout << "Working days: " << this->workingDays << "\n";
    cout << "Allowance: " << this->allowance << "\n";
}
int OfficeEmployee::calculateSalary() const{
    return baseSalary + workingDays * 100000 + allowance;
}

ProductionEmployee::ProductionEmployee(): Employee(), numberOfProducts(0) {}
ProductionEmployee::ProductionEmployee(string name): Employee(name), numberOfProducts(0) {}
ProductionEmployee::ProductionEmployee(string name, int yearJoined): Employee(name, yearJoined), numberOfProducts(0) {}
ProductionEmployee::ProductionEmployee(string name, int yearJoined, int baseSalary, int numberOfProducts): Employee(name, yearJoined, baseSalary), numberOfProducts(numberOfProducts) {}
ProductionEmployee::ProductionEmployee(const ProductionEmployee& other): Employee(other), numberOfProducts(other.numberOfProducts) {}

void ProductionEmployee::input(){
    Employee::input();
    cout << "Enter number of products: ";
    cin >> this->numberOfProducts;
    cin.ignore();
}
void ProductionEmployee::output(){
    Employee::output();
    cout << "Number of products: " << this->numberOfProducts << "\n";
}
int ProductionEmployee::calculateSalary() const{
    return baseSalary + numberOfProducts * 2000;
}

ManagerEmployee::ManagerEmployee(): Employee(), positionFactor(0), bonus(0) {}
ManagerEmployee::ManagerEmployee(string name): Employee(name), positionFactor(0), bonus(0) {}
ManagerEmployee::ManagerEmployee(string name, int yearJoined): Employee(name, yearJoined), positionFactor(0), bonus(0) {}
ManagerEmployee::ManagerEmployee(string name, int yearJoined, int baseSalary, int postionFactor, int bonus): Employee(name, yearJoined, baseSalary), positionFactor(postionFactor), bonus(bonus) {}
ManagerEmployee::ManagerEmployee(const ManagerEmployee& other): Employee(other), positionFactor(other.positionFactor), bonus(other.bonus) {}

void ManagerEmployee::input(){
    Employee::input();
    cout << "Enter postion factor: ";
    cin >> this->positionFactor;
    cout << "Enter bonus: ";
    cin >> this->bonus;
    cin.ignore();
}

void ManagerEmployee::output(){
    Employee::output();
    cout << "Position Factor: " << this->positionFactor << "\n";
    cout << "Bonus: " << this->bonus << "\n";
}

int ManagerEmployee::calculateSalary() const{
    return baseSalary * positionFactor + bonus;
}

Company::Company(): companyName(""){}
Company::Company(string name): companyName(name) {}

void Company::inputEmployees(){
    int choice;
    do{
        cout << "Enter employee you need to insert: (1: office, 2: production, 3: manager, 0: exit)\n";
        cin >> choice;
        cin.ignore();
        switch (choice){
            case 1:{
                OfficeEmployee emp;
                emp.input();
                officeEmployees.push_back(emp);
                break;
            }
            case 2:{
                ProductionEmployee emp;
                emp.input();
                productionEmployees.push_back(emp);
                break;
            }
            case 3:{
                ManagerEmployee emp;
                emp.input();
                managerEmployees.push_back(emp);
                break;
            }
            case 0:{
                cout << "End insert employees.\n";
                break;
            }
            default:{
                cout << "Invalid commands.\n";
                break;
            }
        }
    } while (choice != 0);
}

void Company::printOfficeEmployees(){
    cout << "Office employees: \n";
    for (auto id : officeEmployees){
        id.output();
    }
}
void Company::printProdctionEmployees(){
    cout << "Production employees:\n";
    for (auto id : productionEmployees){
        id.output();
    }
}
void Company::printManagerEmployees(){
    cout << "Manager employees:\n";
    for (auto id : managerEmployees){
        id.output();
    }
}
void Company::displayEmployees(){
    cout << "List of employees: \n";
    cout << "Office Employees: \n";
    for (auto id : officeEmployees){
        id.output();
    }
    cout << "Production employees: \n";
    for (auto id : productionEmployees){
        id.output();
    }
    cout << "Manager employees: \n";
    for (auto id : managerEmployees){
        id.output();
    }
}
int Company::CalculateSalary(){
    int totalSalary = 0;
    for (auto id : officeEmployees) totalSalary += id.calculateSalary();
    for (auto id : productionEmployees) totalSalary += id.calculateSalary();
    for (auto id : managerEmployees) totalSalary += id.calculateSalary();
    return totalSalary;
}

void Company::findEmployeeByName(const string& searchName){
    bool found = false;
    for (auto id : officeEmployees){
        if (id.getName() == searchName){
            found = true;
            cout << "\nSearch completed.\n";
            id.output();
            break;
        }
    }
    for (auto id : productionEmployees){
        if (id.getName() == searchName){
            found = true;
            cout << "\nSearch completed.\n";
            id.output();
            break;
        }
    }
    for (auto id : managerEmployees){
        if (id.getName() == searchName){
            found = true;
            cout << "\nSearch completed.\n";
            id.output();
            break;
        }
    }
    if (!found){
        cout << "Can't find a person looking for.\n";
    }
}
void Company::loadOfficeEmployees(const string& file_name){
    ifstream fin(file_name);
    if (fin.is_open()){
        string line;
        while (getline(fin, line))
        {
            stringstream ss(line);
            string name;
            int yearJoined, workingDays, baseSalary, allowance;
            getline(ss, name, ',');
            ss >> yearJoined;
            ss.ignore();
            ss >> baseSalary;
            ss.ignore();
            ss >> workingDays;
            ss.ignore();
            ss >> allowance;
            OfficeEmployee emp(name, yearJoined, baseSalary, workingDays, allowance);
            officeEmployees.push_back(emp);
        }
        fin.close();
    }
    else{
        cerr << "Can't open the file.\n";
    }
}

void Company::loadProductionEmployees(const string& file_name){
    ifstream fin(file_name);
    if (fin.is_open()){
        string line;
        while (getline(fin, line)){
            stringstream ss(line);
            string name;
            int yearJoined, baseSalary, numberOfProducts;

            getline(ss, name, ',');
            ss >> yearJoined;
            ss.ignore();
            ss >> baseSalary;
            ss.ignore();
            ss >> numberOfProducts;
            ProductionEmployee emp(name, yearJoined, baseSalary, numberOfProducts);
            productionEmployees.push_back(emp);
        }
        fin.close();
    }
    else{
        cerr << "Can't open the files.\n";
    }
}

void Company::loadManagerEmployees(const string& file_name){
    ifstream fin(file_name);
    if (fin.is_open()){
        string line;
        while (getline(fin, line)){
            stringstream ss(line);
            string name;
            int yearJoined, baseSalary, positionFactor, bonus;

            getline(ss, name, ',');
            ss >> yearJoined;
            ss.ignore();
            ss >> baseSalary;
            ss.ignore();
            ss >> positionFactor;
            ss.ignore();
            ss >> bonus;
            ManagerEmployee emp(name, yearJoined, baseSalary, positionFactor, bonus);
            managerEmployees.push_back(emp);
        }
        fin.close();
    }
    else{
        cerr << "Can't open the file.\n";
    }
}