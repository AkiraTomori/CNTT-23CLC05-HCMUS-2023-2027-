#include "bai1.h"

int main(){
    cout << "Bai 1.......................................\n";
    OfficeEmployee officeEmp("Nguyen Van A", 2020, 5000000, 22, 1000000), oEmp;
    ProductionEmployee productEmp("Tran Thi B", 2019, 6000000, 1500), pEmp;
    ManagerEmployee managerEmp("Nguyen Thi C", 2018, 7000000, 2, 2000000), mEmp;

    cout << "Using constructors\n";
    cout << "Office Employee: \n";
    officeEmp.output();
    cout << "Salary: " << officeEmp.calculateSalary() << "\n";

    cout << "\nProduction Employee: \n";
    productEmp.output();
    cout << "Salary: " << productEmp.calculateSalary() << "\n";

    cout << "\nManager Employee: \n";
    managerEmp.output();
    cout << "Salary: " << managerEmp.calculateSalary() << "\n";
    system("pause");
    system("cls");

    cout << "Use input method()\n";
    cout << "Office Employee: \n";
    oEmp.input();
    oEmp.output();
    cout << "Salary: " << oEmp.calculateSalary() << "\n";
    cout << "\n";
    cout << "Production Employee: \n";
    pEmp.input();
    pEmp.output();
    cout << "Salary: " << pEmp.calculateSalary() << "\n";
    cout << "\n";
    cout << "Manager Employee.\n";
    mEmp.input();
    mEmp.output();
    cout << "Salary: " << mEmp.calculateSalary() << "\n";
    cout << "\n";
    system("pause");
    system("cls");
    
    // cout << "Load from files\n";
    // company.loadOfficeEmployees("../23127379_Week04_14/Other/office.txt");
    // company.printOfficeEmployees();
    // cout << "\n";
    // company.loadProductionEmployees("../23127379_Week04_14/Other/production.txt");
    // company.printProdctionEmployees();
    // cout << "\n";
    // company.loadManagerEmployees("../23127379_Week04_14/Other/manager.txt");
    // company.printManagerEmployees();
    // cout << "Total salary: " << company.CalculateSalary() << "\n";
    // company.findEmployeeByName("Nguyen Thi E");
    // company.findEmployeeByName("Thai Minh Huy");
    
    cout << "Enter company name: ";
    string companyName;
    getline(cin, companyName);
    cout << "Company Name: " << companyName << "\n";
    Company company(companyName);
    company.inputEmployees();
    company.printOfficeEmployees();
    cout << "\n";
    company.printProdctionEmployees();
    cout << "\n";
    company.printManagerEmployees();
    cout << "Total Salary: " << company.CalculateSalary() << "\n";
    company.findEmployeeByName("Nguyen Thi E");
    company.findEmployeeByName("Thai Minh Huy");
    system("pause");

    return 0;
}