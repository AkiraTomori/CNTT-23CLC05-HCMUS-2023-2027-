#include "bai4.h"

Student::Student(): studentId(nullptr), gpa(0.0), fullname(nullptr), address(nullptr) {}
Student::Student(char *studentID, double gpa, char *fullname, char *address) : gpa(gpa) {
    this->studentId = new char [strlen(studentID) + 1];
    strcpy(this->studentId, studentID);
    this->fullname = new char [strlen(fullname) + 1];
    strcpy(this->fullname, fullname);
    this->address = new char [strlen(address) + 1];
    strcpy(this->address, address);
}
Student::Student(const Student& other)
{
    this->gpa = other.gpa;
    if (other.studentId)
    {
        this->studentId = new char[strlen(other.studentId) + 1];
        strcpy(this->studentId, other.studentId);
    }
    else
        this->studentId = nullptr;
    if (other.fullname)
    {
        this->fullname = new char[strlen(other.fullname) + 1];
        strcpy(this->fullname, other.fullname);
    }
    else
        this->fullname = nullptr;
    if (other.address)
    {
        this->address = new char[strlen(other.address) + 1];
        strcpy(this->address, other.address);
    }
    else
        this->address = nullptr;
}
Student::~Student()
{
    this->gpa = 0.0;
    delete [] this->studentId;
    delete [] this->fullname;
    delete [] this->address;
}
istream &operator>>(istream &in, Student &s)
{
    char buffer[100];
    cout << "Enter Student ID: ";
    in >> ws;
    in.getline(buffer, 100);
    s.studentId = new char[strlen(buffer) + 1];
    strcpy(s.studentId, buffer);

    cout << "Gpa: ";
    in >> s.gpa;

    cout << "Enter full name: ";
    in >> ws;
    in.getline(buffer, 100);
    s.fullname = new char[strlen(buffer) + 1];
    strcpy(s.fullname, buffer);

    cout << "Enter address: ";
    in >> ws;
    in.getline(buffer, 100);
    s.address = new char[strlen(buffer) + 1];
    strcpy(s.address, buffer);
    return in;
}
ostream& operator << (ostream& out, const Student& other)
{
    out << "Student ID: " << (other.studentId ? other.studentId : "Unknown") << "\n";
    out << "GPA: " << other.gpa << "\n";
    out << "Fullname: " << (other.fullname ? other.fullname : "Unknown") << "\n";
    out << "Address: " << (other.address ? other.address : "Unknown") << "\n";
    return out;
}