#include "bai3.h"

Queue::Queue(): arr(nullptr), front(0), rear(-1), size(0), count(0) {}
Queue::Queue(int size): front(0), rear(-1), size(size), count(0){
    arr = new int [size];
}
Queue::~Queue(){
    delete []arr;
    front = rear = -1;
    size = count = 0;
}
bool Queue::isEmpty()
{
    return count == 0;
}
bool Queue::isFull()
{
    return count == size;
}
bool Queue::enQueue(int value)
{
    if (isFull())
    {
        cout << "Queue is full, cannot enqueue.\n";
        return false;
    }
    rear = (rear + 1) % size;
    arr[rear] = value;
    count++;
    return true;
}
bool Queue::deQueue()
{
    if (isEmpty())
    {
        cout << "Queue is empty.\n";
        return false;
    }
    front = (front + 1) % size;
    count--;
    return true;
}
int Queue::getFrontValue()
{
    if (isEmpty())
    {
        cout << "Queue is empty, can't get the front value.\n";
        return -1;
    }
    return arr[front];
}