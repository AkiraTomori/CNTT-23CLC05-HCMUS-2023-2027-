#include "bai1.h"

Fraction::Fraction() : numerator(0), demorator(1) {}
Fraction::Fraction(int numerator, int demorator) : numerator(numerator), demorator(demorator) {}

int Fraction::FindGreatestCommonDivisor(int a, int b)
{
    if (b == 0) return a;
    else return FindGreatestCommonDivisor(b, a % b);
}
void Fraction::Simplify()
{
    int GCD = FindGreatestCommonDivisor(this->numerator, this->demorator);
    this->numerator /= GCD;
    this->demorator /= GCD;
    if (this->demorator < 0)
    {
        this->numerator = -this->numerator;
        this->demorator = -this->demorator;
    }
}
istream& operator>>(istream &in, Fraction &p)
{
    cout << "Numerator: ";
    in >> p.numerator;
    do
    {
        cout << "Demorator: ";
        in >> p.demorator;
        if (p.demorator == 0)
        {
            cout << "Demorator cannot be zero.\n";
        }
    } while (p.demorator == 0);
    return in;
}
ostream& operator<<(ostream &out, const Fraction &p)
{
    out << "Fraction form: " << p.numerator << "/" << p.demorator << "\n";
    if (p.demorator != 0)
        out << "Decimal form: " << (double) p.numerator / p.demorator << "\n";
    else
        out << "Cannot divied zero.\n";
    return out;
}
Fraction operator+(const Fraction& p1, const Fraction &p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.demorator + p1.demorator * p2.numerator;
    result.demorator = p1.demorator * p2.demorator;
    result.Simplify();
    return result;
}
Fraction operator-(const Fraction& p1, const Fraction &p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.demorator - p1.demorator * p2.numerator;
    result.demorator = p1.demorator * p2.demorator;
    result.Simplify();
    return result;
}
Fraction operator*(const Fraction& p1, const Fraction& p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.numerator;
    result.demorator = p1.demorator * p2.demorator;
    result.Simplify();
    return result;
}
Fraction operator/(const Fraction &p1, const Fraction& p2)
{
    Fraction result;
    if (p2.numerator == 0)
        {
            cout << "Cannot divide by zero.\n";
            return p1;
        }
    result.numerator = p1.numerator * p2.demorator;
    result.demorator = p1.demorator * p2.numerator;
    result.Simplify();
    return result;
}
Fraction& Fraction::operator=(const Fraction& p)
{
    if (this == &p) return *this;
    this->numerator = p.numerator;
    this->demorator = p.demorator;
    return *this;
}
bool Fraction::operator==(const Fraction &other)
{
    return ((this->numerator == other.numerator) && (this->demorator == this->demorator));
}
bool Fraction::operator!=(const Fraction& other)
{
    double f1 = (double)(this->numerator)/(this->demorator);
    double f2 = (double)(other.numerator)/(other.demorator);
    return f1 != f2;
}
int Fraction::operator>=(const Fraction& other)
{
    double f1 = (double)(this->numerator) / (this->demorator);
    double f2 = (double)(other.numerator) / (other.demorator);
    if (f1 >= f2)
        return 1;
    else if (f1 == f2)
        return 0;
    else
        return -1;
}
int Fraction::operator>(const Fraction& other)
{
    double f1 = (double)(this->numerator) / (this->demorator);
    double f2 = (double)(other.numerator) / (other.demorator);
    if (f1 > f2)
        return 1;
    else if (f1 == f2)
        return 0;
    else
        return -1;
}
int Fraction::operator<=(const Fraction& other)
{
    double f1 = (double)(this->numerator) / (this->demorator);
    double f2 = (double)(other.numerator) / (other.demorator);
    if (f1 <= f2)
        return 1;
    else if (f1 == f2)
        return 0;
    else
        return -1;
}
int Fraction::operator<(const Fraction& other)
{
    double f1 = (double)(this->numerator) / (this->demorator);
    double f2 = (double)(other.numerator) / (other.demorator);
    if (f1 < f2)
        return 1;
    else if (f1 == f2)
        return 0;
    else
        return -1;
}
Fraction operator+(const Fraction &p, int x)
{
    Fraction result;
    result.numerator = p.numerator + (x*p.demorator);
    result.demorator = p.demorator;
    result.Simplify();
    return result;
}
Fraction operator+(int x, const Fraction &p)
{
    Fraction result;
    result.numerator = p.numerator + (x*p.demorator);
    result.demorator = p.demorator;
    result.Simplify();
    return result;
}
Fraction operator-(const Fraction& p, int x)
{
    Fraction result;
    result.numerator = p.numerator - (x*p.demorator);
    result.demorator = p.demorator;
    result.Simplify();
    return result;
}
Fraction operator-(int x, const Fraction&p)
{
    Fraction result;
    result.numerator = p.numerator - (x*p.demorator);
    result.demorator = p.demorator;
    result.Simplify();
    return result;
}

Fraction operator*(const Fraction&p, int x)
{
    Fraction result;
    result.numerator = p.numerator * x;
    result.demorator = p.demorator;
    result.Simplify();
    return result;
}
Fraction operator*(int x, const Fraction& p)
{
    Fraction result;
    result.numerator = p.numerator * x;
    result.demorator = p.demorator;
    result.Simplify();
    return result;
}
Fraction operator/(const Fraction& p, int x)
{
    if (x == 0)
    {
        cout << "Cannot divide by zero!.\n";
        return p;
    }
    Fraction result;
    result.numerator = p.numerator;
    result.demorator = p.demorator * x;
    result.Simplify();
    return result;
}
Fraction operator/(int x, const Fraction& p)
{
    if (x == 0)
    {
        cout << "Cannot divide by zero!.\n";
        return p;
    }
    Fraction result;
    result.numerator = p.numerator;
    result.demorator = p.demorator * x;
    result.Simplify();
    return result;
}
Fraction& Fraction::operator+=(const Fraction& other)
{
    this->numerator = this->numerator * other.demorator + this->demorator * other.numerator;
    this->demorator = this->demorator * other.demorator;
    this->Simplify();
    return *this;
}
Fraction& Fraction::operator-=(const Fraction& other)
{
    this->numerator = this->numerator * other.demorator - this->demorator * other.numerator;
    this->demorator = this->demorator * other.demorator;
    this->Simplify();
    return *this;   
}
Fraction& Fraction::operator*=(const Fraction& other)
{
    this->numerator = this->numerator * other.numerator;
    this->demorator = this->demorator * other.demorator;
    this->Simplify();
    return *this;
}
Fraction& Fraction::operator/=(const Fraction& other)
{
    if (other.numerator == 0)
    {
        cout << "Cannot divided by zero!\n";
        return *this;
    }
    this->numerator = this->numerator * other.demorator;
    this->demorator = this->demorator * other.numerator;
    this->Simplify();
    return *this;
}
Fraction& Fraction::operator++()
{
    this->numerator += this->demorator;
    return *this;
}
Fraction Fraction::operator++(int)
{
    Fraction temp = *this;
    this->numerator += this->demorator;
    return temp;
}
Fraction& Fraction::operator--()
{
    this->numerator -= this->demorator;
    return *this;
}
Fraction Fraction::operator--(int)
{
    Fraction temp = *this;
    this->numerator -= this->demorator;
    return temp;
}
Fraction::operator int() const
{
    return this->numerator/this->demorator;
}
Fraction::operator float() const
{
    return static_cast<float>(this->numerator)/(this->demorator);
}