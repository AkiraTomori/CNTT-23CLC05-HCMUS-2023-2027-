#include "bai1.h"
#include "bai2.h"
#include "bai3.h"
#include "bai4.h"

int main()
{
    cout << "Bai 1.\n";
    Fraction f1, f2; // 0/1
    Fraction f3(1, -7); // -1/7
    Fraction f4(f3); // Copy constructor
    Fraction f5 = f2; // Copy constructor
    Fraction f6, f7, f8; // Default constructor;
    f6 = f3;
    f7 = f1 + f5;
    f8 = f2 - f4;
    f3 = f1 * f7;
    f5 = f6 / f2;
    if (f2 == f3)
        cout << "f2 == f3" << "\n";
    if (f3 != f1)
        cout << "f3 != f1" << "\n";
    if (f2 >= f5)
        cout << "f2 >= f5" << "\n";
    if (f2 > f5)
        cout << "f2 > f5" << "\n";
    if (f5 <= f3)
        cout << "f5 <= f3" << "\n";
    if (f5 < f3)
        cout << "f5 < f3" << "\n";
    f1 = f2 + 3;
    f3 = -7 + f1;
    f5 = 7 * f3;
    f6 = f4 - 6;
    cout << f3;
    cout << f6;
    f1 += f5;
    f6 -= f7;
    f8 *= f1;
    f8 /= f2;
    cout << f8++;
    cout << ++f7;
    cout << f8--;
    cout << f7--;
    f3 += Fraction(11, 2);
    int x = int(f3);
    float f = (float)f3;
    cout << x << "\n";
    cout << f << "\n";

    cout << "\nBai 2\n";
    Stack s(5);
    s.push(10);
    s.push(20);
    s.push(30);
    cout << "Top value: " << s.getTopValue() << "\n";

    s.pop();
    cout << "Top value after pop: " << s.getTopValue() << "\n";
    s.pop();
    s.pop();
    s.pop();
    
    cout << "\nBai 3\n";
    Queue q(5);
    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);
    cout << "Front value: " << q.getFrontValue() << "\n";

    q.deQueue();
    cout << "Front value after dequeue: " << q.getFrontValue() << "\n";

    q.enQueue(40);
    q.enQueue(50);
    q.enQueue(60);
    q.enQueue(70);
    
    cout << "\nBai 4\n";
    Student s1;
    cout << "Enter Student Information: " << "\n";
    cin >> s1;

    cout << "Student Information: " << "\n";
    cout << s1;

    Student s2 = s1;
    cout << "Copied Student's information.\n";
    cout << s2;
    return 0;
}