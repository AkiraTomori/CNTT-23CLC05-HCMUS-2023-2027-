#pragma once
#include <iostream>
using namespace std;

class Queue
{
    private:
        int *arr;
        int front;
        int rear;
        int size;
        int count;
    public:
        Queue();
        Queue(int size);
        ~Queue();
        bool isEmpty();
        bool isFull();
        bool enQueue(int value);
        bool deQueue();
        int getFrontValue();
};