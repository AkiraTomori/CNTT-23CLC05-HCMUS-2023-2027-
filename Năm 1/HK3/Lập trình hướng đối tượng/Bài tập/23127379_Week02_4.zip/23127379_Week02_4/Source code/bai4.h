#pragma once
#include <iostream>
#include <string.h>
#include <string>

using namespace std;

class Student{
    private:
        char *studentId;
        double gpa;
        char *fullname;
        char *address;
    public:
        Student();
        Student(char *studentId, double gpa, char *fullname, char *address);
        Student(const Student& other);
        ~Student();
        friend istream& operator>> (istream &in, Student &);
        friend ostream& operator<< (ostream &out, const Student& other);
};