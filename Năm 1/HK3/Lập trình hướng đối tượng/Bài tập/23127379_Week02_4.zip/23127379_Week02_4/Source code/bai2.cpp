#include "bai2.h"

Stack::Stack() : arr(nullptr), topIndex(-1), size(0) {}
Stack::Stack(int size) : size(size), topIndex(-1)
{
    arr = new int [size];
}
Stack::~Stack()
{
    delete [] arr;
    topIndex = -1;
    size = 0;
}
bool Stack::isEmpty()
{
    return topIndex == -1;
}
bool Stack::isFull()
{
    return topIndex == size - 1;
}
bool Stack::push(int value)
{
    if (isFull())
    {
        cout << "Stack is full. Cannot push.\n";
        return false;
    }
    arr[++topIndex] = value;
    return true;
}
bool Stack::pop()
{
    if (isEmpty())
    {
        cout << "Stack is empty.\n";
        return false;
    }
    topIndex--;
    return true;
}
int Stack::getTopValue() {
    if (isEmpty())
    {
        cout << "Stack is empty. No top value\n";
        return -1;
    }
    return arr[topIndex];
}