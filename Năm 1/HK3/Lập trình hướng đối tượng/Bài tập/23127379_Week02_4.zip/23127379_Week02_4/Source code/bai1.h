#pragma once
#include <iostream>
#include <math.h>
using namespace std;

class Fraction
{
    private:
        int numerator;
        int demorator;
        
        int FindGreatestCommonDivisor(int a, int b);
        void Simplify();
    public: 
        Fraction();
        Fraction(int, int);
        
        friend istream& operator >> (istream &in, Fraction &);
        friend ostream& operator << (ostream &out, const Fraction&);
        friend Fraction operator+(const Fraction&, const Fraction&);
        friend Fraction operator-(const Fraction&, const Fraction&);
        friend Fraction operator*(const Fraction&, const Fraction&);
        friend Fraction operator/(const Fraction&, const Fraction&);
        
        Fraction& operator=(const Fraction &p);
        bool operator==(const Fraction &other);
        bool operator!=(const Fraction& other);
        int operator>=(const Fraction& other);
        int operator>(const Fraction& other);
        int operator<=(const Fraction& other);
        int operator<(const Fraction& other);

        friend Fraction operator+(const Fraction& ,int x);
        friend Fraction operator+(int x, const Fraction&);
        friend Fraction operator-(const Fraction& ,int x);
        friend Fraction operator-(int x, const Fraction&);
        friend Fraction operator*(const Fraction&, int x);
        friend Fraction operator*(int x, const Fraction&);
        friend Fraction operator/(const Fraction&, int x);
        friend Fraction operator/(int x, const Fraction&);

        Fraction& operator +=(const Fraction&);
        Fraction& operator -=(const Fraction&);
        Fraction& operator *=(const Fraction&);
        Fraction& operator /=(const Fraction&);

        Fraction& operator++();
        Fraction operator++(int);
        Fraction& operator--();
        Fraction operator--(int);

        operator int() const;
        operator float() const;
};