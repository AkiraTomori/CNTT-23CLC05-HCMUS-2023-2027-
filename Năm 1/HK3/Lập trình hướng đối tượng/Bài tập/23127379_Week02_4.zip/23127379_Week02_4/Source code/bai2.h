#pragma once
#include <iostream>
using namespace std;

class Stack
{
    private:
        int *arr;
        int topIndex;
        int size;
    public:
        Stack();
        Stack(int size);
        ~Stack();
        bool isEmpty();
        bool isFull();
        bool push(int);
        bool pop();
        int getTopValue() ;
};