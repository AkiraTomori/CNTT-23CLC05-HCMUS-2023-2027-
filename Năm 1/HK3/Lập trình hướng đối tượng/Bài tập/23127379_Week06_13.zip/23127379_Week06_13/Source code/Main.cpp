#include "bai1.h"

int main()
{
    Company company;
    company.inputEmployees();

    cout << "\nList of employees: \n";
    company.displayEmployees();

    cout << "Total salary: " << company.calculateTotalSalary() << "\n";
    cout << "Average Salary: " << setprecision(2) << fixed << company.calculateAverateTotalSalary() << "\n";
    Employee* highestSalaryEmp = company.findHighestSalaryEmployee();
    if (highestSalaryEmp){
        cout << "Highest's salary employee: \n";
        highestSalaryEmp->output();
        cout << " | Salary: " << highestSalaryEmp->calculateSalary() << "\n";
    }
    else{
        cout << "No employees in list.\n";
    }

    cout << "Number of office employees: " << company.countOfficeEmployees() << "\n";
    cout << "Number of production employees: " << company.countProductionEmployees() << "\n";
    cout << "List of employees have lower 3 millions salary: \n";
    company.getListLower3mils();
    string searchName;
    cout << "Enter name to find: ";
    getline(cin, searchName);
    Employee *empName = company.findName(searchName);
    if (empName){
        cout << "Found by name.\n";
        empName->output();
        cout << " | Salary: " << empName->calculateSalary() << "\n";
    }
    else{
        cout << "Can't find\n";
    }
    
    string searchId;
    cout << "Enter id to find: ";
    getline(cin, searchId);
    Employee *empId = company.findId(searchId);
    if (empId){
        cout << "Found by id\n";
        empId->output();
        cout << " | Salary: " << empId->calculateSalary() << "\n";
    }
    else{
        cout << "Can't find.\n";
    }
    cout << "Employees have birth month May: " << company.countEmployeeHasMayBirthMonth() << "\n";
    return 0;
}