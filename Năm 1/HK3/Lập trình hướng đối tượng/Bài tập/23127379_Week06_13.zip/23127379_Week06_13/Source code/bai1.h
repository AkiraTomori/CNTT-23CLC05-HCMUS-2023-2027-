#pragma once
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

// Lop co so 
class Employee{
    protected:
        string id;
        string name;
        int yearJoined;
        int baseSalary;
        int birthDay;
        int birthMonth;
        int birthYear;
    public:
        Employee();
        Employee(string name);
        Employee(string name, int yearJoined);
        Employee(string name, int yearJoinded, int baseSalary);
        Employee(const Employee& other);
        string getId();
        string getName();
        int getBirthMonth();

        // virtual ~Employee();

        virtual void input();
        virtual void output();

        virtual int calculateSalary() const = 0;
};

class OfficeEmployee: public Employee{
    private:
        int workingDays;
        int allowance;
    public:
        OfficeEmployee();
        OfficeEmployee(string name);
        OfficeEmployee(string name, int yearJoined);
        OfficeEmployee(string name, int yearJoined, int baseSalary, int WorkingDays, int allowance);
        OfficeEmployee(const OfficeEmployee& other);

        void input();
        void output();
        int calculateSalary() const;
};

class ProductionEmployee : public Employee{
    private:
        int numberOfProducts;
    public:
        ProductionEmployee();
        ProductionEmployee(string name);
        ProductionEmployee(string name, int yearJoined);
        ProductionEmployee(string name, int yearJoined, int baseSalary, int numberOfProducts);
        ProductionEmployee(const ProductionEmployee& other);

        void input();
        void output();
        int calculateSalary() const;
};

class ManagerEmployee : public Employee{
    private:
        int positionFactor;
        int bonus;
    public:
        ManagerEmployee();
        ManagerEmployee(string name);
        ManagerEmployee(string name, int yearJoined);
        ManagerEmployee(string name, int yearJoined, int baseSalary, int positionFactor, int bonus);
        ManagerEmployee(const ManagerEmployee& other);

        void input();
        void output();
        int calculateSalary() const;
};

class Company{
    private:
        vector<Employee*> employees;
    public:
        ~Company();
        void inputEmployees();
        void displayEmployees();
        int calculateTotalSalary();
        Employee* findHighestSalaryEmployee();

        int countProductionEmployees();
        int countOfficeEmployees();
        double calculateAverateTotalSalary();
        void getListLower3mils();
        Employee *findName(const std::string& nameFind);
        Employee *findId(const std::string& Id);
        int countEmployeeHasMayBirthMonth();
};