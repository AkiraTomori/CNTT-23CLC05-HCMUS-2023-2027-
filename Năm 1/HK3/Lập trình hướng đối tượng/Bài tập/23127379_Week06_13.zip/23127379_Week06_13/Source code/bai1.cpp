#include "bai1.h"

Employee::Employee() : name(" "), yearJoined(0), baseSalary(0) {}
Employee::Employee(string name) : name(name), yearJoined(0), baseSalary(0) {}
Employee::Employee(string name, int yearJoined): name(name), yearJoined(yearJoined), baseSalary(0) {}
Employee::Employee(string name, int yearJoined, int basesalary): name(name), yearJoined(yearJoined), baseSalary(basesalary) {}
Employee::Employee(const Employee& other) {
    this->name = other.name;
    this->yearJoined = other.yearJoined;
    this->baseSalary = other.baseSalary;    
}

void Employee::input(){
    cout << "Enter id: ";
    getline(cin, this->id);
    cout << "Enter name: ";
    getline(cin, this->name);
    cout << "Enter date of birth: ";
    cin >> birthDay >> birthMonth >> birthYear;
    cout << "Enter year joined: ";
    cin >> this->yearJoined;
    
    cout << "Enter base salary: ";
    cin >> this->baseSalary;
}

void Employee::output(){
    cout << "Name: " << this->name
         << " | ID: " << this->id
         << " | Date of birth: " << this->birthDay << "/" << this->birthMonth << "/" << this->birthYear
         << " | Year joined: " << this->yearJoined
         << " | Base salary: " << this->baseSalary;
}
int Employee::getBirthMonth(){
    return this->birthMonth;
}
string Employee::getName(){
    return this->name;
}
string Employee::getId(){
    return this->id;
}
OfficeEmployee::OfficeEmployee(): Employee(), workingDays(0), allowance(0) {}
OfficeEmployee::OfficeEmployee(string name): Employee(name), workingDays(0), allowance(0) {}
OfficeEmployee::OfficeEmployee(string name, int yearJoined): Employee(name, yearJoined), workingDays(0) ,allowance(0) {}
OfficeEmployee::OfficeEmployee(string name, int yearJoined, int salary, int workingDays, int allowance): Employee(name, yearJoined, salary), workingDays(workingDays), allowance(allowance) {}
OfficeEmployee::OfficeEmployee(const OfficeEmployee& other): Employee(other), workingDays(other.workingDays), allowance(other.allowance) {}

void OfficeEmployee::input(){
    Employee::input();
    cout << "Enter working days: ";
    cin >> this->workingDays;
    cout << "Enter allowance: ";
    cin >> this->allowance;
    cin.ignore();
}
void OfficeEmployee::output(){
    Employee::output();
    cout << " | Working days: " << this->workingDays
         << " | Allowance: " << this->allowance;
}
int OfficeEmployee::calculateSalary() const{
    return baseSalary + workingDays * 100000 + allowance;
}

ProductionEmployee::ProductionEmployee(): Employee(), numberOfProducts(0) {}
ProductionEmployee::ProductionEmployee(string name): Employee(name), numberOfProducts(0) {}
ProductionEmployee::ProductionEmployee(string name, int yearJoined): Employee(name, yearJoined), numberOfProducts(0) {}
ProductionEmployee::ProductionEmployee(string name, int yearJoined, int baseSalary, int numberOfProducts): Employee(name, yearJoined, baseSalary), numberOfProducts(numberOfProducts) {}
ProductionEmployee::ProductionEmployee(const ProductionEmployee& other): Employee(other), numberOfProducts(other.numberOfProducts) {}

void ProductionEmployee::input(){
    Employee::input();
    cout << "Enter number of products: ";
    cin >> this->numberOfProducts;
    cin.ignore();
}

void ProductionEmployee::output(){
    Employee::output();
    cout << " | Number of products: " << this->numberOfProducts;
}

int ProductionEmployee::calculateSalary() const{
    return baseSalary + numberOfProducts * 2000;
}

ManagerEmployee::ManagerEmployee(): Employee(), positionFactor(0), bonus(0) {}
ManagerEmployee::ManagerEmployee(string name): Employee(name), positionFactor(0), bonus(0) {}
ManagerEmployee::ManagerEmployee(string name, int yearJoined): Employee(name, yearJoined), positionFactor(0), bonus(0) {}
ManagerEmployee::ManagerEmployee(string name, int yearJoined, int baseSalary, int postionFactor, int bonus): Employee(name, yearJoined, baseSalary), positionFactor(postionFactor), bonus(bonus) {}
ManagerEmployee::ManagerEmployee(const ManagerEmployee& other): Employee(other), positionFactor(other.positionFactor), bonus(other.bonus) {}

void ManagerEmployee::input(){
    Employee::input();
    cout << "Enter position factor: ";
    cin >> this->positionFactor;
    cout << "Enter bonus: ";
    cin >> this->bonus;
    cin.ignore();
}
void ManagerEmployee::output(){
    Employee::output();
    cout << " | Position factor: " << this->positionFactor
         << " | Bonus: " << this->bonus;
}
int ManagerEmployee::calculateSalary() const{
    return baseSalary * positionFactor + bonus;
}
Company::~Company(){
    for (Employee* emp : employees){
        delete emp;
    }
}
void Company::inputEmployees(){
    int n;
    cout << "Number of employees: ";
    cin >> n;
    cin.ignore();
    for (int i = 0; i < n; i++){
        int type;
        cout << "\nType of employees (1: office, 2: production, 3: manager): ";
        cin >> type;
        cin.ignore();
        Employee *emp = nullptr;
        switch(type){
            case 1: emp = new OfficeEmployee(); break;
            case 2: emp = new ProductionEmployee(); break;
            case 3: emp = new ManagerEmployee(); break;
            default:
                cout << "Invalid type !\n";
                continue;
        }
        emp->input();
        employees.push_back(emp);
    }
}

void Company::displayEmployees(){
    for (Employee *emp : employees){
        emp->output();
        cout << " | Salary: " << emp->calculateSalary() << "\n";
    }
}
int Company::calculateTotalSalary(){
    int total = 0;
    for (Employee *emp : employees){
        total += emp->calculateSalary();
    }
    return total;
}
Employee* Company::findHighestSalaryEmployee(){
    if (employees.empty()) return nullptr;
    Employee *highestSalaryEmp = employees[0];
    for (auto &emp : employees){
        if (emp->calculateSalary() > highestSalaryEmp->calculateSalary()){
            highestSalaryEmp = emp;
        }
    }
    return highestSalaryEmp;
}

int Company::countOfficeEmployees(){
    int count = 0;
    for (Employee *emp : employees){
        if (dynamic_cast<OfficeEmployee*>(emp) != nullptr){
            count++;
        }
    }
    return count;
}

int Company::countProductionEmployees(){
    int count = 0;
    for (Employee *emp : employees){
        if (dynamic_cast<ProductionEmployee*>(emp) != nullptr){
            count++;
        }
    }
    return count;
}
double Company::calculateAverateTotalSalary(){
    int Total_Salary = calculateTotalSalary();
    return (double)(Total_Salary) / (employees.size());
}
void Company::getListLower3mils(){
    int lowerBoundSalary = 3000000;
    bool found = false;
    for (auto& emp : employees){
        if (emp->calculateSalary() < lowerBoundSalary){
            emp->output();
            cout << " | Salary: " << emp->calculateSalary() << "\n";
            found = true;
        }
    }
    if (!found){
        cout << "No employees have salary below 3 milions.\n";
    }
}

Employee* Company::findName(const std::string &name){
    if (employees.empty()) return nullptr;
    for (auto emp : employees){
        if (emp->getName() == name){
            return emp;
        }
    }
    return nullptr;
}

Employee* Company::findId(const std::string &Id){
    if (employees.empty()) return nullptr;
    for (auto emp : employees){
        if (emp->getId() == Id){
            return emp;
        }
    }
    return nullptr;
}
int Company::countEmployeeHasMayBirthMonth(){
    int count = 0;
    for (auto emp : employees){
        if (emp->getBirthMonth() == 5){
            count++;
        }
    }
    return count;
}