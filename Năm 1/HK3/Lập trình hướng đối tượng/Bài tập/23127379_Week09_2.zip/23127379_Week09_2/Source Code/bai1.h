#pragma once
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <algorithm>

using namespace std;

class Product{
    private:
        int productId;
        string nameProduct;
        int price;
        int quantity;
    public:
        Product();
        Product(int id, string nameProduct, int price, int quantity);

        int getTotalPrice();
        void printProduct();
};

class PaymentMethod{
    public:
        virtual void pay(int amount) = 0;
        virtual ~PaymentMethod();
};

class CashPayment : public PaymentMethod{
    public:
        void pay(int amount);
};

class ATMPayment : public PaymentMethod{
    public:
        void pay(int amount);
};

class MomoPayment : public PaymentMethod{
    public:
        void pay(int amount);
};

class ZalopayPayment : public PaymentMethod{
    public: 
        void pay(int amount);
};

class Order{
    private:
        int orderId;
        string customerName;
        string customerPhone;
        string customerAddress;
        vector<Product> products;
        int totalPrice;
        PaymentMethod* paymentMethod;

        int calculateTotalAmount();
    public:
        Order(int id, string name, string phone, string address, vector<Product> products);
        void setPaymentMethod(PaymentMethod* method);
        void pay();
        int getTotalAmount();
        void printOrder();
};