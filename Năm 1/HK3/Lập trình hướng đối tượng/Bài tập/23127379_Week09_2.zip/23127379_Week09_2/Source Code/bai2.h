#pragma once
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <algorithm>
using namespace std;

class DragonState;
class Dragon;

class Dragon{
    private:
        string name;
        int damage;
        int defend;
        int healthpoint;
        int level;
        DragonState* initState;
    public:
        Dragon(string name, int dame, int def, int hp, int lv, DragonState* state);

        string getName();
        int getDame();
        int getDefend();
        int getHealthPoint();
        int getLevel();
        void setState(DragonState* state);
        void printStats();

        void calculatePower();
        void attack();
        void move();
};

class DragonState{
    public:
        virtual void calculatePower(Dragon* dragon) = 0;
        virtual void attack(Dragon* dragon) = 0;
        virtual void move(Dragon* dragon) = 0;
        virtual ~DragonState();
};

class NormalState: public DragonState{
    public:
        void calculatePower(Dragon* dragon);
        void attack(Dragon* dragon);
        void move(Dragon* dragon);
};

class FuryState: public DragonState{
    public:
        void calculatePower(Dragon* dragon);
        void attack(Dragon* dragon);
        void move(Dragon* dragon);
};

class DefendState: public DragonState{
    public:
        void calculatePower(Dragon* dragon);
        void attack(Dragon* dragon);
        void move(Dragon* dragon);
};