#include "bai1.h"

Product::Product(): productId(0), nameProduct(""), price(0.0), quantity(0) {}
Product::Product(int id, string nameProduct, int price, int quantity) : productId(id), nameProduct(nameProduct), price(price), quantity(quantity) {}

int Product::getTotalPrice(){
    return price * quantity;
}

void Product::printProduct(){
    cout << "Ma san pham: " << productId
         << " | " << "Ten san pham: " << nameProduct
         << " | " << "Gia san pham: " << price
         << " | " << "So luong san pham: " << quantity << "\n";
}
PaymentMethod::~PaymentMethod(){}
void CashPayment::pay(int amount){
    cout << "Da thanh toan " << amount << " d bang tien mat.\n";
}

void ATMPayment::pay(int amount){
    cout << "Da thanh toan " << amount << " d bang the ATM.\n";
}

void MomoPayment::pay(int amount){
    cout << "Da thanh toan " << amount << " d bang momo.\n";
}

void ZalopayPayment::pay(int amount){
    cout << "Da thanh toan " << amount << " d bang zalopay.\n";
}

int Order::calculateTotalAmount(){
    double sum = 0;
    for (auto product : products){
        sum += product.getTotalPrice();
    }
    return sum;
}

int Order::getTotalAmount(){
    return this->totalPrice;
}

Order::Order(int id, string name, string phone, string address, vector<Product> products): orderId(id), customerName(name), customerPhone(phone), customerAddress(address), products(products), paymentMethod(nullptr) {
    totalPrice = calculateTotalAmount();
}

void Order::setPaymentMethod(PaymentMethod *method){
    paymentMethod = method;
}

void Order::pay(){
    if (paymentMethod){
        paymentMethod->pay(totalPrice);
    }
    else{
        cout << "Chua chon phuong thuc thanh toan.\n";
    }
}
void Order::printOrder(){
    cout << "Ma don: " << orderId
         << " | " << "Ten khach hang: " << customerName
         << " | " << "So dien thoai: " << customerPhone
         << " | " << "Dia chi: " << customerAddress << "\n"; 
}