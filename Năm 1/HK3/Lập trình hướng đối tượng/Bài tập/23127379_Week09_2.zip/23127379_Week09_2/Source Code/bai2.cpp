#include "bai2.h"

Dragon::Dragon(string name, int dame, int def, int hp, int lv, DragonState* state){
    this->name = name;
    this->damage = dame;
    this->defend = def;
    this->healthpoint = hp;
    this->level = lv;
    this->initState = state;
}

string Dragon::getName(){
    return this->name;
}

int Dragon::getDame(){
    return this->damage;
}

int Dragon::getDefend(){
    return this->defend;
}

int Dragon::getLevel(){
    return this->level;
}

int Dragon::getHealthPoint(){
    return this->healthpoint;
}

void Dragon::setState(DragonState* state){
    this->initState = state;
}

void Dragon::printStats(){
    cout << "Tan cong: " << this->damage
         << " | Phong thu: " << this->defend
         << " | Cap do: " << this->level
         << " | Mau: " << this->healthpoint
         << " | Ten: " << this->name << "\n";
}

void Dragon::calculatePower(){
    initState->calculatePower(this);
}

void Dragon::attack(){
    initState->attack(this);
}

void Dragon::move(){
    initState->move(this);
}

DragonState::~DragonState(){}
void NormalState::calculatePower(Dragon* dragon){
    int power = (dragon->getDame() + dragon->getDefend() + dragon->getHealthPoint()) * dragon->getLevel();
    cout << "Suc manh cua rong khi o trang thai binh thuong: " << power << "\n";
}

void NormalState::attack(Dragon* dragon){
    cout << "Rong " << dragon->getName() << " phun lua mau vang.\n";
}

void NormalState::move(Dragon* dragon){
    cout << "Rong " << dragon->getName() << " di chuyen toc do binh thuong.\n";
}

void FuryState::calculatePower(Dragon* dragon){
    int power = (2 * dragon->getDame() + dragon->getDefend() + dragon->getHealthPoint()) * dragon->getLevel();
    cout << "Suc manh cua rong khi o trang thai cuong no: " << power << "\n";
}

void FuryState::attack(Dragon* dragon){
    cout << "Rong " << dragon->getName() << " phun lua mau do.\n";
}

void FuryState::move(Dragon* dragon){
    cout << "Rong " << dragon->getName() << " di chuyen nhanh.\n";
}

void DefendState::calculatePower(Dragon* dragon){
    int power = (dragon->getDame() + dragon->getDefend() * 1.5 + dragon->getHealthPoint() * 1.5) * dragon->getLevel();
    cout << "Suc manh cua rong khi o trang thai phong thu: " << power << "\n";
}

void DefendState::attack(Dragon* dragon){
    cout << "Rong " << dragon->getName() << " phun lua mau xanh la.\n";
}

void DefendState::move(Dragon* dragon){
    cout << "Rong " << dragon->getName() << " di chuyen cham.\n";
}