#include "bai1.h"
#include "bai2.h"

int main(){
    // Bai 1
    cout << "Bai 1.\n";
    Product product1(1, "Sunday Figure Honkai Star Rail", 500000, 2);
    Product product2(2, "Robin Figure Honkai Star Rail", 1000000, 1);

    vector<Product> products;
    products.push_back(product1);
    products.push_back(product2);
    for (auto product : products){
        product.printProduct();
    }
    Order order(101, "Thai Minh Huy", "0909324326", "xxx, phuong xx, quan xx", products);
    order.printOrder();
    PaymentMethod *method = nullptr;

    int choice;
    cout << "Chon phuong thuc thanh toan:\n"
         << "1. Tien mat.\n"
         << "2. The ATM.\n"
         << "3. Momo.\n"
         << "4. Zalopay.\n";
    cin >> choice;
    switch(choice){
        case 1:
            method = new CashPayment();
            break;
        case 2:
            method = new ATMPayment();
            break;
        case 3:
            method = new MomoPayment();
            break;
        case 4:
            method = new ZalopayPayment();
            break;
        default:
            cout << "Lua chon khong hop le.\n";
            return 1;
    }
    order.setPaymentMethod(method);
    order.pay();
    system("pause");
    delete method;

    // Bai 2
    cout << "Bai 2.\n";
    NormalState normal;
    FuryState fury;
    DefendState def;

    Dragon myDragon("Akira", 100, 50, 200, 5, &normal);
    myDragon.printStats();

    myDragon.calculatePower();
    myDragon.attack();
    myDragon.move();

    myDragon.setState(&fury);
    myDragon.calculatePower();
    myDragon.attack();
    myDragon.move();

    myDragon.setState(&def);
    myDragon.calculatePower();
    myDragon.attack();
    myDragon.move();
    system("pause");
    return 0;
}