#pragma once
#include <iostream>
#include <string>
#include <string.h>
#include <iomanip>
using namespace std;

class Student{
    private:
        string studentId;
        double grade;
        string fullname;
    public:
        Student();
        Student(string studentId, double grade, string fullname);
        ~Student();
        
        void inputStudent();
        void outputStudent();
        
        void setStudentId(string studentId);
        string getStudentId();
        void setGrade(double grade);
        double getGrade();
        void setFullname(string fullname);
        string getFullName();

        void setStudentInformation(string studentId, double grade, string fullname);
};