#pragma once
#include <iostream>
#include <algorithm>
#include <string>
#include <string.h>
#include <vector>
#include <fstream>
#include "bai2.h" // Dùng lại class bài 2

class Course{
    private:
        string courseId;
        string courseName;
        vector<Student> students;
        vector<Student> fillerStudentByGrades(double minGrade, double maxGrade);
    public:
        Course();
        Course(string courseId, string courseName);

        void enrollStudent(const Student& student);
        void enrollStudents(const vector<Student>& newstudents);
        void unenrollStudent(const string& studentId);
        void unenrollStudents(const vector<string>& studentId);
        void printStudents();
        vector<Student> getExecellentStudents();
        vector<Student> getGoodStudents();
        vector<Student> getAverageStudents();
        vector<Student> getBelowAverageStudents();
        int countPassStundents();
        int countFailStudents();
        void sortByName(bool ascending);
        void sortByGrades(bool ascending);
        void saveToFile(const string &filename);
        void loadFromFile(const string& filename);
};