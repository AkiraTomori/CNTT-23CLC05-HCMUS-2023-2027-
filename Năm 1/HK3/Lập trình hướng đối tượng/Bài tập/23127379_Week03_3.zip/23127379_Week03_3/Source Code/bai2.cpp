#include "bai2.h"

Student::Student(): studentId(""), grade(0.0), fullname("") {}
Student::Student(string studentId, double grade, string fullname): studentId(studentId), grade(grade), fullname(fullname) {}

Student::~Student() {
    studentId = "";
    grade = 0.0;
    fullname = "";
}

void Student::inputStudent()
{
    cout << "Enter Student's id: ";
    cin >> this->studentId;
    cin.ignore();
    cout << "Enter student's fullname: ";
    getline(cin, this->fullname);

    cout << "Enter student's grade: ";
    cin >> this->grade;
}

void Student::outputStudent()
{
    cout << "ID: " << this->studentId << "\n";
    cout << "Name: " << this->fullname << "\n";
    cout << "Grades: " << this->grade << "\n";
}

void Student::setStudentId(string studentId){
    this->studentId = studentId;
}
string Student::getStudentId(){
    return this->studentId;
}

void Student::setGrade(double grade){
    this->grade = grade;
}
double Student::getGrade(){
    return this->grade;
}

void Student::setFullname(string fullname){
    this->fullname = fullname;
}
string Student::getFullName(){
    return this->fullname;
}

void Student::setStudentInformation(string studentId, double grade, string fullname){
    setStudentId(studentId);
    setGrade(grade);
    setFullname(fullname);
}
