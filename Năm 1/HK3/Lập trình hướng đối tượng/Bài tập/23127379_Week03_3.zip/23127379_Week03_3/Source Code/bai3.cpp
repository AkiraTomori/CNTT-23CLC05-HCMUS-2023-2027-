#include "bai3.h"

Course::Course(): courseId(""), courseName("") {}
Course::Course(string courseId, string courseName): courseId(courseId), courseName(courseName){}

void Course::enrollStudent(const Student& student){
    students.push_back(student);
}
void Course::enrollStudents(const vector<Student>& newStudents){
    for (int i = 0; i < newStudents.size(); i++){
        enrollStudent(newStudents[i]);
    }
}
void Course::unenrollStudent(const string& studentId){
    for (size_t i = 0; i < students.size(); i++){
        if (students[i].getStudentId() == studentId){
            students.erase(students.begin() + i);
            break;
        }
    }
}
void Course::unenrollStudents(const vector<string>& studentId){
    for (auto id : studentId){
        unenrollStudent(id);
    }
}
void Course::printStudents(){
    for (auto id : students){
        id.outputStudent();
    }
}
vector<Student> Course::fillerStudentByGrades(double minGrade, double maxGrade){
    vector<Student> ans;
    for (int i = 0; i < students.size(); i++){
        if (students[i].getGrade() >= minGrade && students[i].getGrade() <= maxGrade)
            ans.push_back(students[i]);
    }
    return ans;
}
vector<Student> Course::getExecellentStudents(){
    return fillerStudentByGrades(9.0, 10.0);
}
vector<Student> Course::getGoodStudents(){
    return fillerStudentByGrades(7.0, 8.9);
}
vector<Student> Course::getAverageStudents(){
    return fillerStudentByGrades(5.0, 6.9);
}
vector<Student> Course::getBelowAverageStudents(){
    return fillerStudentByGrades(0, 4.9);
}
int Course::countPassStundents(){
    int count = 0;
    for (int i = 0; i < students.size(); i++){
        if (students[i].getGrade() >= 5.0)
            count++;
    }
    return count;
}
int Course::countFailStudents(){
    return students.size() - countPassStundents();
}
void Course::sortByName(bool ascending){
    sort(students.begin(), students.end(), [&](Student& a, Student& b){
        return ascending ? a.getFullName() < b.getFullName() : a.getFullName() > b.getFullName();
    });
}
void Course::sortByGrades(bool ascending){
    sort(students.begin(), students.end(), [&](Student& a, Student&b){
        return ascending ? a.getGrade() < b.getGrade() : a.getGrade() > b.getGrade();
    });
}
void Course::saveToFile(const string& filename){
    ofstream fout(filename);
    if (fout.is_open()){
        fout << courseId << "\n";
        fout << courseName << "\n";
        fout << students.size() << "\n";
        for (auto student : students){
            fout << student.getStudentId() << " "
                 << student.getGrade() << " "
                 << student.getFullName() << "\n";
        }
        fout.close();
    }
}
void Course::loadFromFile(const string& filename){
    ifstream fin(filename);
    if (fin.is_open()){
        getline(fin, courseId);
        getline(fin, courseName);
        int studentCount;
        fin >> studentCount;
        fin.ignore();
        students.clear();
        string id, name; double grade;
        string line;
        while (getline(fin, line)){
            size_t pos_1 = line.find(',');
            size_t pos_2 = line.find(',', pos_1 + 1);
            id = line.substr(0, pos_1);
            name = line.substr(pos_1 + 1, pos_2 - pos_1 - 1);
            line = line.substr(pos_2 + 1);
            fin >> grade;
            fin.ignore();
            students.emplace_back(id, grade, name);
        }
        fin.close();
    }
}