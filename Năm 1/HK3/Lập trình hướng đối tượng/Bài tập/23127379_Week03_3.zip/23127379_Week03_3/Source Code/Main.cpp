#include "bai1.h"
#include "bai2.h"
#include "bai3.h"

int main()
{
    // Bai 1
    cout << "Bai 1...............................\n";
    Stack<int> intStack(5);
    intStack.push(1);
    intStack.push(2);
    intStack.push(3);
    intStack.push(4);
    intStack.push(5);
    if (intStack.isFull())
        cout << "Stack is full.\n";
    
    if (!intStack.isEmpty()){
        cout << "Top of IntStacks: " << intStack.getTop() << "\n";
        intStack.pop();
        if (!intStack.isEmpty()){
            cout << "Top of IntStacks after pop: " << intStack.getTop() << "\n";
            intStack.pop();
        }
    }
    intStack.clear();
    if (intStack.isEmpty()){
        cout << "Stack is empty.\n";
    }
    Stack<Fraction> fractionStack(5);
    fractionStack.push(Fraction(1, 2));
    fractionStack.push(Fraction(3, 4));
    fractionStack.push(Fraction(4, 5));
    Fraction p1, p2;
    cin >> p1 >> p2;
    fractionStack.push(p1); fractionStack.push(p2);
    if (!fractionStack.isEmpty()){
        cout << "Top of fractionStack: " << fractionStack.getTop() << "\n";
        fractionStack.pop();
        if (!fractionStack.isEmpty()){
            cout << "Top of fractionStack after pop: " << fractionStack.getTop() << "\n";
        }
    }
    fractionStack.clear();
    // Bai 2
    cout << "\nBai 2...............................\n";
    Student s1, s2("23127379", 3.2, "Thai Minh Huy");
    s2.outputStudent();
    cout << "\nSet new information in s2.\n";
    cout << "Use separated setter.\n";
    s2.setFullname("Tran Van A");
    s2.setGrade(4.0);
    s2.setStudentId("2301000");
    s2.outputStudent();
    cout << "\nUse combination setter.\n";
    s2.setStudentInformation("23010001", 4.0, "Tuong Vy");
    s2.outputStudent();

    cout << "\nSet information for s1.\n";
    s1.inputStudent();
    cout << "ID: " << s1.getStudentId() << "\n"
         << "Name: " << s1.getFullName() << "\n"
         << "Grade: " << s1.getGrade() << "\n";

    // Bai 3
    cout << "\nBai 3\n";

    Course course("CS100003", "Object Oriented Programming");

    Student student1("001", 9.0, "Nguyen Van A");
    Student student2("002", 7.8, "Tran Thi B");
    Student student3("003", 5.5, "Nguyen Thi C");
    Student student4("004", 4.0, "Ly Thi Xoai");
    Student student5("005", 6.8, "Eva");

    course.enrollStudent(student1);
    course.enrollStudent(student2);
    course.enrollStudent(student3);
    course.enrollStudent(student4);
    course.enrollStudent(student5);
    cout << "List of Students.\n";
    course.printStudents();
    cout << "\nList of execellent Student.\n";
    vector<Student> exStudents = course.getExecellentStudents();
    for (int i = 0; i < exStudents.size(); i++){
        exStudents[i].outputStudent();
    }

    cout << "Number of passing students: " << course.countPassStundents() << "\n";
    cout << "Number of fail students: " << course.countFailStudents() << "\n";
    course.sortByName(true);
    cout << "\nList by name in ascending order.\n";
    course.printStudents();
    course.sortByGrades(false);
    cout << "\nList by grades in descending order.\n";
    course.printStudents();

    course.saveToFile("output.txt");
    course.loadFromFile("input.txt");
    cout << "Load from files.\n";
    course.printStudents();
    system("pause");
    return 0;
}