#pragma once
#include <iostream>

using namespace std;

template<class T> class Stack{
    private:
        T* data;
        int topIndex;
        int capacity;
    public:
        Stack(): data(nullptr), topIndex(-1), capacity(0) {}
        Stack(int n): topIndex(-1), capacity(n) {
            data = new T [capacity];
        }
        ~Stack(){
            delete []data;
        }
        void clear(){
            topIndex = -1;
        }
        bool isFull() const{
            return topIndex == capacity - 1;
        }
        bool isEmpty() const{
            return topIndex == -1;
        }
        void push(const T& item){
            if (isFull()){
                throw std::overflow_error("Stack is full.\n");
            }
            data[++topIndex] = item;
        }
        void pop(){
            if (isEmpty()){
                throw std::underflow_error("Stack is empty.\n");
            }
            topIndex--;
        }
        T getTop() const{
            if (isEmpty()){
                throw std::underflow_error("Stack is empty.\n");
            }
            return data[topIndex];
        }
};
class Fraction{
    private:
        int numerator;
        int demoniator;
    public:
        Fraction(): numerator(0), demoniator(1) {}
        Fraction(int numerator, int demoniator): numerator(numerator), demoniator(demoniator) {} 
        ~Fraction(){
            this->numerator = 0; this->demoniator = 1;
        }
        friend ostream& operator<<(ostream& out, const Fraction& other){
            out << other.numerator << "/" << other.demoniator << "\n";
            return out;
        }
        friend istream& operator>>(istream& in, Fraction& other){
            cout << "Numerator: ";
            in >> other.numerator;
            cout << "Demoniator: ";
            in >> other.demoniator;
            return in;
        }
};