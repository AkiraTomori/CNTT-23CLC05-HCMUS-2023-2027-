#pragma once
#include <iostream>
using namespace std;

class Fraction
{
    private:
        int numerator;
        int demorator;
        int FindGCD(int a, int b);
        void Simplify();
    public:
        Fraction();
        Fraction(int numerator, int demorator);
        friend Fraction operator+(const Fraction& p1, const Fraction& p2);
        friend Fraction operator-(const Fraction& p1, const Fraction& p2);
        friend Fraction operator*(const Fraction& p1, const Fraction& p2);
        friend Fraction operator/(const Fraction& p1, const Fraction& p2);
        friend istream &operator>>(istream &in, Fraction& p);
        friend ostream &operator<<(ostream &out,const Fraction& p);
};