#include "bai5.h"

Student::Student() : mathGrade(0.0), englishGrade(0.0), programmingGrade(0.0) {}
Student::Student(double mathGrade, double englishGrade, double programmingGrade) : mathGrade(mathGrade), englishGrade(englishGrade), programmingGrade(programmingGrade) {}

void Student::AssignGrade(double mathGrade, double englishGrade, double programmingGrade)
{
    this->mathGrade = mathGrade;
    this->englishGrade = englishGrade;
    this->programmingGrade = programmingGrade;
}
void Student::InputGrades()
{
    cout << "Math Grades: ";
    cin >> this->mathGrade;
    cout << "English Grades: ";
    cin >> this->englishGrade;
    cout << "Programming Grades: ";
    cin >> this->programmingGrade;
}
double Student::calculateAverage()
{
    return (this->mathGrade + this->englishGrade + this->programmingGrade) / 3.0;
}
bool Student::CheckStudent(const double& average)
{
    if (average > 8.0 && this->mathGrade > 6.5 && this->englishGrade > 6.5 && this->programmingGrade > 6.5)
        return 1;
    else
        return 0;
}
void Student::displayStudent()
{
    double average = calculateAverage();
    cout << "Average Grades: " << average << "\n";
    if (CheckStudent(average))
        cout << "Excellent Student.\n";
    else
        cout << "No\n";
}