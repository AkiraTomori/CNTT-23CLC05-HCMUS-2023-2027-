#pragma once
#include <iostream>
using namespace std;

class Date
{
    private:
        int day;
        int month;
        int year;
        bool checkLeapYear(int year);
        int DaysInMonth(int month, int year);
    public:
        Date();
        Date(int, int, int);
        void setDate(int, int, int);
        void printDate();
        bool isValidDate(int, int, int); // Additional method
        void increaseOneDay();
        void increaseNDays(int n);
        void decreaseOneDay();
        void decreaseNDays(int n);
        int Compare(const Date &other);
};
