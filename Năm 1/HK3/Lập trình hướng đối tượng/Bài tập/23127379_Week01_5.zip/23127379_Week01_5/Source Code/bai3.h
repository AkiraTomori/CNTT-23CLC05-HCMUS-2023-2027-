#pragma once
#include <iostream>
#include <math.h>
using namespace std;

class Point2D
{
    private:
        double x;
        double y;
    public:
        Point2D();
        Point2D(double, double);
        void inputCoordinate();
        void printCoordinate();
        double Distance(const Point2D&);
};