#include "bai1.h"
#include "bai2.h"
#include "bai3.h"
#include "bai4.h"
#include "bai5.h"

int main()
{
    cout << "Bai 1.\n";
    Fraction p1(1, 5), p2, result; // p1 uses constructor, p2 uses operator overloading method, result uses constructor
    
    cout << "First Fraction\n";
    cout << p1;
    
    cout << "Second Fraction\n";
    cin >> p2;
    cout << p2;
    
    cout << "Addition.\n";
    result = p1 + p2;
    cout << result;
    
    cout << "Subtraction.\n";
    result = p1 - p2;
    cout << result;

    cout << "Multiplication.\n";
    result = p1 * p2;
    cout << result;

    cout << "Division.\n";
    result = p1 / p2;
    cout << result;
    
    cout << "\nBai 2.\n";
    cout << "First date\n";
    Date date1(14, 7, 2005); // Use constructor
    date1.printDate();

    cout << "Second date\n";
    Date date2;
    int day, month, year;
    
    cout << "Day: ";
    cin >> day;
    cout << "Month: ";
    cin >> month;
    cout << "Year: ";
    cin >> year;

    date2.setDate(day, month, year);
    date2.printDate();

    cout << "Increase one day.\n";
    date1.increaseOneDay();
    cout << "After increase.\n";
    date1.printDate();
    cout << "Increase n day.\n";
    date1.increaseNDays(25);
    cout << "After increase n days.\n";
    date1.printDate();

    cout << "Decrease one day.\n";
    date2.decreaseOneDay();
    cout << "After decrease one day.\n";
    date2.printDate();
    cout << "Decrease n days.\n";
    date2.decreaseNDays(34);
    cout << "After decrease n days.\n";
    date2.printDate();

    Date date3(29, 11, 2005), date4(14, 7, 2005);
    cout << "Third date: ";
    date3.printDate();
    cout << "Fourth date: ";
    date4.printDate();
    int check = date3.Compare(date4);
    
    if (check == 1)
        cout << "Third date > Fourth date.\n";
    else if (check == 0)
        cout << "Equal.\n";
    else
        cout << "Fourth date > Third date.\n";

    cout << "\nBai 3.\n";
    Point2D point1(3, 4), point2;
    cout << "First Coordinate ";
    point1.printCoordinate();
    cout << "Second Coordinate \n";
    point2.inputCoordinate();
    point2.printCoordinate();
    double toDistance = point1.Distance(point2);
    cout << "Distance between two coordinates is: " << toDistance << "\n";

    cout << "\nBai 4.\n";
    Rectangle rect1(Point2D(0, 2), Point2D(4, 2), Point2D(4, 0), Point2D(0, 0)), rect2;
    cout << "First Rectangle.\n";
    cout << "Rectangle's information.\n";
    rect1.printRectangle();
    if (rect1.isValid())
    {
        cout << "Valid Rectangle.\n";
        cout << "Perimeter: " << rect1.Perimeter() << "\n";
        cout << "Area: " << rect1.Area() << "\n";
    }
    else
        cout << "Invalid Rectangle.\n";
    cout << "Second Rectangle.\n";
    rect2.inputRectangle();
    cout << "Rectangle's information.\n";
    rect2.printRectangle();
    if (rect2.isValid())
    {
        cout << "Valid Rectangle.\n";
        cout << "Perimeter: " << rect2.Perimeter() << "\n";
        cout << "Area: " << rect2.Area() << "\n";
    }
    else
        cout << "Invalid Rectangle.\n";
    
    cout << "\nBai 5.\n";
    Student s1, s2;
    s1.AssignGrade(7, 8, 9); // s1(7, 8, 9);
    cout << "Check first student.\n";
    s1.displayStudent();

    cout << "Check second student.\n";
    s2.InputGrades();
    s2.displayStudent();
    return 0;
}