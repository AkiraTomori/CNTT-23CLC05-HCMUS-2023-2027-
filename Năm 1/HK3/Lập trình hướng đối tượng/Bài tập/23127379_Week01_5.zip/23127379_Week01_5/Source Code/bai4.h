#pragma once
#include "bai3.h"
#include <iostream>
#include <math.h>
using namespace std;

class Rectangle
{
    private:
        Point2D topLeft;
        Point2D topRight;
        Point2D bottomRight;
        Point2D bottomLeft;
        bool almostEqual(double, double);
    public:
        Rectangle();
        Rectangle(Point2D, Point2D, Point2D, Point2D);
        void inputRectangle();
        void printRectangle();
        double Perimeter();
        double Area();
        bool isValid();
};