#include "bai1.h"

int Fraction::FindGCD(int a, int b)
{
    if (b == 0) return a;
    else return FindGCD(b, a % b);
}
void Fraction::Simplify()
{
    int GCD = FindGCD(this->numerator, this->demorator);
    this->numerator /= GCD;
    this->demorator /= GCD;
    if (this->demorator < 0)
    {
        this->numerator = -this->numerator;
        this->demorator = -this->demorator;
    }
}
// Constructor
Fraction::Fraction() : numerator(0), demorator(1) {}
Fraction::Fraction(int numerator, int demorator) : numerator(numerator), demorator(demorator) {}
// Set value, assignment
// Fraction::Fraction()
// {
//     this->numerator = 0;
//     this->demorator = 1;
// }
// Fraction::Fraction(int numerator, int demorator)
// {
//     this->numerator = numerator;
//     this->demorator = demorator;
// }
Fraction operator+(const Fraction& p1, const Fraction &p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.demorator + p1.demorator * p2.numerator;
    result.demorator = p1.demorator * p2.demorator;
    result.Simplify();
    return result;
}
Fraction operator-(const Fraction& p1, const Fraction &p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.demorator - p1.demorator * p2.numerator;
    result.demorator = p1.demorator * p2.demorator;
    result.Simplify();
    return result;
}
Fraction operator*(const Fraction& p1, const Fraction& p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.numerator;
    result.demorator = p1.demorator * p2.demorator;
    result.Simplify();
    return result;
}
Fraction operator/(const Fraction &p1, const Fraction &p2)
{
    Fraction result;
    result.numerator = p1.numerator * p2.demorator;
    result.demorator = p1.demorator * p2.numerator;
    result.Simplify();
    return result;
}
istream &operator>>(istream &in, Fraction &p)
{
    cout << "Numerator: ";
    in >> p.numerator;
    do
    {
        cout << "Demorator: ";
        in >> p.demorator;
        if (p.demorator == 0)
        {
            cout << "Demorator indifference 0.\n";
        }
    } while (p.demorator == 0);    
    return in;
}
ostream &operator << (ostream &out,const Fraction &p)
{
    out << "Fraction form: " << p.numerator << "/" << p.demorator << "\n";
    out << "Decimal form: " << (double)(p.numerator) / p.demorator << "\n";
    return out;
}