#pragma once
#include <iostream>
using namespace std;

class Student
{
    private:
        double mathGrade;
        double englishGrade;
        double programmingGrade;
    public:
        Student();
        Student(double, double, double);
        void AssignGrade(double, double, double);
        double calculateAverage();
        bool CheckStudent(const double&);
        void InputGrades();
        void displayStudent();
};