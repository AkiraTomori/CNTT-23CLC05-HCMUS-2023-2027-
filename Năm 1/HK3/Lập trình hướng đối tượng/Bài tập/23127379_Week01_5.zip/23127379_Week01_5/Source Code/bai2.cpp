#include "bai2.h"

bool Date::checkLeapYear(int year)
{
    return ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0));
}
int Date::DaysInMonth(int month, int year)
{
    switch (month)
    {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            return 31;
        case 4: case 6: case 9: case 11:
            return 30;
        case 2:
            return checkLeapYear(year) ? 29 : 28;
        default:
            return 0;
    }
}
Date::Date() : day(1), month(1), year(2000) {}
Date::Date(int day, int month, int year) : day(day), month(month), year(year) {}
// Date::Date()
// {
//     this->day = 1;
//     this->month = 1;
//     this->year = 2000;
// }
// Date::Date(int day, int month, int year)
// {
//     this->day = day;
//     this->month = month;
//     this->year = year;
// }
bool Date::isValidDate(int day, int month, int year)
{
    // return (year < 0 || month < 1 || month > 12 || day < 1 || day > DaysInMonth(month, year)) ? 0 : 1;
    if (year < 0 || month < 1 || month > 12 || day < 1 || day > (DaysInMonth(month, year)))
        return 0;
    else return 1;
}
void Date::setDate(int iday, int imonth, int iyear)
{
    if (isValidDate(iday, imonth, iyear))
    {
        this->day = iday;
        this->month = imonth;
        this->year = iyear;
    }
    else
        Date();
}
void Date::printDate()
{
    cout << (day < 10 ? "0" : "") << this->day << "/"
         << (month < 10 ? "0" : "") << this->month << "/"
         << this->year << "\n";
}
void Date::increaseOneDay()
{
    this->day++;
    if (this->day > DaysInMonth(this->month, this->year))
    {
        this->day = 1;
        this->month++;
        if (this->month > 12)
        {
            this->month = 1;
            this->year++;
        }
    }
}
void Date::increaseNDays(int n)
{
    for (int i = 1; i <= n; i++)
        increaseOneDay();
}
void Date::decreaseOneDay()
{
    this->day--;
    if (this->day < 1)
    {
        this->month--;
        if (this->month < 1)
        {
            this->month = 12;
            this->year--;
        }
        this->day = DaysInMonth(month, year);
    }
}
void Date::decreaseNDays(int n)
{
    for (int i = 1; i <= n; i++)
        decreaseOneDay();
}
int Date::Compare(const Date& other)
{
    if (this->year < other.year || (this->year == other.year && this->month < other.month) || (this->year == other.year && this->month == other.month && this->day < other.day))
        return -1;
    else if (this->year == other.year && this->month == other.month && this->day == other.day)
        return 0;
    else return 1;
}