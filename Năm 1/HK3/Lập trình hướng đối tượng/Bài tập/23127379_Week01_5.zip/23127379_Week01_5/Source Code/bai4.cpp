#include "bai4.h"

Rectangle::Rectangle() : topLeft(), topRight(), bottomRight(), bottomLeft() {}
Rectangle::Rectangle(Point2D A, Point2D B, Point2D C, Point2D D) : topLeft(A), topRight(B), bottomRight(C), bottomLeft(D) {}

void Rectangle::inputRectangle()
{
    cout << "Coordinate of top-left point:\n";
    topLeft.inputCoordinate();
    cout << "Coordinate of top-right point: \n";
    topRight.inputCoordinate();
    cout << "Coordinate of bottom-right point: \n";
    bottomRight.inputCoordinate();
    cout << "Coordinate of bottom-left point: \n";
    bottomLeft.inputCoordinate();
}
void Rectangle::printRectangle()
{
    cout << "Coordinates of Rectangle.\n";
    cout << "Top-left coordinate: "; topLeft.printCoordinate();
    cout << "Top-right coordinate: "; topRight.printCoordinate();
    cout << "Bottom-right coordinate: "; bottomRight.printCoordinate();
    cout << "Bottom-left coordinate: "; bottomLeft.printCoordinate();
}
bool Rectangle::almostEqual(double a, double b)
{
    double epsilon = 1e-9;
    return fabs(a - b) < epsilon;
}
bool Rectangle::isValid()
{
    double topLength = topLeft.Distance(topRight);
    double bottomLength = bottomLeft.Distance(bottomRight);
    double leftLength = topLeft.Distance(bottomLeft);
    double rightLength = topRight.Distance(bottomRight);
    bool oppositeSide = (almostEqual(topLength, bottomLength) && almostEqual(leftLength, rightLength));

    double diagonal_1 = topLeft.Distance(bottomRight);
    double diagonal_2 = topRight.Distance(bottomLeft);
    bool diagonal = almostEqual(diagonal_1, diagonal_2);
    return oppositeSide && diagonal;
}
double Rectangle::Perimeter()
{
    if (!isValid()) return 0.0;
    double topLength = topLeft.Distance(topRight);
    double leftLength = topLeft.Distance(bottomLeft);
    return (2 * topLength * leftLength);
}
double Rectangle::Area()
{
    if (!isValid()) return 0.0;
    double topLength = topLeft.Distance(topRight);
    double leftLength = topLeft.Distance(bottomLeft);
    return topLength * leftLength;
}