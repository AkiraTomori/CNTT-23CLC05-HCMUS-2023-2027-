#include "bai3.h"

Point2D::Point2D() : x(0), y(0) {}

Point2D::Point2D(double x, double y) : x(x), y(y) {}

void Point2D::inputCoordinate()
{
    cout << "x: ";
    cin >> this->x;
    cout << "y: ";
    cin >> this->y;
}

void Point2D::printCoordinate()
{
    cout << "(" << this->x << "," << this->y << ")" << "\n";
}
double Point2D::Distance(const Point2D& other)
{
     return sqrt(pow(this->x - other.x, 2) + pow(this->y - other.y, 2));
}