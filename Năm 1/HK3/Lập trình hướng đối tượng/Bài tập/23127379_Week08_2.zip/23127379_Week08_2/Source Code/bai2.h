#pragma once
#include <iostream>
#include <vector>

using namespace std;

// Abstract class: Component
class Circuit{
    public:
        virtual double calculateResistance() = 0;
        virtual ~Circuit();
};

// leaf class: SingleCircuit
class SingleCircuit : public Circuit {
    private:
        double resistance;
    public:
        SingleCircuit(double r);

        double calculateResistance();
};

// Composite class: SeriesCircuit (Mach noi tiep)
class SeriesCircuit : public Circuit{
    private:
        vector<Circuit*> subCircuits;
    public:
        ~SeriesCircuit();

        void addSubCircuit(Circuit* circuit);
        double calculateResistance();
};

// Composite Class: Parallel Circuit(Mach song son)
class ParallelCircuit : public Circuit{
    private:
        vector<Circuit*> subCircuits;
    public:
        ~ParallelCircuit();
        void addSubCircuit(Circuit* circuit);
        double calculateResistance();
};