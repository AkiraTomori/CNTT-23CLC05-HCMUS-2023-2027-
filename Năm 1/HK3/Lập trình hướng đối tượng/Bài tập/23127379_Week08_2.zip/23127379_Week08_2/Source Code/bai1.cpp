#include "bai1.h"
#include <algorithm>

// Bar class implementation
Bar::Bar(int posX, int w) : positionX(posX), width(w) {}

void Bar::moveLeft() {
    positionX = max(0, positionX - 1);
    cout << "Bar moved left to position " << positionX << endl;
}

void Bar::moveRight(int maxWidth) {
    positionX = min(maxWidth - width, positionX + 1);
    cout << "Bar moved right to position " << positionX << endl;
}

int Bar::getPositionX() const { return positionX; }
int Bar::getWidth() const { return width; }

// Ball class implementation
Ball* Ball::instance = nullptr;

Ball::Ball(int posX, int posY, int dirX, int dirY)
    : positionX(posX), positionY(posY), directionX(dirX), directionY(dirY) {
    cout << "Ball created at (" << positionX << ", " << positionY << ")!" << endl;
}

Ball* Ball::getInstance() {
    if (instance == nullptr) {
        instance = new Ball();
    }
    return instance;
}

void Ball::move() {
    positionX += directionX;
    positionY += directionY;
    cout << "Ball moved to (" << positionX << ", " << positionY << ")" << endl;
}

int Ball::getPositionX() const { return positionX; }
int Ball::getPositionY() const { return positionY; }

// Brick class implementation
Brick::Brick(int posX, int posY) : positionX(posX), positionY(posY), isBroken(false) {}

void Brick::breakBrick() {
    isBroken = true;
    cout << "Brick at (" << positionX << ", " << positionY << ") broken!" << endl;
}

bool Brick::getIsBroken() const { return isBroken; }
int Brick::getPositionX() const { return positionX; }
int Brick::getPositionY() const { return positionY; }

// Game class implementation
Game::Game() {
    bar = new Bar(5, 10);
    ball = Ball::getInstance();
    for (int i = 0; i < 5; ++i) {
        bricks.push_back(new Brick(i * 2, 10));
    }
    cout << "Game initialized!" << endl;
}

Game::~Game() {
    delete bar;
    delete ball;
    for (Brick* brick : bricks) {
        delete brick;
    }
    cout << "Game destroyed!" << endl;
}

void Game::run() {
    cout << "Game started!" << endl;

    for (int i = 0; i < 3; ++i) {
        ball->move();
        for (Brick* brick : bricks) {
            if (!brick->getIsBroken() &&
                brick->getPositionX() == ball->getPositionX() &&
                brick->getPositionY() == ball->getPositionY()) {
                brick->breakBrick();
            }
        }
    }

    bar->moveLeft();
    bar->moveRight(20);
}
