#include "bai2.h"

Circuit::~Circuit(){}
SingleCircuit::SingleCircuit(double r): resistance(r) {}
double SingleCircuit::calculateResistance(){
    return this->resistance;
}

void SeriesCircuit::addSubCircuit(Circuit* circuit){
    subCircuits.push_back(circuit);
}
SeriesCircuit::~SeriesCircuit(){
    for (auto circuit : subCircuits){
        delete circuit;
    }
}
double SeriesCircuit::calculateResistance(){
    double totalResistance = 0.0;
    for (auto circuit : subCircuits){
        totalResistance += circuit->calculateResistance();
    }
    return totalResistance;
}

void ParallelCircuit::addSubCircuit(Circuit* circuit){
    subCircuits.push_back(circuit);
}
ParallelCircuit::~ParallelCircuit(){
    for (auto circuit : subCircuits){
        delete circuit;
    }
}
double ParallelCircuit::calculateResistance(){
    double inverseTotal = 0.0;
    for (auto circuit : subCircuits){
        double resistance = circuit->calculateResistance();
        if (resistance != 0){
            inverseTotal += (1.0) / resistance;
        }
    }
    return inverseTotal == 0 ? 0.0 : 1.0 / inverseTotal;
}