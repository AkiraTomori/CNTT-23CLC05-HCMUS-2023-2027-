#include "bai1.h"
#include "bai2.h"

int main()
{
    // Bai 1
    cout << "Bai 1.\n";
    Game *game = new Game();
    game->run();
    delete game;
    system("pause");

    // Bai 2
    cout << "Bai 2.\n";
    // Dien tro don
    Circuit *resistor1 = new SingleCircuit(10);
    cout << "First Resistance: " << resistor1->calculateResistance() << " Ohm\n";
    Circuit *resistor2 = new SingleCircuit(20);
    cout << "Second Resistance: " << resistor2->calculateResistance() << " Ohm\n";
    Circuit *resistor3 = new SingleCircuit(30);
    cout << "Third Resistance: " << resistor3->calculateResistance() << " Ohm\n";

    // Mach noi tiep
    SeriesCircuit *seriesCircuit = new SeriesCircuit();
    seriesCircuit->addSubCircuit(resistor1);
    seriesCircuit->addSubCircuit(resistor2);

    cout << "Total resistance of series circuit: " << seriesCircuit->calculateResistance() << "\n";

    // Mach song song
    ParallelCircuit *parallelCircuit = new ParallelCircuit();
    parallelCircuit->addSubCircuit(seriesCircuit);
    parallelCircuit->addSubCircuit(resistor3);
    cout << "Total resistance of parallel circuit: " << parallelCircuit->calculateResistance() << "\n";
    delete parallelCircuit;
    system("pause");
    return 0;
}