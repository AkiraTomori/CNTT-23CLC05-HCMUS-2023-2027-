#pragma once

#include <iostream>
#include <vector>
using namespace std;

// Bar class
class Bar {
private:
    int positionX;
    int width;

public:
    Bar(int posX = 0, int w = 10);
    void moveLeft();
    void moveRight(int maxWidth);
    int getPositionX() const;
    int getWidth() const;
};

// Ball class (Singleton)
class Ball {
private:
    static Ball* instance;
    int positionX, positionY;
    int directionX, directionY;

    Ball(int posX = 0, int posY = 0, int dirX = 1, int dirY = -1);

public:
    Ball(const Ball&) = delete;
    Ball& operator=(const Ball&) = delete;
    static Ball* getInstance();
    void move();
    int getPositionX() const;
    int getPositionY() const;
};

// Brick class
class Brick {
private:
    int positionX, positionY;
    bool isBroken;

public:
    Brick(int posX, int posY);
    void breakBrick();
    bool getIsBroken() const;
    int getPositionX() const;
    int getPositionY() const;
};

// Game class
class Game {
private:
    vector<Brick*> bricks;
    Bar* bar;
    Ball* ball;

public:
    Game();
    ~Game();
    void run();
};
